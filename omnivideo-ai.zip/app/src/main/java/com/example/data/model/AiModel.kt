package com.example.data.model

data class AiVideoEngine(
  val id: String,
  val name: String,
  val company: String,
  val resolution: String,
  val maxFps: Int,
  val latencyAvg: String,
  val strengths: String,
  val badge: String
)

data class ElevenLabsVoice(
  val id: String,
  val name: String,
  val language: String,
  val tone: String,
  val gender: String,
  val samplePrompt: String
)

data class RenderJob(
  val id: String,
  val projectName: String,
  val outputAspects: List<AspectRatioType>,
  val resolution: String, // "4K (3840x2160)", "1080p Full HD"
  val codec: String, // "HEVC / H.265", "AV1", "ProRes 422"
  val progress: Float, // 0.0 to 1.0
  val status: RenderStatus,
  val gpuNode: String,
  val clientWebGpuFps: Int = 60,
  val serverNvencSpeed: String = "4.2x Gerçek Zamanlı",
  val cloudStorageUrl: String? = null
)

enum class RenderStatus(val label: String, val colorHex: Long) {
  QUEUED("Kuyrukta", 0xFF94A3B8),
  PROCESSING_CLIENT("WebGPU Önizleme", 0xFF00D2FF),
  ENCODING_NVENC("CUDA / NVENC Render", 0xFFA855F7),
  UPLOADING_CLOUD("Cloudflare R2 / S3 Dağıtım", 0xFFFBBF24),
  COMPLETED("Tamamlandı (4K Hazır)", 0xFF10B981),
  FAILED("Hata", 0xFFEF4444)
}
