package com.example.data.model

enum class SubscriptionTier(val title: String, val badge: String, val colorHex: Long) {
  FREE("Ücretsiz Plan", "FREE", 0xFF94A3B8),
  PRO_VIP("Pro VIP Stüdyo", "PRO VIP", 0xFFFBBF24)
}

enum class BillingCycle(val label: String, val price: String, val discountNote: String) {
  MONTHLY("Aylık Abonelik", "₺149 / ay", "Her ay yenilenir"),
  YEARLY("Yıllık Abonelik", "₺999 / yıl", "%44 İndirim • En Popüler")
}

data class CreditPackage(
  val id: String,
  val credits: Int,
  val price: String,
  val description: String,
  val isPopular: Boolean = false,
  val bonusTag: String? = null
)

data class FeatureComparisonItem(
  val featureName: String,
  val freeValue: String,
  val proValue: String,
  val isProExclusive: Boolean = false
)
