package com.example.data.model

enum class ArchitectureLayer(val displayName: String, val colorHex: Long) {
  FREE_TIER_TOOLS("Ücretsiz Katman (Temel Araçlar & 1080p)", 0xFF94A3B8),
  PREMIUM_AI_TIER("Premium Katman (10 Klip AI, 4K & Whisper)", 0xFFFBBF24),
  CENTER_WORKSPACE("Merkez: Çoklu Format Tuval & Çoklu İz", 0xFF00D2FF),
  BOTTOM_TECH_RENDER("Teknoloji, Render & Ödeme Altyapısı", 0xFF10B981)
}

data class ArchitectureNode(
  val id: String,
  val layer: ArchitectureLayer,
  val title: String,
  val subtitle: String,
  val iconName: String,
  val detailedDescription: String,
  val technologies: List<String>,
  val metrics: String,
  val dataflowIn: String,
  val dataflowOut: String,
  val highlightBadge: String,
  val isPremiumFeature: Boolean = false
)

data class DataStreamLine(
  val fromNodeId: String,
  val toNodeId: String,
  val colorHex: Long,
  val label: String
)
