package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class VideoRepository {

  val architectureNodes: List<ArchitectureNode> = listOf(
    // 1. ÜCRETSİZ KATMAN (FREE TIER)
    ArchitectureNode(
      id = "free_basic_editing",
      layer = ArchitectureLayer.FREE_TIER_TOOLS,
      title = "Temel Görsel ve Video Kurgu",
      subtitle = "Kırpma, Döndürme, Temel Renk, Kesme & Geçişler",
      iconName = "ContentCut",
      detailedDescription = "Kullanıcı çekmek için sunulan ücretsiz araçlar: Görsel kırpma, döndürme, temel parlaklık ayarları, video kesme, birleştirme ve standart geçiş efektleri.",
      technologies = listOf("Canvas 2D", "Temel Kırpıcı", "Standart Şablonlar", "WebAssembly"),
      metrics = "Ücretsiz Herkes İçin | Sınırsız Temel Kurgu",
      dataflowIn = "Kullanıcı Medyası ve Temel Kırpma Komutları",
      dataflowOut = "1080p Önizleme Tamponu",
      highlightBadge = "ÜCRETSİZ",
      isPremiumFeature = false
    ),
    ArchitectureNode(
      id = "free_limited_export",
      layer = ArchitectureLayer.FREE_TIER_TOOLS,
      title = "Sınırlı Çıktı & Köşe Filigranı",
      subtitle = "Maksimum 1080p 30 FPS + 'OmniVideo AI Free' Logosu",
      iconName = "BrandingWatermark",
      detailedDescription = "Ücretsiz kullanıcıların videolarının köşesine uygulamanın logosu yerleştirilir. Çıktı kalitesi maksimum 1080p (30 FPS) ile sınırlandırılır; filigranı kaldırmak için Premium yükseltme gerekir.",
      technologies = listOf("Watermark Overlay", "1080p 30FPS Capping", "H.264 Standart Codec"),
      metrics = "1080p 30 FPS Sınırı | Filigran Dahil",
      dataflowIn = "İşlenmiş Video Kareleri",
      dataflowOut = "Filigranlı 1080p Video Dosyası",
      highlightBadge = "FİLİGRANLI",
      isPremiumFeature = false
    ),
    ArchitectureNode(
      id = "free_daily_quota",
      layer = ArchitectureLayer.FREE_TIER_TOOLS,
      title = "Günlük Deneme Üretim Hakları",
      subtitle = "Günlük 2 Adet Kısa AI Görsel / Video Üretim Kotası",
      iconName = "CalendarToday",
      detailedDescription = "Kullanıcıların yapay zeka gücünü tatması için günlük 2 adet kısa AI görsel veya video üretim hakkı tanımlanır. Daha fazlası için Pro abonelik veya kredi paketi gerekir.",
      technologies = listOf("Daily Reset Cron", "2 Hak/Gün Kotası", "Temel Şablon Kütüphanesi"),
      metrics = "Günlük 2 Ücretsiz AI Hakkı",
      dataflowIn = "Kullanıcı Deneme Talebi",
      dataflowOut = "Hafif AI Model Çıktısı",
      highlightBadge = "2 HAK/GÜN",
      isPremiumFeature = false
    ),

    // 2. PREMIUM & KREDİ KATMANI (VIP TIER)
    ArchitectureNode(
      id = "prem_text_to_video",
      layer = ArchitectureLayer.PREMIUM_AI_TIER,
      title = "Dahili AI Video Üretimi",
      subtitle = "9:16 ve 16:9 Yüksek Kalite Veo 2, Sora, Kling & Flux",
      iconName = "AutoAwesome",
      detailedDescription = "Komut kutusundan dikey (9:16) ve yatay (16:9) formatlarda yüksek kaliteli fotogerçekçi AI videoları ve Flux.1 ile 4K görseller üreten premium modül.",
      technologies = listOf("Google Veo 2", "OpenAI Sora", "Kling 1.5 Pro", "Flux.1 4K Görsel"),
      metrics = "4K Ultra-Res | 60 FPS | Sınırsız Prompt",
      dataflowIn = "Metin Komutları & Kamera Yörüngeleri",
      dataflowOut = "Yüksek Kaliteli Video Kareleri",
      highlightBadge = "PREMIUM VIP",
      isPremiumFeature = true
    ),
    ArchitectureNode(
      id = "prem_batch_10_scenes",
      layer = ArchitectureLayer.PREMIUM_AI_TIER,
      title = "10 Sahne Toplu Üretim & Birleştirme",
      subtitle = "Tek Tıkla 10 Klibi Üretip Zaman Çizelgesine Otomatik Dizme",
      iconName = "VideoCameraBack",
      detailedDescription = "Senaryoyu 10 parçaya bölüp 8-15 sn klipleri tek seferde üreten ve Auto-Assemble motoruyla geçiş efektleriyle birleştirip 2 dakikalık uzun video hazırlayan amiral gemisi özellik.",
      technologies = listOf("10/10 Batch Quota", "Parallel Scene Generator", "Auto-Assemble Engine"),
      metrics = "10 Sahne Tek Tıkla | 2:00 dk Uzun Format",
      dataflowIn = "10 Bölümlü Senaryo",
      dataflowOut = "Birleşik Master Video İzi",
      highlightBadge = "EN POPÜLER",
      isPremiumFeature = true
    ),
    ArchitectureNode(
      id = "prem_whisper_subtitles",
      layer = ArchitectureLayer.PREMIUM_AI_TIER,
      title = "AI Otomatik Altyazı (Whisper)",
      subtitle = "Kelime Senkronlu, Animasyonlu ve Çok Dilli Altyazılar",
      iconName = "ClosedCaption",
      detailedDescription = "OpenAI Whisper Large-v3 ile konuşmaları otomatik yakalayan, milisaniye hassasiyetli kelime bazlı animasyonlu karaoke neon altyazı motoru.",
      technologies = listOf("Whisper Large-v3", "Word Karaoke Sync", "Animasyonlu Tipografi"),
      metrics = "%99.4 Kelime Doğruluğu | Sınırsız Dakika",
      dataflowIn = "Ses Dalga Akışı",
      dataflowOut = "Zaman Damgalı Altyazı Katmanı",
      highlightBadge = "PREMIUM",
      isPremiumFeature = true
    ),
    ArchitectureNode(
      id = "prem_elevenlabs_tts",
      layer = ArchitectureLayer.PREMIUM_AI_TIER,
      title = "AI Metinden Seslendirme (ElevenLabs)",
      subtitle = "Doğal Türkçe Spiker Tonlamaları (Elif, Ahmet, Can)",
      iconName = "RecordVoiceOver",
      detailedDescription = "Metin senaryolarından duygusal tonlamaya sahip, stüdyo kalitesinde Türkçe seslendirme üretir. TikTok, Shorts ve YouTube anlatımları için kusursuzdur.",
      technologies = listOf("ElevenLabs Multilingual v2", "Türkçe Dil Modeli", "44.1 kHz WAV"),
      metrics = "Stüdyo Kalitesi | Doğal Nefes & Vurgu",
      dataflowIn = "Senaryo Metni",
      dataflowOut = "Master WAV Ses İzi",
      highlightBadge = "PREMIUM",
      isPremiumFeature = true
    ),
    ArchitectureNode(
      id = "prem_rembg_background",
      layer = ArchitectureLayer.PREMIUM_AI_TIER,
      title = "Tek Tıkla Arka Plan Silme (rembg)",
      subtitle = "Yeşil Ekransız AI Nesne ve İnsan Segmentasyonu",
      iconName = "LayersClear",
      detailedDescription = "Videolarda ve görsellerde yeşil perde olmadan insanı ve nesneleri milisaniyeler içinde dekupe eden AI segmentasyon modülü.",
      technologies = listOf("rembg AI", "WebGPU Matting", "Alpha Channel"),
      metrics = "60 FPS Gerçek Zamanlı Dekupe",
      dataflowIn = "Video/Görsel Katmanı",
      dataflowOut = "Şeffaf Alpha Katmanı",
      highlightBadge = "PREMIUM",
      isPremiumFeature = true
    ),
    ArchitectureNode(
      id = "prem_4k_no_watermark",
      layer = ArchitectureLayer.PREMIUM_AI_TIER,
      title = "Filigransız Çıktı & 4K 60 FPS Export",
      subtitle = "Logosuz, NVIDIA NVENC Donanım Hızlandırmalı 4K Master",
      iconName = "HighQuality",
      detailedDescription = "Tüm logoları ve filigranları kaldırır; 4K Ultra HD (3840x2160) ve 60 FPS akıcılıkta ultra net çıktılar sunar.",
      technologies = listOf("NVIDIA NVENC Dual-Pass", "CUDA 12.4", "HEVC/H.265 4K 60FPS"),
      metrics = "4K UHD 60 FPS | Sıfır Filigran",
      dataflowIn = "Master Render Çizelgesi",
      dataflowOut = "4K Filigransız Video Dosyası",
      highlightBadge = "4K VIP",
      isPremiumFeature = true
    ),

    // 3. MERKEZİ ÇALIŞMA ALANI & TUVAL
    ArchitectureNode(
      id = "workspace_multi_format",
      layer = ArchitectureLayer.CENTER_WORKSPACE,
      title = "Çoklu Format Canlı Önizleme",
      subtitle = "Sol 9:16 Dikey Mobil, Sağ 16:9 / 1:1 Tuval Ekranı",
      iconName = "SmartDisplay",
      detailedDescription = "Reels/TikTok için dikey 9:16 ve YouTube/Grafik için 16:9 / 1:1 formatlarında eşzamanlı canlı tuval.",
      technologies = listOf("PixiJS", "Fabric.js", "WebGPU 60 FPS"),
      metrics = "60 FPS Eşzamanlı Çift Tuval",
      dataflowIn = "Grafik & Video Katmanları",
      dataflowOut = "Canlı Ekran Tamponu",
      highlightBadge = "MERKEZ TUVAL",
      isPremiumFeature = false
    ),
    ArchitectureNode(
      id = "workspace_multitrack_timeline",
      layer = ArchitectureLayer.CENTER_WORKSPACE,
      title = "Çoklu İz Zaman Çizelgesi",
      subtitle = "Video, Ses, Görsel, Vektör, Metin & Efekt Katmanları",
      iconName = "ViewTimeline",
      detailedDescription = "5 bağımsız katmanın milisaniye hassasiyetinde yönetildiği gelişmiş zaman çizelgesi.",
      technologies = listOf("Multi-Track Engine", "Frame-Accurate Cut", "Magnet Snapping"),
      metrics = "5 Katman | 120 sn Kapasite",
      dataflowIn = "10 Klip + Katmanlar",
      dataflowOut = "Montaj Haritası",
      highlightBadge = "TIMELINE",
      isPremiumFeature = false
    ),

    // 4. TEKNOLOJİ, RENDER & ÖDEME ALTYAPISI
    ArchitectureNode(
      id = "tech_client_side",
      layer = ArchitectureLayer.BOTTOM_TECH_RENDER,
      title = "İstemci Tarafı (Client-Side)",
      subtitle = "WebAssembly (FFmpeg.wasm), Canvas & WebGPU",
      iconName = "Memory",
      detailedDescription = "Cihaz üzerinde sıfır gecikmeli 60 FPS önizleme ve hafif düzenlemeler sağlar.",
      technologies = listOf("FFmpeg.wasm", "WebGPU", "PixiJS"),
      metrics = "60 FPS Sıfır Gecikme | 10.4ms",
      dataflowIn = "Düzenleme Komutları",
      dataflowOut = "Anlık Frame Buffer",
      highlightBadge = "WEBGPU",
      isPremiumFeature = false
    ),
    ArchitectureNode(
      id = "tech_server_render",
      layer = ArchitectureLayer.BOTTOM_TECH_RENDER,
      title = "Sunucu Tarafı 4K Render",
      subtitle = "Node.js Orkestratörü, FFmpeg & CUDA / NVENC 4K",
      iconName = "Dns",
      detailedDescription = "10 videoyu ve grafik katmanlarını tek parça 4K çıktı almak için donanım hızlandırma havuzu.",
      technologies = listOf("Node.js Workers", "CUDA 12.4", "Dual NVENC"),
      metrics = "4.8x Gerçek Zaman | 4K 60FPS",
      dataflowIn = "Master Proje Dosyaları",
      dataflowOut = "4K Video Dosyaları",
      highlightBadge = "CUDA 4K",
      isPremiumFeature = true
    ),
    ArchitectureNode(
      id = "tech_monetization_payment",
      layer = ArchitectureLayer.BOTTOM_TECH_RENDER,
      title = "Ödeme & Kredi Faturalandırma Altyapısı",
      subtitle = "Aylık ₺149 / Yıllık ₺999 Abonelik & Kredi Havuzu",
      iconName = "Payment",
      detailedDescription = "Kullanıcıların aboneliklerini (Aylık/Yıllık) ve yapay zeka kredi paketlerini yöneten güvenli ödeme mikroservisi.",
      technologies = listOf("Stripe / Google Play Billing", "Credit Ledger", "Realtime Quota Sync"),
      metrics = "₺149/Ay • ₺999/Yıl • Kredi Paketleri",
      dataflowIn = "Ödeme Talepleri ve Kredi Kullanımları",
      dataflowOut = "Doğrulanmış Lisans ve Bakiye Onayı",
      highlightBadge = "FATURALANDIRMA",
      isPremiumFeature = false
    )
  )

  val creditPackages = listOf(
    CreditPackage("pack_50", 50, "₺79", "5 AI Video veya 25 AI Görsel"),
    CreditPackage("pack_100", 100, "₺129", "10 Adet AI Video Toplu Üretim"),
    CreditPackage("pack_250", 250, "₺249", "25 AI Video + Öncelikli Render Sırası", isPopular = true, bonusTag = "EN POPÜLER"),
    CreditPackage("pack_500", 500, "₺399", "50 AI Video + VIP Stüdyo Çekirdeği", bonusTag = "VIP AVANTAJ")
  )

  val featureComparisons = listOf(
    FeatureComparisonItem("Temel Video & Görsel Kurgu", "Sınırsız", "Sınırsız"),
    FeatureComparisonItem("Dışa Aktarma Çözünürlüğü", "1080p (30 FPS)", "4K Ultra HD (60 FPS)", isProExclusive = true),
    FeatureComparisonItem("Köşe Filigranı (Watermark)", "Logo Eklenir", "Tamamen Filigransız", isProExclusive = true),
    FeatureComparisonItem("10 Sahne Toplu AI Üretimi", "Günlük 2 Deneme", "Sınırsız (Veo, Sora, Kling)", isProExclusive = true),
    FeatureComparisonItem("Whisper Kelime Senkron Altyazı", "10 sn Sınırlı", "Sınırsız Çok Dilli Karaoke", isProExclusive = true),
    FeatureComparisonItem("ElevenLabs Doğal Türkçe TTS", "Kilitli (Önizleme)", "Sınırsız Stüdyo Kalitesi", isProExclusive = true),
    FeatureComparisonItem("Tek Tıkla Arka Plan Silme (rembg)", "Kilitli", "Sınırsız Yeşil Ekransız AI", isProExclusive = true),
    FeatureComparisonItem("Akıllı Auto-Reframe (9:16 - 16:9)", "Kilitli", "Sınırsız YOLOv8 Takibi", isProExclusive = true),
    FeatureComparisonItem("VIP Şablon & Sinematik LUT", "Temel Şablonlar", "Tüm VIP Kütüphane", isProExclusive = true)
  )

  val aiEngines: List<AiVideoEngine> = listOf(
    AiVideoEngine("flux1", "Flux.1 Dev", "Black Forest Labs", "4K Ultra-Res Görsel", 60, "1.4 sn/görsel", "Fotogerçekçi görsel üretimi, tipografi ve detay zenginliği", "Görsel AI"),
    AiVideoEngine("veo2", "Google Veo 2", "Google DeepMind", "4K Ultra HD Video", 60, "2.4 sn/kare", "Yüksek fiziksel tutarlılık, sinematik kamera hareketleri", "Önerilen Video"),
    AiVideoEngine("sora", "OpenAI Sora", "OpenAI", "1080p Geniş Video", 30, "3.1 sn/kare", "Karmaşık sahne kompozisyonu ve ışık simülasyonu", "En Popüler"),
    AiVideoEngine("kling", "Kling 1.5 Pro", "Kuaishou", "1080p Dikey/Yatay", 30, "1.8 sn/kare", "Akıcı insan hareketleri ve nesne etkileşimi", "Hızlı Video"),
    AiVideoEngine("seedance", "Seedance Video", "Seedance", "720p / 1080p", 30, "1.2 sn/kare", "Sosyal medya kısa videoları için ultra hızlı nesil", "Ultra Hızlı"),
    AiVideoEngine("wan", "Wan 2.1", "Wan AI Lab", "1080p Sinematik", 24, "2.0 sn/kare", "Gelişmiş anime, bilim kurgu ve siberpunk dokuları", "Stil Uzmanı")
  )

  val elevenLabsVoices: List<ElevenLabsVoice> = listOf(
    ElevenLabsVoice("elif", "Elif - Enerjik & Sosyal", "Türkçe (TR)", "TikTok, Reels & Shorts Dinamik", "Kadın", "Canva ve CapCut tarzı hepsi bir arada stüdyomuz hazır, hemen üretmeye başlayın!"),
    ElevenLabsVoice("ahmet", "Ahmet - Derin Anlatıcı", "Türkçe (TR)", "Belgesel & Sinematik Karizmatik", "Erkek", "Yapay zeka mimarisi görsel katmanları ve 10 video sahnesini kusursuz birleştiriyor."),
    ElevenLabsVoice("can", "Can - Teknoloji Rehberi", "Türkçe (TR)", "Net, Modern & Profesyonel", "Erkek", "WebGPU, PixiJS ve CUDA NVENC paralel çalışarak sıfır gecikmeli kurgu sağlar."),
    ElevenLabsVoice("zeynep", "Zeynep - Sakin & Masalsı", "Türkçe (TR)", "Duygusal, Şiirsel & Akıcı", "Kadın", "Mavi, mor ve altın veri hatlarıyla geleceğin içerik stüdyosu parmaklarınızın ucunda.")
  )

  fun createSampleProject(): VideoProject {
    val scenes10 = listOf(
      VideoScene("sc_1", "1. Siber Şehir Girişi", 12f, "Neon ışıklı siber şehir üzerinde drone süzülüşü", "Google Veo 2", 0xFF00D2FF, 0xFFA855F7, "Siber Işık İzi", "Drone İleri Uçuş", 0.5f, "Çapraz Geçiş (Crossfade)"),
      VideoScene("sc_2", "2. Kuantum AI Çekirdeği", 11f, "Dönen altın rengi kuantum yapay zeka çekirdeği", "OpenAI Sora", 0xFFFBBF24, 0xFF10B981, "Kuantum Parıltı", "360 Yavaş Yörünge", 0.48f, "Dinamik Zum (Zoom Blur)"),
      VideoScene("sc_3", "3. Holografik Arayüz", 12f, "Havada asılı parlayan 3B izometrik dokunmatik arayüz panelleri", "Kling 1.5 Pro", 0xFF00D2FF, 0xFFFBBF24, "Holografik Tarama", "Dinamik Yakınlaşma", 0.52f, "Glitch Geçiş"),
      VideoScene("sc_4", "4. Veri Akış Hatları", 13f, "Mavi, mor ve altın rengi fiber optik veri hatları", "Wan 2.1", 0xFFA855F7, 0xFF00D2FF, "Neon Işık Akışı", "Pan Sağ", 0.5f, "Hızlı Pan (Whip Pan)"),
      VideoScene("sc_5", "5. Siber Otoyol Hızı", 10f, "Uçan otonom siber araçların neon yollardaki akışı", "Seedance Video", 0xFFFBBF24, 0xFFEF4444, "Işık İzi Hızı", "Hızlı Takip", 0.49f, "Çapraz Geçiş (Crossfade)"),
      VideoScene("sc_6", "6. Nöral Ağ Matrisi", 14f, "Milyarlarca parlayan sinaps bağlantısından oluşan nöral küre", "Google Veo 2", 0xFF10B981, 0xFF00D2FF, "Sinaptik Kıvılcım", "Vinç Yukarı", 0.51f, "Dinamik Zum (Zoom Blur)"),
      VideoScene("sc_7", "7. Biyo-Robotik Entegrasyon", 11f, "Gelişmiş android robot elinin dijital ışık kristalini tutuşu", "OpenAI Sora", 0xFF00D2FF, 0xFFA855F7, "Krom Yansıma", "Makro Odaklanma", 0.5f, "Glitch Geçiş"),
      VideoScene("sc_8", "8. Neon Yağmur Işıkları", 12f, "Gökdelenlerin ıslak siber sokaklardaki yansımaları", "Kling 1.5 Pro", 0xFFA855F7, 0xFFFBBF24, "Yağmur Parıltısı", "Tilt Aşağı", 0.48f, "Hızlı Pan (Whip Pan)"),
      VideoScene("sc_9", "9. Global Uydu İletişimi", 13f, "Dünya yörüngesindeki kuantum uydulardan yeryüzüne inen lazer ağları", "Wan 2.1", 0xFF00D2FF, 0xFF10B981, "Lazer Işınları", "Yörünge Uçuşu", 0.53f, "Çapraz Geçiş (Crossfade)"),
      VideoScene("sc_10", "10. Geleceğin Şafağı", 12f, "Siber metropolün üzerinde doğan fütüristik altın şafak güneşi", "Google Veo 2", 0xFFFBBF24, 0xFF00D2FF, "Güneş Işıması", "Geniş Sinematik", 0.5f, "Kararma (Fade to Black)")
    )

    val graphicLayersSample = listOf(
      GraphicLayer("l_1", "Başlık Metni", LayerType.TEXT, "GELECEĞİN İÇERİK STÜDYOSU", 0.5f, 0.18f, 1.2f, 0f, 0xFFFBBF24),
      GraphicLayer("l_2", "Vektör Rozet", LayerType.STICKER, "⚡ CANVA + CAPCUT AI", 0.5f, 0.28f, 1.0f, 0f, 0xFF00D2FF),
      GraphicLayer("l_3", "Vurgu Metni", LayerType.TEXT, "Tek Tıkla 10 Sahne & Çoklu Format", 0.5f, 0.82f, 1.0f, 0f, 0xFFFFFFFF),
      GraphicLayer("l_4", "Görsel Filtre", LayerType.EFFECT, "Siber Neon LUT", 0.5f, 0.5f, 1.0f, 0f, 0xFFA855F7)
    )

    val wordsFullNarrative = listOf(
      CaptionWord("Canva", 500, 1100),
      CaptionWord("ve", 1150, 1500),
      CaptionWord("CapCut", 1550, 2400),
      CaptionWord("tarzı", 2450, 3100),
      CaptionWord("hepsi", 3200, 3700),
      CaptionWord("bir", 3750, 4100),
      CaptionWord("arada", 4150, 4800),
      CaptionWord("stüdyo!", 4900, 6000),

      CaptionWord("Hem", 12000, 12600),
      CaptionWord("görselleri", 12700, 13700),
      CaptionWord("katmanlarla", 13800, 15100),
      CaptionWord("düzenleyin,", 15200, 16400),

      CaptionWord("hem", 24000, 24600),
      CaptionWord("de", 24650, 25000),
      CaptionWord("on", 25100, 25600),
      CaptionWord("yapay", 25700, 26400),
      CaptionWord("zeka", 26500, 27100),
      CaptionWord("sahnesini", 27200, 28300),
      CaptionWord("birleştirin.", 28400, 29800),

      CaptionWord("Dikey", 36000, 36800),
      CaptionWord("dokuz", 36900, 37600),
      CaptionWord("on", 37650, 38000),
      CaptionWord("altı", 38050, 38600),
      CaptionWord("ve", 38700, 39100),
      CaptionWord("yatay", 39200, 40000),
      CaptionWord("on", 40100, 40500),
      CaptionWord("altı", 40550, 41100),
      CaptionWord("dokuz", 41150, 41800),
      CaptionWord("hazır!", 41900, 43000),

      CaptionWord("Whisper", 60000, 61000),
      CaptionWord("kelime", 61100, 62000),
      CaptionWord("senkronizasyonu", 62100, 64200),
      CaptionWord("ve", 64300, 64700),
      CaptionWord("ElevenLabs", 64800, 66200),
      CaptionWord("Türkçe", 66300, 67200),
      CaptionWord("seslendirme", 67300, 68800),
      CaptionWord("aktif!", 68900, 71000)
    )

    return VideoProject(
      id = "proj_canva_capcut_studio",
      title = "Hepsi Bir Arada İçerik Stüdyosu",
      currentAspect = AspectRatioType.PORTRAIT_9_16,
      scenes = scenes10,
      graphicLayers = graphicLayersSample,
      voiceover = VoiceoverTrack(
        id = "vo_allinone",
        speakerName = "Elif - Enerjik & Sosyal",
        language = "Türkçe (TR)",
        scriptText = "Canva ve CapCut tarzı hepsi bir arada stüdyo! Hem görselleri katmanlarla düzenleyin hem de 10 AI sahnesi üretin.",
        durationMs = 120000L,
        words = wordsFullNarrative
      ),
      subtitleStyle = "Karaoke Neon",
      autoReframeEnabled = true,
      smartBackgroundRemoved = false,
      totalDurationSeconds = 120f,
      maxQuota = 10,
      currentQuotaCount = 10
    )
  }

  val sampleProjects: List<VideoProject> = listOf(
    createSampleProject()
  )

  private val _activeRenderJobs = MutableStateFlow<List<RenderJob>>(
    listOf(
      RenderJob(
        id = "job_1",
        projectName = "Hepsi Bir Arada İçerik Stüdyosu",
        outputAspects = listOf(AspectRatioType.PORTRAIT_9_16, AspectRatioType.LANDSCAPE_16_9),
        resolution = "4K Ultra HD (3840x2160)",
        codec = "HEVC / H.265 (Donanım NVENC)",
        progress = 0.95f,
        status = RenderStatus.ENCODING_NVENC,
        gpuNode = "NVIDIA RTX 4090 #03 (CUDA 12.4)",
        clientWebGpuFps = 60,
        serverNvencSpeed = "4.8x Gerçek Zamanlı",
        cloudStorageUrl = "https://cdn.omnivideo.ai/export/canva_capcut_allinone.mp4"
      )
    )
  )
  val activeRenderJobs: StateFlow<List<RenderJob>> = _activeRenderJobs.asStateFlow()

  val popularTemplates: List<TemplateItem> = listOf(
    TemplateItem("tmpl_1", "Siberpunk Trend Reels", "TikTok / Reels", AspectRatioType.PORTRAIT_9_16, "1080 x 1920", "🔥 TREND", false, "28.4K", 0xFF7C3AED, 0xFFEC4899, "📱", listOf("Reels", "TikTok", "9:16")),
    TemplateItem("tmpl_2", "YouTube 4K Tech İntro", "YouTube", AspectRatioType.LANDSCAPE_16_9, "3840 x 2160", "👑 PRO", true, "19.1K", 0xFF2563EB, 0xFF06B6D4, "🎬", listOf("YouTube", "16:9", "4K")),
    TemplateItem("tmpl_3", "10 Sahne Sinematik Belgesel", "AI Sinema", AspectRatioType.LANDSCAPE_16_9, "1920 x 1080", "✨ AI BATCH", true, "14.5K", 0xFFF59E0B, 0xFF7C3AED, "🪄", listOf("10 Sahne", "Sora", "Veo")),
    TemplateItem("tmpl_4", "E-Ticaret Ürün Reklamı", "Ticari / E-Ticaret", AspectRatioType.PORTRAIT_9_16, "1080 x 1920", "POPÜLER", false, "32.0K", 0xFF10B981, 0xFF06B6D4, "🛍️", listOf("Shop", "Dikey", "Reels")),
    TemplateItem("tmpl_5", "Podcast & Whisper Karaoke", "Altyazılı Klip", AspectRatioType.PORTRAIT_9_16, "1080 x 1920", "KARAOKE", false, "41.2K", 0xFFA855F7, 0xFF2563EB, "🎙️", listOf("Whisper", "ElevenLabs", "Shorts")),
    TemplateItem("tmpl_6", "Minimalist Canva Banner", "Grafik Tasarım", AspectRatioType.LANDSCAPE_16_9, "1200 x 630", "YENİ", false, "11.8K", 0xFFEC4899, 0xFFF59E0B, "🖼️", listOf("Banner", "Canva", "Post"))
  )

  val recentProjects: List<RecentProjectCard> = listOf(
    RecentProjectCard("proj_rec_1", "Siber Metropol & Gelecek", AspectRatioType.PORTRAIT_9_16, 120, "2 dk önce", 10, "4K UHD (60 FPS)", 0xFF7C3AED, 0xFF00D2FF, true),
    RecentProjectCard("proj_rec_2", "Yapay Zeka Çağı Tanıtımı", AspectRatioType.LANDSCAPE_16_9, 85, "1 saat önce", 8, "1080p Full HD", 0xFF2563EB, 0xFF7C3AED, true),
    RecentProjectCard("proj_rec_3", "Trend Dans & Müzik Klip", AspectRatioType.PORTRAIT_9_16, 30, "Dün", 4, "1080 x 1920", 0xFFEC4899, 0xFFF59E0B, false),
    RecentProjectCard("proj_rec_4", "Teknoloji Ürün Lansmanı", AspectRatioType.LANDSCAPE_16_9, 60, "3 gün önce", 6, "4K UHD", 0xFF10B981, 0xFF2563EB, true)
  )

  val trendAudios: List<TrendAudio> = listOf(
    TrendAudio("snd_1", "Phonk Cyber Echo (Slowed)", "Kxrvx Beats", 28, "1.4M Video", "+380%", "Phonk / Trap"),
    TrendAudio("snd_2", "Deep Focus Lo-Fi Study", "Chill Synth Wave", 60, "890K Video", "+210%", "Lo-Fi / Ambient"),
    TrendAudio("snd_3", "Neon Synth Action Riser", "Cyberpulse Audio", 35, "640K Video", "+185%", "Sinematik / Riser"),
    TrendAudio("snd_4", "Energetic Tech Review Theme", "AudioStock Pro", 45, "520K Video", "+140%", "Elektronik / Vlog"),
    TrendAudio("snd_5", "Motivational Cinematic Piano", "Eleven Orchestral", 50, "980K Video", "+320%", "Motivasyon / Shorts"),
    TrendAudio("snd_6", "Retro 80s Cyberpunk Bass", "Synthwave Club", 32, "430K Video", "+95%", "Retro Wave")
  )

  val sampleSfxPresets: List<SfxPreset> = listOf(
    SfxPreset("sfx_1", "Sinematik Whoosh Geçiş", "Geçiş", "💨"),
    SfxPreset("sfx_2", "Derin Bas Boom / Hit", "Vuruş", "💥"),
    SfxPreset("sfx_3", "Yükselen Gerilim (Riser)", "Riser", "⚡"),
    SfxPreset("sfx_4", "Pop / Bildirim Sesi", "UI", "✨"),
    SfxPreset("sfx_5", "Kamera Obtüratör Klik", "Mekanik", "📸"),
    SfxPreset("sfx_6", "Glitch / Dijital Bozulma", "Siber", "👾")
  )

  fun addRenderJob(job: RenderJob) {
    _activeRenderJobs.value = listOf(job) + _activeRenderJobs.value
  }
}

