package com.example.data.model

enum class AspectRatioType(val title: String, val ratio: Float, val label: String, val iconDesc: String) {
  PORTRAIT_9_16("9:16 Dikey", 9f / 16f, "Reels / TikTok / Shorts", "Dikey Mobil Video"),
  LANDSCAPE_16_9("16:9 Yatay", 16f / 9f, "YouTube / 4K Sinematik", "Geniş Format Video"),
  SQUARE_1_1("1:1 Kare", 1f, "Instagram Feed / Post", "Kare Grafik / Video")
}

enum class StudioEditorMode(val title: String, val subtitle: String) {
  VIDEO_CAPCUT("Video Kurgu (CapCut)", "Çoklu İz Timeline, Geçişler ve Altyazı"),
  GRAPHIC_CANVA("Grafik Tasarım (Canva)", "Katmanlar, Vektörler, Metin ve Filtreler"),
  DUAL_SYNC("İkili Eşzamanlı", "9:16 ve 16:9 Canlı Çoklu Önizleme")
}

enum class LayerType(val title: String, val iconName: String) {
  TEXT("Metin Katmanı", "TextFields"),
  STICKER("Vektörel Çıkartma", "Stars"),
  IMAGE("Görsel Katman", "Image"),
  SHAPE("Geometrik Şekil", "Category"),
  EFFECT("Görsel Filtre (LUT)", "AutoFixHigh")
}

enum class CanvaCategory(val title: String, val iconEmoji: String, val subtitle: String) {
  SEARCH("Ara", "🔍", "Tüm Kütüphanede Ara"),
  TEMPLATES("Şablonlar", "🧩", "Shorts, Reels & Banner Şablonları"),
  IMAGES("Görseller", "🖼️", "Stok Fotoğraflar & Flux.1 AI"),
  VIDEOS("Videolar", "🎥", "10 Klip AI Video Havuzu"),
  TEXT("Metin & Tipografi", "🅰️", "Başlıklar & Tipografik Stiller"),
  STICKERS("Çıkartma & Elementler", "🎨", "Vektör Objeler & Neon Rozetler"),
  UPLOADS("Yüklenen Medyalar", "📤", "Cihazdan Yüklenen Medyalar")
}

data class GraphicLayer(
  val id: String,
  val title: String,
  val type: LayerType,
  val content: String,
  val x: Float = 0.5f,
  val y: Float = 0.5f,
  val scale: Float = 1f,
  val rotation: Float = 0f,
  val colorHex: Long = 0xFFFFFFFF,
  val isVisible: Boolean = true
)

data class CaptionWord(
  val word: String,
  val startMs: Long,
  val endMs: Long
)

data class VideoScene(
  val id: String,
  val title: String,
  val durationSeconds: Float,
  val prompt: String,
  val aiModel: String,
  val primaryColorHex: Long = 0xFF00D2FF,
  val secondaryColorHex: Long = 0xFFA855F7,
  val visualEffect: String = "Siber Işıklar",
  val motionType: String = "Dinamik İleri Uçuş",
  val autoReframeTargetX: Float = 0.5f,
  val transitionEffect: String = "Çapraz Geçiş (Crossfade)"
)

data class TimelineClip(
  val id: String,
  val sceneId: String,
  val startMs: Long,
  val durationMs: Long,
  val name: String,
  val colorHex: Long,
  val transitionType: String = "Crossfade"
)

data class VoiceoverTrack(
  val id: String,
  val speakerName: String,
  val language: String,
  val scriptText: String,
  val durationMs: Long,
  val words: List<CaptionWord>
)

data class VideoProject(
  val id: String,
  val title: String,
  val currentAspect: AspectRatioType = AspectRatioType.PORTRAIT_9_16,
  val scenes: List<VideoScene>,
  val graphicLayers: List<GraphicLayer> = emptyList(),
  val voiceover: VoiceoverTrack,
  val subtitleStyle: String = "Karaoke Neon",
  val autoReframeEnabled: Boolean = true,
  val smartBackgroundRemoved: Boolean = false,
  val totalDurationSeconds: Float = 120f,
  val maxQuota: Int = 10,
  val currentQuotaCount: Int = 10
)

data class TemplateItem(
  val id: String,
  val title: String,
  val category: String,
  val aspectType: AspectRatioType,
  val dimensions: String,
  val badgeText: String? = null,
  val isPro: Boolean = false,
  val usageCount: String = "12.4K",
  val gradientStartHex: Long = 0xFF7C3AED,
  val gradientEndHex: Long = 0xFF2563EB,
  val iconEmoji: String = "✨",
  val tags: List<String> = emptyList()
)

data class RecentProjectCard(
  val id: String,
  val title: String,
  val aspectType: AspectRatioType,
  val durationSeconds: Int,
  val lastEdited: String,
  val sceneCount: Int = 10,
  val resolution: String = "4K / 1080p",
  val primaryColorHex: Long = 0xFF7C3AED,
  val secondaryColorHex: Long = 0xFF2563EB,
  val isAiGenerated: Boolean = true
)

data class TrendAudio(
  val id: String,
  val title: String,
  val artist: String,
  val durationSec: Int,
  val usageCount: String,
  val growthPercent: String,
  val category: String,
  val isTrendingNow: Boolean = true,
  val isSaved: Boolean = false,
  val isPlaying: Boolean = false,
  val waveformPoints: List<Float> = listOf(0.2f, 0.5f, 0.9f, 0.4f, 0.8f, 1f, 0.7f, 0.85f, 0.45f, 0.9f, 0.35f, 0.2f)
)

data class BatchShortsAutomation(
  val id: String,
  val title: String,
  val totalDays: Int = 30,
  val completedDays: Int = 14,
  val topicPrompt: String = "Finans & Girişimcilik Motivasyon Sözleri",
  val targetPlatform: String = "TikTok + Shorts + Reels (9:16)",
  val fontStyle: String = "Neon Sarı & Kalın Siyah Kontur",
  val voiceModel: String = "ElevenLabs - Adam (Türkçe)",
  val isAutomatedPosting: Boolean = true
)

data class VoiceCloneState(
  val isRecording: Boolean = false,
  val sampleSecondsRecorded: Int = 10,
  val cloneStatus: String = "Hazır (%99 Doğruluk)",
  val clonedVoiceName: String = "Baysal AI (Doğal Türkçe)",
  val sampleAudioUrl: String = "",
  val isNoiseCleanupActive: Boolean = true,
  val backgroundNoiseReductionDb: Int = -32
)

data class VideoUpscaleState(
  val isUpscaling: Boolean = false,
  val progress: Float = 0f,
  val sourceResolution: String = "720p / 1080p",
  val targetResolution: String = "4K UHD (3840x2160 @ 60 FPS)",
  val modelEngine: String = "Real-ESRGAN v3 (TensorRT GPU)",
  val sharpnessLevel: Float = 0.85f,
  val isCompleted: Boolean = false
)

data class SocialPlatformPost(
  val platform: String,
  val iconEmoji: String,
  val isConnected: Boolean = true,
  val scheduledTime: String = "Bugün 18:30 (En Yüksek Etkileşim)",
  val autoHashtags: List<String> = listOf("#viral", "#fyp", "#aivideo", "#shorts", "#reels"),
  val status: String = "Kuyrukta (Otomatik Zamanlandı)"
)

data class LipSyncConfig(
  val targetLanguage: String = "İngilizce (ABD)",
  val preserveOriginalTone: Boolean = true,
  val dynamicMouthMovement: Boolean = true,
  val confidenceScore: Float = 0.98f
)

data class SfxPreset(
  val id: String,
  val name: String,
  val category: String,
  val emoji: String,
  val timestampMs: Long = 0L
)

