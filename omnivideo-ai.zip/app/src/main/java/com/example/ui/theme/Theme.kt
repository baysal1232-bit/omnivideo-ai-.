package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
  primary = NeonCyan,
  onPrimary = DarkBg,
  primaryContainer = DarkCardElevated,
  onPrimaryContainer = NeonCyan,
  secondary = CyberPurple,
  onSecondary = TextPrimary,
  secondaryContainer = DeepViolet,
  onSecondaryContainer = TextPrimary,
  tertiary = RadiantGold,
  onTertiary = DarkBg,
  background = DarkBg,
  onBackground = TextPrimary,
  surface = DarkSurface,
  onSurface = TextPrimary,
  surfaceVariant = DarkCard,
  onSurfaceVariant = TextSecondary,
  outline = DarkCardBorder,
  error = CoralRed
)

private val LightColorScheme = lightColorScheme(
  primary = CanvaPurple,
  onPrimary = LightSurface,
  primaryContainer = LightCardElevated,
  onPrimaryContainer = CanvaPurple,
  secondary = CanvaBlue,
  onSecondary = LightSurface,
  secondaryContainer = CanvaIndigo,
  onSecondaryContainer = LightSurface,
  tertiary = CanvaGold,
  onTertiary = LightSurface,
  background = LightBg,
  onBackground = LightTextPrimary,
  surface = LightSurface,
  onSurface = LightTextPrimary,
  surfaceVariant = LightCardElevated,
  onSurfaceVariant = LightTextSecondary,
  outline = LightCardBorder,
  error = CoralRed
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false,
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window
      window?.let {
        val bg = if (darkTheme) DarkBg else LightBg
        it.statusBarColor = bg.toArgb()
        it.navigationBarColor = bg.toArgb()
        val controller = WindowCompat.getInsetsController(it, view)
        controller.isAppearanceLightStatusBars = !darkTheme
        controller.isAppearanceLightNavigationBars = !darkTheme
      }
    }
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
