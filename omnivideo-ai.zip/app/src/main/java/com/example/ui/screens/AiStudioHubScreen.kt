package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.StudioSubTab
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun AiStudioHubScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val isDark = uiState.isDarkTheme

  val bgColor = if (isDark) DarkBg else LightBg
  val surfaceColor = if (isDark) DarkSurface else LightSurface
  val textPrimary = if (isDark) TextPrimary else LightTextPrimary
  val textSecondary = if (isDark) TextSecondary else LightTextSecondary

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(bgColor)
  ) {
    // Üst Stüdyo Alt Sekme Seçici
    Surface(
      color = surfaceColor,
      tonalElevation = 2.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        StudioSubTab.values().forEach { subTab ->
          val isSelected = uiState.activeStudioSubTab == subTab
          Surface(
            onClick = { viewModel.setStudioSubTab(subTab) },
            shape = RoundedCornerShape(20.dp),
            color = if (isSelected) CanvaPurple else (if (isDark) DarkCardElevated else LightCardElevated),
            modifier = Modifier
              .weight(1f)
              .testTag("studio_tab_${subTab.name.lowercase()}")
          ) {
            Box(
              modifier = Modifier.padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = subTab.title,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else textSecondary,
                maxLines = 1
              )
            }
          }
        }
      }
    }

    // Seçili Alt Sekme İçeriği
    Box(modifier = Modifier.fillMaxSize()) {
      when (uiState.activeStudioSubTab) {
        StudioSubTab.DUAL_TIMELINE -> {
          DualStudioScreen(viewModel = viewModel)
        }
        StudioSubTab.AI_ENGINES -> {
          AiGenerationScreen(viewModel = viewModel)
        }
        StudioSubTab.AUTOMATION -> {
          AiGenerationScreen(viewModel = viewModel)
        }
        StudioSubTab.AUDIO_VOICE -> {
          // Doğrudan ses ve altyazı odaklı AI Generation ekranı
          AiGenerationScreen(viewModel = viewModel)
        }
      }
    }
  }
}
