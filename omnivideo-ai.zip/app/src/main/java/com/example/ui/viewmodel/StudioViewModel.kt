package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.VideoRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class MainNavigationTab(val title: String, val iconName: String) {
  HOME("Ana Sayfa", "Home"),
  DESIGNS("Tasarımlar", "Folder"),
  AI_STUDIO("AI Stüdyo", "AutoAwesome"),
  TRENDS("Trendler", "TrendingUp"),
  SETTINGS("Ayarlar", "Settings");

  companion object {
    val TEMPLATES: MainNavigationTab get() = TRENDS
    val MORE: MainNavigationTab get() = SETTINGS
    val DUAL_STUDIO: MainNavigationTab get() = AI_STUDIO
    val AI_GENERATION: MainNavigationTab get() = AI_STUDIO
    val PRICING_PLANS: MainNavigationTab get() = SETTINGS
    val INFOGRAPHIC_3D: MainNavigationTab get() = SETTINGS
    val RENDER_PIPELINE: MainNavigationTab get() = SETTINGS
  }
}

enum class StudioSubTab(val title: String) {
  DUAL_TIMELINE("🎬 Kurgu & Katmanlar"),
  AI_ENGINES("🪄 AI Video Modelleri"),
  AUTOMATION("⚡ Otomasyon & Lip-Sync"),
  AUDIO_VOICE("🎙️ ElevenLabs & Whisper")
}

enum class MoreSubTab(val title: String) {
  OVERVIEW("Genel Bakış"),
  PRICING("👑 Planınızı Yükseltin"),
  ARCHITECTURE_3D("🏛️ 3B Mimarisi"),
  RENDER_GPU("⚡ Render & GPU")
}

data class StudioUiState(
  val currentTab: MainNavigationTab = MainNavigationTab.HOME,
  val isDarkTheme: Boolean = true,
  val userName: String = "Baysal",
  val homeSearchQuery: String = "",
  val homeFilterTag: String = "Tümü",
  val showCustomSizeDialog: Boolean = false,
  val customWidthPx: Int = 1080,
  val customHeightPx: Int = 1920,
  val showQuickCreateSheet: Boolean = false,
  val activeStudioSubTab: StudioSubTab = StudioSubTab.DUAL_TIMELINE,
  val activeMoreSubTab: MoreSubTab = MoreSubTab.OVERVIEW,
  val currentProject: VideoProject,
  val currentAspect: AspectRatioType = AspectRatioType.PORTRAIT_9_16,
  val editorMode: StudioEditorMode = StudioEditorMode.VIDEO_CAPCUT,
  val isDualSimultaneousView: Boolean = false,
  val isPlaying: Boolean = true,
  val currentPlaybackMs: Long = 3200L,
  val autoReframeActive: Boolean = true,
  val smartBgRemoved: Boolean = false,
  val selectedArchitectureNode: ArchitectureNode? = null,
  val architectureLayerFilter: ArchitectureLayer? = null,
  val selectedAiModel: AiVideoEngine,
  val selectedVoice: ElevenLabsVoice,
  val aiPromptInput: String = "Neon gökdelenler arasında süzülen siber araçlar, yağmurlu asfalt yansımaları, 8k sinematik ışıklandırma",
  val cameraMotion: String = "Drone İleri Uçuş",
  val isGeneratingAiVideo: Boolean = false,
  val isGeneratingFluxImage: Boolean = false,
  val aiGenerationProgress: Float = 0f,
  // 10 Video Üretim Kotası & Batch Generation
  val remainingVideoQuota: Int = 10,
  val maxVideoQuota: Int = 10,
  val isBatchGenerating: Boolean = false,
  val batchProgress: Float = 0f,
  val batchCurrentSceneIndex: Int = 0,
  val batchStatusMessage: String = "",
  val selectedTransitionEffect: String = "Çapraz Geçiş (Crossfade)",
  val selectedColorFilter: String = "Siber Neon",
  val activeRenderModal: Boolean = false,
  val selectedRenderResolution: String = "4K Ultra HD (3840x2160)",
  val selectedRenderCodec: String = "HEVC / H.265 (Donanım NVENC)",
  val isExportingBothFormats: Boolean = true,
  // CANVA COMPONENT LIBRARY STATE
  val canvaActiveCategory: CanvaCategory = CanvaCategory.TEMPLATES,
  val selectedLayerId: String? = null,
  // MONETIZATION & SUBSCRIPTION STATE
  val userTier: SubscriptionTier = SubscriptionTier.FREE,
  val aiCredits: Int = 85,
  val dailyFreeAiUsageRemaining: Int = 2,
  val dailyFreeAiUsageMax: Int = 2,
  val activeBillingCycle: BillingCycle = BillingCycle.YEARLY,
  val activePricingDialog: Boolean = false,
  val activePricingFeatureContext: String? = null,
  // OTOMASYON, SES KLONLAMA, LIP-SYNC, SFX & TRENDLER
  val trendAudios: List<TrendAudio> = emptyList(),
  val activePlayingAudioId: String? = null,
  val batchShortsAutomation: BatchShortsAutomation = BatchShortsAutomation("batch_1", "30 Günlük Otomatik Shorts"),
  val voiceCloneState: VoiceCloneState = VoiceCloneState(),
  val lipSyncConfig: LipSyncConfig = LipSyncConfig(),
  val appliedSfxList: List<SfxPreset> = emptyList(),
  val showBatchAutomationDialog: Boolean = false,
  val showVoiceCloneDialog: Boolean = false,
  val showLipSyncDialog: Boolean = false,
  val showAutoSfxDialog: Boolean = false,
  val showRembgDialog: Boolean = false,
  val canvasDragOffsetX: Float = 0f,
  val canvasDragOffsetY: Float = 0f,
  val videoUpscaleState: VideoUpscaleState = VideoUpscaleState(),
  val showUpscaleDialog: Boolean = false,
  val socialPlatforms: List<SocialPlatformPost> = listOf(
    SocialPlatformPost("TikTok", "🎵", true, "Bugün 18:30", listOf("#fyp", "#viral", "#keşfet")),
    SocialPlatformPost("Instagram Reels", "📸", true, "Bugün 19:00", listOf("#reels", "#aivideo", "#trend")),
    SocialPlatformPost("YouTube Shorts", "▶️", true, "Bugün 20:00", listOf("#shorts", "#yapayzeka", "#4k"))
  ),
  val showSocialShareDialog: Boolean = false,
  val toastMessage: String? = null
) {
  val hasWatermark: Boolean
    get() = userTier == SubscriptionTier.FREE

  val isProUser: Boolean
    get() = userTier == SubscriptionTier.PRO_VIP
}

class StudioViewModel(
  private val repository: VideoRepository = VideoRepository()
) : ViewModel() {

  private val _uiState: MutableStateFlow<StudioUiState>
  val uiState: StateFlow<StudioUiState>

  private var playbackJob: Job? = null
  private var generationJob: Job? = null
  private var batchJob: Job? = null
  private var renderSimJob: Job? = null

  val architectureNodes = repository.architectureNodes
  val aiEngines = repository.aiEngines
  val voices = repository.elevenLabsVoices
  val activeRenderJobs = repository.activeRenderJobs
  val creditPackages = repository.creditPackages
  val featureComparisons = repository.featureComparisons
  val popularTemplates = repository.popularTemplates
  val recentProjects = repository.recentProjects
  val trendAudios = repository.trendAudios
  val sampleSfxPresets = repository.sampleSfxPresets

  fun repositoryTrendAudios() = repository.trendAudios

  init {
    val initialProject = repository.sampleProjects.first()
    _uiState = MutableStateFlow(
      StudioUiState(
        currentProject = initialProject,
        selectedAiModel = repository.aiEngines.first(),
        selectedVoice = repository.elevenLabsVoices.first(),
        selectedArchitectureNode = repository.architectureNodes.first(),
        trendAudios = repository.trendAudios
      )
    )
    uiState = _uiState.asStateFlow()
    startPlaybackLoop()
  }

  fun toggleTrendAudioPlayback(audioId: String) {
    val current = _uiState.value.activePlayingAudioId
    val next = if (current == audioId) null else audioId
    _uiState.value = _uiState.value.copy(activePlayingAudioId = next)
    if (next != null) {
      val item = repository.trendAudios.find { it.id == audioId }
      showToast("Trend Ses Çalınıyor: ${item?.title ?: ""}")
    }
  }

  fun applyTrendAudioToTimeline(audio: TrendAudio) {
    _uiState.value = _uiState.value.copy(
      currentTab = MainNavigationTab.AI_STUDIO,
      activeStudioSubTab = StudioSubTab.DUAL_TIMELINE,
      activePlayingAudioId = audio.id
    )
    showToast("'${audio.title}' Proje Zaman Çizelgesine Ses İzi Olarak Eklendi!")
  }

  fun openBatchAutomationDialog(open: Boolean) {
    _uiState.value = _uiState.value.copy(showBatchAutomationDialog = open)
  }

  fun startBatchShortsGeneration() {
    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(showBatchAutomationDialog = false)
      showToast("🚀 30 Günlük Shorts Otomasyonu Başlatıldı! CSV/TXT işleniyor...")
      delay(1200)
      showToast("✅ 30 Sahne ve Altyazı Otomatik Olarak Kurgulandı!")
    }
  }

  fun openVoiceCloneDialog(open: Boolean) {
    _uiState.value = _uiState.value.copy(showVoiceCloneDialog = open)
  }

  fun startVoiceRecording() {
    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(
        voiceCloneState = _uiState.value.voiceCloneState.copy(isRecording = true, sampleSecondsRecorded = 0)
      )
      for (i in 1..10) {
        delay(300)
        _uiState.value = _uiState.value.copy(
          voiceCloneState = _uiState.value.voiceCloneState.copy(sampleSecondsRecorded = i)
        )
      }
      _uiState.value = _uiState.value.copy(
        voiceCloneState = _uiState.value.voiceCloneState.copy(
          isRecording = false,
          cloneStatus = "Hazır (%99.4 Benzerlik - Türkçe TTS Aktif)"
        )
      )
      showToast("🎙️ 10 Saniyeden AI Ses Klonlama Tamamlandı! ElevenLabs motoruna bağlandı.")
    }
  }

  fun openLipSyncDialog(open: Boolean) {
    _uiState.value = _uiState.value.copy(showLipSyncDialog = open)
  }

  fun applyLipSync(targetLang: String) {
    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(
        lipSyncConfig = _uiState.value.lipSyncConfig.copy(targetLanguage = targetLang),
        showLipSyncDialog = false
      )
      showToast("🗣️ Dudak Senkronu Uygulanıyor: Video $targetLang diline çevrildi ve ağız hareketleri senkronlandı!")
    }
  }

  fun openAutoSfxDialog(open: Boolean) {
    _uiState.value = _uiState.value.copy(showAutoSfxDialog = open)
  }

  fun applyAutoSfx(preset: SfxPreset) {
    val current = _uiState.value.appliedSfxList
    _uiState.value = _uiState.value.copy(
      appliedSfxList = current + preset,
      showAutoSfxDialog = false
    )
    showToast("🎵 Otomatik SFX Eklendi: ${preset.name}")
  }

  fun openRembgDialog(open: Boolean) {
    _uiState.value = _uiState.value.copy(showRembgDialog = open)
  }

  fun toggleRembg() {
    val next = !_uiState.value.smartBgRemoved
    _uiState.value = _uiState.value.copy(smartBgRemoved = next)
    showToast(if (next) "🪄 AI Arka Plan Silme (rembg) Aktif!" else "Arka Plan Geri Yüklendi")
  }

  fun updateCanvasDrag(dx: Float, dy: Float) {
    _uiState.value = _uiState.value.copy(
      canvasDragOffsetX = (_uiState.value.canvasDragOffsetX + dx).coerceIn(-300f, 300f),
      canvasDragOffsetY = (_uiState.value.canvasDragOffsetY + dy).coerceIn(-300f, 300f)
    )
  }

  fun resetCanvasDrag() {
    _uiState.value = _uiState.value.copy(canvasDragOffsetX = 0f, canvasDragOffsetY = 0f)
  }

  fun trigger4kExport() {
    if (_uiState.value.userTier == SubscriptionTier.FREE) {
      openPricingDialog("4K Ultra HD Filigransız Export")
    } else {
      openRenderModal()
    }
  }

  fun openSocialShareDialog(open: Boolean) {
    _uiState.value = _uiState.value.copy(showSocialShareDialog = open)
  }

  fun startSocialAutoPost() {
    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(showSocialShareDialog = false)
      showToast("🚀 TikTok, Reels ve Shorts için otomatik paylaşım kuyruğa alındı!")
    }
  }

  fun openUpscaleDialog(open: Boolean) {
    _uiState.value = _uiState.value.copy(showUpscaleDialog = open)
  }

  fun start4kUpscale() {
    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(
        videoUpscaleState = _uiState.value.videoUpscaleState.copy(isUpscaling = true, progress = 0.1f)
      )
      showToast("⚡ Real-ESRGAN v3 ile 4K AI Upscale başlatıldı...")
      for (i in 1..10) {
        delay(150)
        _uiState.value = _uiState.value.copy(
          videoUpscaleState = _uiState.value.videoUpscaleState.copy(progress = i / 10f)
        )
      }
      _uiState.value = _uiState.value.copy(
        videoUpscaleState = _uiState.value.videoUpscaleState.copy(isUpscaling = false, isCompleted = true),
        showUpscaleDialog = false
      )
      showToast("✅ Video başarıyla 4K UHD (3840x2160 @ 60 FPS) çözünürlüğe yükseltildi!")
    }
  }

  fun toggleNoiseCleanup() {
    val current = _uiState.value.voiceCloneState.isNoiseCleanupActive
    _uiState.value = _uiState.value.copy(
      voiceCloneState = _uiState.value.voiceCloneState.copy(isNoiseCleanupActive = !current)
    )
    showToast(if (!current) "🎙️ AI Gürültü Temizleme Aktif (-32dB arkaplan gürültüsü silindi)" else "Gürültü filtresi kapatıldı")
  }

  fun setTab(tab: MainNavigationTab) {
    _uiState.value = _uiState.value.copy(currentTab = tab)
  }

  fun toggleTheme() {
    val nextTheme = !_uiState.value.isDarkTheme
    _uiState.value = _uiState.value.copy(isDarkTheme = nextTheme)
    showToast(if (nextTheme) "Koyu Tema Aktif" else "Canva Açık Tema Aktif")
  }

  fun setDarkTheme(dark: Boolean) {
    _uiState.value = _uiState.value.copy(isDarkTheme = dark)
  }

  fun setHomeSearchQuery(query: String) {
    _uiState.value = _uiState.value.copy(homeSearchQuery = query)
  }

  fun setHomeFilterTag(tag: String) {
    _uiState.value = _uiState.value.copy(homeFilterTag = tag)
  }

  fun openCustomSizeDialog(open: Boolean) {
    _uiState.value = _uiState.value.copy(showCustomSizeDialog = open)
  }

  fun setCustomDimensions(w: Int, h: Int) {
    _uiState.value = _uiState.value.copy(customWidthPx = w, customHeightPx = h)
  }

  fun startCustomSizeProject() {
    val w = _uiState.value.customWidthPx
    val h = _uiState.value.customHeightPx
    val aspect = if (h > w) AspectRatioType.PORTRAIT_9_16 else if (w > h) AspectRatioType.LANDSCAPE_16_9 else AspectRatioType.SQUARE_1_1
    _uiState.value = _uiState.value.copy(
      showCustomSizeDialog = false,
      currentAspect = aspect,
      currentTab = MainNavigationTab.AI_STUDIO
    )
    showToast("Özel Boyutlu Proje Açıldı (${w}x${h} px)")
  }

  fun setQuickCreateSheet(open: Boolean) {
    _uiState.value = _uiState.value.copy(showQuickCreateSheet = open)
  }

  fun launchNewVideo(aspect: AspectRatioType) {
    _uiState.value = _uiState.value.copy(
      currentAspect = aspect,
      currentTab = MainNavigationTab.AI_STUDIO,
      activeStudioSubTab = StudioSubTab.DUAL_TIMELINE,
      editorMode = StudioEditorMode.VIDEO_CAPCUT
    )
    showToast("${aspect.title} Video Projesi Başlatıldı")
  }

  fun launchGraphicEditor() {
    _uiState.value = _uiState.value.copy(
      currentTab = MainNavigationTab.AI_STUDIO,
      activeStudioSubTab = StudioSubTab.DUAL_TIMELINE,
      editorMode = StudioEditorMode.GRAPHIC_CANVA
    )
    showToast("Canva Stili Görsel Editör Başlatıldı")
  }

  fun launchAiVideoBatch() {
    _uiState.value = _uiState.value.copy(
      currentTab = MainNavigationTab.AI_STUDIO,
      activeStudioSubTab = StudioSubTab.AI_ENGINES
    )
    triggerBatchGeneration10Scenes("Siber Metropol & Gelecek")
  }

  fun openTemplate(template: TemplateItem) {
    _uiState.value = _uiState.value.copy(
      currentAspect = template.aspectType,
      currentTab = MainNavigationTab.AI_STUDIO,
      activeStudioSubTab = StudioSubTab.DUAL_TIMELINE
    )
    showToast("Şablon Yüklendi: ${template.title}")
  }

  fun openRecentProject(project: RecentProjectCard) {
    _uiState.value = _uiState.value.copy(
      currentAspect = project.aspectType,
      currentTab = MainNavigationTab.AI_STUDIO,
      activeStudioSubTab = StudioSubTab.DUAL_TIMELINE
    )
    showToast("Tasarıma Devam Ediliyor: ${project.title}")
  }

  fun setStudioSubTab(subTab: StudioSubTab) {
    _uiState.value = _uiState.value.copy(activeStudioSubTab = subTab)
  }

  fun setMoreSubTab(subTab: MoreSubTab) {
    _uiState.value = _uiState.value.copy(activeMoreSubTab = subTab)
  }

  fun setUserTier(tier: SubscriptionTier) {
    _uiState.value = _uiState.value.copy(userTier = tier)
    if (tier == SubscriptionTier.PRO_VIP) {
      showToast("Tebrikler! Pro VIP Stüdyo Aktif: Filigran kaldırıldı, 4K ve 10 sahne batch açıldı!")
    } else {
      showToast("Ücretsiz Plan Aktif: 1080p sınırı ve köşe filigranı geçerli.")
    }
  }

  fun toggleUserTier() {
    val next = if (_uiState.value.userTier == SubscriptionTier.FREE) SubscriptionTier.PRO_VIP else SubscriptionTier.FREE
    setUserTier(next)
  }

  fun setBillingCycle(cycle: BillingCycle) {
    _uiState.value = _uiState.value.copy(activeBillingCycle = cycle)
  }

  fun purchaseCredits(pkg: CreditPackage) {
    val updated = _uiState.value.aiCredits + pkg.credits
    _uiState.value = _uiState.value.copy(aiCredits = updated)
    showToast("${pkg.credits} AI Kredisi Hesabınıza Eklendi! Toplam: $updated Kredi")
  }

  fun openPricingDialog(featureContext: String? = null) {
    _uiState.value = _uiState.value.copy(
      activePricingDialog = true,
      activePricingFeatureContext = featureContext
    )
  }

  fun closePricingDialog() {
    _uiState.value = _uiState.value.copy(
      activePricingDialog = false,
      activePricingFeatureContext = null
    )
  }

  fun setEditorMode(mode: StudioEditorMode) {
    _uiState.value = _uiState.value.copy(editorMode = mode)
    if (mode == StudioEditorMode.DUAL_SYNC) {
      _uiState.value = _uiState.value.copy(isDualSimultaneousView = true)
    }
    showToast("Mod değiştirildi: ${mode.title}")
  }

  fun togglePlayback() {
    val newPlaying = !_uiState.value.isPlaying
    _uiState.value = _uiState.value.copy(isPlaying = newPlaying)
    if (newPlaying) {
      startPlaybackLoop()
    } else {
      playbackJob?.cancel()
    }
  }

  fun seekPlayback(targetMs: Long) {
    val totalMs = (_uiState.value.currentProject.totalDurationSeconds * 1000).toLong()
    val clamped = targetMs.coerceIn(0L, totalMs)
    _uiState.value = _uiState.value.copy(currentPlaybackMs = clamped)
  }

  fun setAspectRatio(aspectRatio: AspectRatioType) {
    _uiState.value = _uiState.value.copy(
      currentAspect = aspectRatio,
      isDualSimultaneousView = false
    )
  }

  fun toggleDualSimultaneousView() {
    val newDual = !_uiState.value.isDualSimultaneousView
    _uiState.value = _uiState.value.copy(
      isDualSimultaneousView = newDual,
      editorMode = if (newDual) StudioEditorMode.DUAL_SYNC else StudioEditorMode.VIDEO_CAPCUT
    )
  }

  fun toggleAutoReframe() {
    if (!_uiState.value.isProUser) {
      openPricingDialog("Akıllı Kadrajlama (Auto-Reframe)")
      return
    }
    val updated = !_uiState.value.autoReframeActive
    _uiState.value = _uiState.value.copy(autoReframeActive = updated)
    showToast(if (updated) "Akıllı Auto-Reframe (Yüz & Nesne Takibi) Aktif" else "Auto-Reframe Devre Dışı")
  }

  fun toggleSmartBgRemoved() {
    if (!_uiState.value.isProUser) {
      openPricingDialog("Tek Tıkla Arka Plan Silme (rembg)")
      return
    }
    val updated = !_uiState.value.smartBgRemoved
    _uiState.value = _uiState.value.copy(smartBgRemoved = updated)
    showToast(if (updated) "AI rembg ile Arka Plan Silindi (Şeffaf Katman)" else "Orijinal Arka Plan Gösteriliyor")
  }

  fun selectArchitectureNode(node: ArchitectureNode?) {
    _uiState.value = _uiState.value.copy(selectedArchitectureNode = node)
  }

  fun setArchitectureLayerFilter(layer: ArchitectureLayer?) {
    _uiState.value = _uiState.value.copy(architectureLayerFilter = layer)
  }

  fun setAiPrompt(prompt: String) {
    _uiState.value = _uiState.value.copy(aiPromptInput = prompt)
  }

  fun selectAiModel(model: AiVideoEngine) {
    _uiState.value = _uiState.value.copy(selectedAiModel = model)
  }

  fun selectVoice(voice: ElevenLabsVoice) {
    _uiState.value = _uiState.value.copy(selectedVoice = voice)
  }

  fun setCameraMotion(motion: String) {
    _uiState.value = _uiState.value.copy(cameraMotion = motion)
  }

  fun setTransitionEffect(effect: String) {
    _uiState.value = _uiState.value.copy(selectedTransitionEffect = effect)
    showToast("CapCut geçiş efekti seçildi: $effect")
  }

  fun setColorFilter(filterName: String) {
    _uiState.value = _uiState.value.copy(selectedColorFilter = filterName)
    showToast("Görsel LUT Filtresi uygulandı: $filterName")
  }

  fun addGraphicLayer(title: String, type: LayerType, content: String, colorHex: Long) {
    val newLayer = GraphicLayer(
      id = "layer_${System.currentTimeMillis()}",
      title = title,
      type = type,
      content = content,
      x = 0.5f,
      y = 0.5f,
      colorHex = colorHex
    )
    val updatedList = _uiState.value.currentProject.graphicLayers + newLayer
    _uiState.value = _uiState.value.copy(
      currentProject = _uiState.value.currentProject.copy(graphicLayers = updatedList)
    )
    showToast("Canva katmanı eklendi: $title")
  }

  fun toggleLayerVisibility(layerId: String) {
    val updated = _uiState.value.currentProject.graphicLayers.map {
      if (it.id == layerId) it.copy(isVisible = !it.isVisible) else it
    }
    _uiState.value = _uiState.value.copy(
      currentProject = _uiState.value.currentProject.copy(graphicLayers = updated)
    )
  }

  fun deleteGraphicLayer(layerId: String) {
    val updated = _uiState.value.currentProject.graphicLayers.filter { it.id != layerId }
    _uiState.value = _uiState.value.copy(
      currentProject = _uiState.value.currentProject.copy(graphicLayers = updated),
      selectedLayerId = if (_uiState.value.selectedLayerId == layerId) null else _uiState.value.selectedLayerId
    )
    showToast("Katman silindi")
  }

  fun selectCanvaCategory(cat: CanvaCategory) {
    _uiState.value = _uiState.value.copy(canvaActiveCategory = cat)
  }

  fun selectLayerForEditing(layerId: String?) {
    _uiState.value = _uiState.value.copy(selectedLayerId = layerId)
  }

  fun updateLayerTransform(layerId: String, scale: Float, rotation: Float, x: Float = 0.5f, y: Float = 0.5f) {
    val updated = _uiState.value.currentProject.graphicLayers.map {
      if (it.id == layerId) it.copy(scale = scale, rotation = rotation, x = x, y = y) else it
    }
    _uiState.value = _uiState.value.copy(
      currentProject = _uiState.value.currentProject.copy(graphicLayers = updated)
    )
  }

  fun refillQuota() {
    _uiState.value = _uiState.value.copy(remainingVideoQuota = 10)
    showToast("10/10 Video Oluşturma Kotası Yenilendi!")
  }

  fun triggerBatchGeneration10Scenes(scenarioTheme: String = "Siber Metropol & Gelecek") {
    // Check quota / tier
    if (!_uiState.value.isProUser) {
      if (_uiState.value.dailyFreeAiUsageRemaining > 0) {
        _uiState.value = _uiState.value.copy(
          dailyFreeAiUsageRemaining = _uiState.value.dailyFreeAiUsageRemaining - 1
        )
        showToast("Günlük deneme hakkınızdan 1 adet kullanıldı. Kalan: ${_uiState.value.dailyFreeAiUsageRemaining}/2")
      } else if (_uiState.value.aiCredits >= 10) {
        _uiState.value = _uiState.value.copy(
          aiCredits = _uiState.value.aiCredits - 10
        )
        showToast("10 Sahne için 10 AI Kredisi kullanıldı. Kalan: ${_uiState.value.aiCredits}")
      } else {
        openPricingDialog("10 Sahne Toplu AI Üretimi ve Birleştirme")
        return
      }
    }

    if (_uiState.value.isBatchGenerating) return
    batchJob?.cancel()

    _uiState.value = _uiState.value.copy(
      isBatchGenerating = true,
      batchProgress = 0.05f,
      batchCurrentSceneIndex = 1,
      batchStatusMessage = "Senaryo 10 parçaya bölünüyor..."
    )

    batchJob = viewModelScope.launch {
      val models = listOf("Google Veo 2", "OpenAI Sora", "Kling 1.5 Pro", "Wan 2.1", "Seedance Video")
      for (i in 1..10) {
        val modelName = models[(i - 1) % models.size]
        _uiState.value = _uiState.value.copy(
          batchCurrentSceneIndex = i,
          batchProgress = (i - 0.5f) / 10f,
          batchStatusMessage = "Sahne $i/10 üretiliyor [$modelName]..."
        )
        delay(300)
      }

      _uiState.value = _uiState.value.copy(
        batchProgress = 0.95f,
        batchStatusMessage = "Auto-Assemble: 10 klip zaman çizelgesine diziliyor..."
      )
      delay(350)

      val refreshedProject = repository.createSampleProject()
      _uiState.value = _uiState.value.copy(
        isBatchGenerating = false,
        batchProgress = 1f,
        batchStatusMessage = "10 Klip Birleştirildi!",
        currentProject = refreshedProject,
        remainingVideoQuota = 10,
        currentPlaybackMs = 0L,
        isPlaying = true
      )

      showToast("10 Sahne Tek Tıkla Üretildi ve Birleştirildi! (Toplam 2:00 dk)")
    }
  }

  fun triggerGenerateFluxImage() {
    if (_uiState.value.isGeneratingFluxImage) return
    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(isGeneratingFluxImage = true)
      delay(1200)
      _uiState.value = _uiState.value.copy(isGeneratingFluxImage = false)
      addGraphicLayer("Flux.1 Yapay Zeka Görseli", LayerType.IMAGE, "4K Sinematik Arka Plan", 0xFF00D2FF)
      showToast("Flux.1 ile 4K görsel üretildi ve Canva tuvaline katman olarak eklendi!")
    }
  }

  fun triggerGenerateVideo() {
    if (_uiState.value.isGeneratingAiVideo) return
    generationJob?.cancel()
    _uiState.value = _uiState.value.copy(
      isGeneratingAiVideo = true,
      aiGenerationProgress = 0.05f
    )

    generationJob = viewModelScope.launch {
      for (step in 1..20) {
        delay(100)
        val progress = step / 20f
        _uiState.value = _uiState.value.copy(aiGenerationProgress = progress)
      }
      _uiState.value = _uiState.value.copy(
        isGeneratingAiVideo = false,
        aiGenerationProgress = 1f
      )
      showToast("${_uiState.value.selectedAiModel.name} ile video sahnesi üretildi ve zaman çizelgesine eklendi!")
    }
  }

  fun openRenderModal(open: Boolean = true) {
    _uiState.value = _uiState.value.copy(activeRenderModal = open)
  }

  fun setRenderOptions(res: String, codec: String, dualBoth: Boolean) {
    _uiState.value = _uiState.value.copy(
      selectedRenderResolution = res,
      selectedRenderCodec = codec,
      isExportingBothFormats = dualBoth
    )
  }

  fun startExportJob() {
    if (_uiState.value.selectedRenderResolution.contains("4K") && !_uiState.value.isProUser) {
      openPricingDialog("4K Ultra HD (60 FPS) & Filigransız Export")
      return
    }

    val formats = if (_uiState.value.isExportingBothFormats) {
      listOf(AspectRatioType.PORTRAIT_9_16, AspectRatioType.LANDSCAPE_16_9)
    } else {
      listOf(_uiState.value.currentAspect)
    }

    val newJob = RenderJob(
      id = "job_${System.currentTimeMillis()}",
      projectName = _uiState.value.currentProject.title,
      outputAspects = formats,
      resolution = _uiState.value.selectedRenderResolution,
      codec = _uiState.value.selectedRenderCodec,
      progress = 0.05f,
      status = RenderStatus.PROCESSING_CLIENT,
      gpuNode = "CUDA Kümesi #07 (NVIDIA A100)",
      clientWebGpuFps = 60,
      serverNvencSpeed = "4.8x Gerçek Zamanlı",
      cloudStorageUrl = "https://cdn.omnivideo.ai/export/omni_${System.currentTimeMillis()}.mp4"
    )

    repository.addRenderJob(newJob)
    _uiState.value = _uiState.value.copy(activeRenderModal = false)
    showToast(if (_uiState.value.isProUser) "4K Filigransız Render Başlatıldı!" else "1080p Filigranlı Render Başlatıldı!")

    renderSimJob?.cancel()
    renderSimJob = viewModelScope.launch {
      delay(800)
    }
  }

  fun showToast(msg: String) {
    _uiState.value = _uiState.value.copy(toastMessage = msg)
  }

  fun clearToast() {
    _uiState.value = _uiState.value.copy(toastMessage = null)
  }

  private fun startPlaybackLoop() {
    playbackJob?.cancel()
    playbackJob = viewModelScope.launch {
      while (true) {
        delay(50)
        if (_uiState.value.isPlaying) {
          val totalMs = (_uiState.value.currentProject.totalDurationSeconds * 1000).toLong()
          val next = _uiState.value.currentPlaybackMs + 50L
          val looped = if (next >= totalMs) 0L else next
          _uiState.value = _uiState.value.copy(currentPlaybackMs = looped)
        }
      }
    }
  }

  override fun onCleared() {
    super.onCleared()
    playbackJob?.cancel()
    generationJob?.cancel()
    batchJob?.cancel()
    renderSimJob?.cancel()
  }
}
