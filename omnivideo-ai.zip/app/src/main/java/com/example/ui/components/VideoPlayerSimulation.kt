package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun VideoPlayerSimulation(
  project: VideoProject,
  aspectRatio: AspectRatioType,
  currentPlaybackMs: Long,
  isPlaying: Boolean,
  autoReframeActive: Boolean,
  smartBgRemoved: Boolean,
  isDualSimultaneous: Boolean,
  onTogglePlay: () -> Unit,
  modifier: Modifier = Modifier
) {
  if (isDualSimultaneous) {
    // Dual simultaneous view: 9:16 and 16:9 side-by-side
    Column(
      modifier = modifier.fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        GlowingBadge(
          text = "ÇOKLU FORMAT CANLI ÖNİZLEME",
          color = RadiantGold
        )
        Text(
          text = "Sol 9:16 Dikey Mobil • Sağ 16:9 Tuval",
          color = TextSecondary,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
      }

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .height(265.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Vertical 9:16 screen (TikTok / Reels / Shorts)
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
        ) {
          SingleScreenCanvas(
            aspectRatio = AspectRatioType.PORTRAIT_9_16,
            project = project,
            currentPlaybackMs = currentPlaybackMs,
            autoReframeActive = autoReframeActive,
            smartBgRemoved = smartBgRemoved,
            onTogglePlay = onTogglePlay,
            isPlaying = isPlaying,
            badgeLabel = "9:16 Reels/TikTok"
          )
        }

        // Horizontal 16:9 / 1:1 screen (YouTube & Graphic Tuval)
        Box(
          modifier = Modifier
            .weight(1.35f)
            .fillMaxHeight()
        ) {
          SingleScreenCanvas(
            aspectRatio = AspectRatioType.LANDSCAPE_16_9,
            project = project,
            currentPlaybackMs = currentPlaybackMs,
            autoReframeActive = autoReframeActive,
            smartBgRemoved = smartBgRemoved,
            onTogglePlay = onTogglePlay,
            isPlaying = isPlaying,
            badgeLabel = "16:9 YouTube / Grafik Tuvali"
          )
        }
      }
    }
  } else {
    // Single selected aspect ratio display
    Box(
      modifier = modifier
        .fillMaxWidth()
        .height(if (aspectRatio == AspectRatioType.PORTRAIT_9_16) 380.dp else 240.dp),
      contentAlignment = Alignment.Center
    ) {
      SingleScreenCanvas(
        aspectRatio = aspectRatio,
        project = project,
        currentPlaybackMs = currentPlaybackMs,
        autoReframeActive = autoReframeActive,
        smartBgRemoved = smartBgRemoved,
        onTogglePlay = onTogglePlay,
        isPlaying = isPlaying,
        badgeLabel = aspectRatio.title
      )
    }
  }
}

@Composable
fun SingleScreenCanvas(
  aspectRatio: AspectRatioType,
  project: VideoProject,
  currentPlaybackMs: Long,
  autoReframeActive: Boolean,
  smartBgRemoved: Boolean,
  isPlaying: Boolean,
  badgeLabel: String,
  onTogglePlay: () -> Unit
) {
  val currentSec = currentPlaybackMs / 1000f

  // Determine active scene based on time
  val (activeScene, sceneIndex) = remember(currentPlaybackMs) {
    var accumulated = 0f
    var found = project.scenes.first()
    var foundIdx = 0
    for ((idx, s) in project.scenes.withIndex()) {
      if (currentSec >= accumulated && currentSec <= accumulated + s.durationSeconds) {
        found = s
        foundIdx = idx
        break
      }
      accumulated += s.durationSeconds
    }
    Pair(found, foundIdx)
  }

  val primaryColor = Color(activeScene.primaryColorHex)
  val secondaryColor = Color(activeScene.secondaryColorHex)
  val shape = RoundedCornerShape(16.dp)

  Box(
    modifier = Modifier
      .aspectRatio(aspectRatio.ratio)
      .fillMaxHeight()
      .clip(shape)
      .background(DarkBg)
      .border(1.5.dp, Brush.linearGradient(listOf(primaryColor, secondaryColor)), shape)
      .clickable { onTogglePlay() }
      .testTag("video_player_canvas")
  ) {
    // 1. Procedural generative AI video graphics Canvas
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height

      if (smartBgRemoved) {
        // Transparent checkerboard background
        val squareSize = 24f
        var isWhite = false
        var yPos = 0f
        while (yPos < h) {
          var xPos = 0f
          while (xPos < w) {
            drawRect(
              color = if (isWhite) Color(0xFF1E2638) else Color(0xFF121724),
              topLeft = Offset(xPos, yPos),
              size = Size(squareSize, squareSize)
            )
            xPos += squareSize
            isWhite = !isWhite
          }
          yPos += squareSize
          isWhite = !isWhite
        }
      } else {
        // Generative AI sci-fi world background
        drawRect(
          brush = Brush.verticalGradient(
            colors = listOf(
              DarkBg,
              primaryColor.copy(alpha = 0.25f),
              secondaryColor.copy(alpha = 0.4f),
              DarkBg
            )
          )
        )

        // Perspective grid lines (cyber city landscape)
        val horizonY = h * 0.55f
        drawLine(
          color = primaryColor.copy(alpha = 0.5f),
          start = Offset(0f, horizonY),
          end = Offset(w, horizonY),
          strokeWidth = 2f
        )

        // Radial perspective grid vanishing to horizon
        val centerX = w * activeScene.autoReframeTargetX
        for (i in -6..6) {
          val bottomX = centerX + i * (w * 0.12f)
          drawLine(
            color = primaryColor.copy(alpha = 0.25f),
            start = Offset(centerX, horizonY),
            end = Offset(bottomX, h),
            strokeWidth = 1.5f
          )
        }

        // Horizontal scan lines
        for (j in 1..6) {
          val y = horizonY + (h - horizonY) * (j / 6f) * (j / 6f)
          drawLine(
            color = secondaryColor.copy(alpha = 0.25f),
            start = Offset(0f, y),
            end = Offset(w, y),
            strokeWidth = 1f
          )
        }
      }

      // Dynamic Subject / AI Object
      val timeOffset = sin(currentSec * 3f) * 15f
      val subjectCenterX = w * activeScene.autoReframeTargetX
      val subjectCenterY = h * 0.45f + timeOffset

      // Holographic subject orb/silhouette
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            RadiantGold,
            primaryColor,
            Color.Transparent
          ),
          center = Offset(subjectCenterX, subjectCenterY),
          radius = w * 0.28f
        ),
        radius = w * 0.28f,
        center = Offset(subjectCenterX, subjectCenterY)
      )

      drawCircle(
        color = Color.White.copy(alpha = 0.85f),
        radius = 8f,
        center = Offset(subjectCenterX, subjectCenterY)
      )

      // Auto-reframe AI Bounding Box overlay
      if (autoReframeActive) {
        val boxWidth = w * 0.65f
        val boxHeight = h * 0.55f
        val boxLeft = (subjectCenterX - boxWidth / 2f).coerceIn(10f, w - boxWidth - 10f)
        val boxTop = (subjectCenterY - boxHeight / 2f).coerceIn(20f, h - boxHeight - 20f)

        // Draw bounding box
        drawRect(
          color = NeonCyan.copy(alpha = 0.4f),
          topLeft = Offset(boxLeft, boxTop),
          size = Size(boxWidth, boxHeight),
          style = Stroke(width = 1.5f)
        )

        val cornerLen = 18f
        drawLine(NeonCyan, Offset(boxLeft, boxTop), Offset(boxLeft + cornerLen, boxTop), 3.5f)
        drawLine(NeonCyan, Offset(boxLeft, boxTop), Offset(boxLeft, boxTop + cornerLen), 3.5f)
        drawLine(NeonCyan, Offset(boxLeft + boxWidth, boxTop), Offset(boxLeft + boxWidth - cornerLen, boxTop), 3.5f)
        drawLine(NeonCyan, Offset(boxLeft + boxWidth, boxTop), Offset(boxLeft + boxWidth, boxTop + cornerLen), 3.5f)
        drawLine(NeonCyan, Offset(boxLeft, boxTop + boxHeight), Offset(boxLeft + cornerLen, boxTop + boxHeight), 3.5f)
        drawLine(NeonCyan, Offset(boxLeft, boxTop + boxHeight), Offset(boxLeft, boxTop + boxHeight - cornerLen), 3.5f)
        drawLine(NeonCyan, Offset(boxLeft + boxWidth, boxTop + boxHeight), Offset(boxLeft + boxWidth - cornerLen, boxTop + boxHeight), 3.5f)
        drawLine(NeonCyan, Offset(boxLeft + boxWidth, boxTop + boxHeight), Offset(boxLeft + boxWidth, boxTop + boxHeight - cornerLen), 3.5f)
      }
    }

    // 2. Canva-Style Graphic Layers Overlay (Vektörel Çıkartmalar, Metinler ve Şekiller)
    project.graphicLayers.filter { it.isVisible }.forEach { layer ->
      Box(
        modifier = Modifier
          .align(
            when {
              layer.y < 0.3f -> Alignment.TopCenter
              layer.y > 0.7f -> Alignment.BottomCenter
              else -> Alignment.Center
            }
          )
          .padding(
            top = if (layer.y < 0.3f) 40.dp else 0.dp,
            bottom = if (layer.y > 0.7f) 64.dp else 0.dp
          )
          .clip(RoundedCornerShape(8.dp))
          .background(Color.Black.copy(alpha = 0.65f))
          .border(1.dp, Color(layer.colorHex).copy(alpha = 0.6f), RoundedCornerShape(8.dp))
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Text(
          text = layer.content,
          color = Color(layer.colorHex),
          fontSize = (11f * layer.scale).sp,
          fontWeight = FontWeight.Bold,
          fontFamily = if (layer.type == LayerType.STICKER) FontFamily.Monospace else FontFamily.Default
        )
      }
    }

    // 3. Top Bar UI: Scene info & Format Tag
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(Color.Black.copy(alpha = 0.75f))
          .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Box(
          modifier = Modifier
            .size(6.dp)
            .clip(CircleShape)
            .background(if (isPlaying) EmeraldTech else CoralRed)
        )
        Text(
          text = "${sceneIndex + 1}/10 • $badgeLabel",
          color = TextPrimary,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold
        )
      }

      if (autoReframeActive) {
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(NeonCyan.copy(alpha = 0.2f))
            .border(0.6.dp, NeonCyan, RoundedCornerShape(6.dp))
            .padding(horizontal = 5.dp, vertical = 2.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "AI REFRAME",
            color = NeonCyan,
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }

    // 4. Center Play / Pause Indicator
    if (!isPlaying) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .align(Alignment.Center)
          .clip(CircleShape)
          .background(Color.Black.copy(alpha = 0.7f))
          .border(1.dp, NeonCyan, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.PlayArrow,
          contentDescription = "Oynat",
          tint = NeonCyan,
          modifier = Modifier.size(28.dp)
        )
      }
    }

    // 5. Bottom Video Captions: Word-by-Word Synchronized Karaoke (Whisper API)
    Column(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = if (aspectRatio == AspectRatioType.PORTRAIT_9_16) 16.dp else 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(Color.Black.copy(alpha = 0.8f))
          .border(0.8.dp, DarkCardBorder, RoundedCornerShape(8.dp))
          .padding(horizontal = 10.dp, vertical = 5.dp)
      ) {
        Row(
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically
        ) {
          project.voiceover.words.chunked(4).firstOrNull { chunk ->
            chunk.any { it.startMs <= currentPlaybackMs && currentPlaybackMs <= it.endMs }
          }?.let { visibleWords ->
            visibleWords.forEach { word ->
              val isWordActive = currentPlaybackMs in word.startMs..word.endMs
              Text(
                text = "${word.word} ",
                color = if (isWordActive) RadiantGold else TextPrimary,
                fontWeight = if (isWordActive) FontWeight.Black else FontWeight.Bold,
                fontSize = if (isWordActive) 14.sp else 12.sp,
                textAlign = TextAlign.Center
              )
            }
          } ?: run {
            Text(
              text = activeScene.title,
              color = TextSecondary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }

      // Metadata info badge
      Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "${activeScene.aiModel} • ${activeScene.transitionEffect}",
          color = primaryColor,
          fontSize = 9.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
    }
  }
}
