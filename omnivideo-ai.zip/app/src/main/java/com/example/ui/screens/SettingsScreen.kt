package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.MoreSubTab
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun SettingsScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val isDark = uiState.isDarkTheme

  val bgColor = if (isDark) DarkBg else LightBg
  val cardBg = if (isDark) DarkCard else LightCard
  val cardBorder = if (isDark) DarkCardBorder else LightCardBorder
  val textPrimary = if (isDark) TextPrimary else LightTextPrimary
  val textSecondary = if (isDark) TextSecondary else LightTextSecondary
  val textMuted = if (isDark) TextMuted else LightTextMuted

  // If a sub-view is selected (like 3D architecture, Pricing, Render queue), display it with back navigation
  if (uiState.activeMoreSubTab != MoreSubTab.OVERVIEW) {
    Column(
      modifier = modifier
        .fillMaxSize()
        .background(bgColor)
    ) {
      Surface(
        color = if (isDark) DarkSurface else LightSurface,
        tonalElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          IconButton(
            onClick = { viewModel.setMoreSubTab(MoreSubTab.OVERVIEW) },
            modifier = Modifier.testTag("btn_settings_back")
          ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Geri", tint = textPrimary)
          }

          Text(
            text = uiState.activeMoreSubTab.title,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = textPrimary
          )
        }
      }

      Box(modifier = Modifier.fillMaxSize()) {
        when (uiState.activeMoreSubTab) {
          MoreSubTab.PRICING -> PricingPlansScreen(viewModel = viewModel)
          MoreSubTab.ARCHITECTURE_3D -> InfographicScreen(viewModel = viewModel)
          MoreSubTab.RENDER_GPU -> RenderPipelineScreen(viewModel = viewModel)
          MoreSubTab.OVERVIEW -> { /* handled above */ }
        }
      }
    }
    return
  }

  // Ana Ayarlar Menüsü
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(bgColor)
      .testTag("settings_screen_scroll"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Profil Kartı
    item {
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        shadowElevation = if (isDark) 2.dp else 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          Box(
            modifier = Modifier
              .size(56.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(listOf(CanvaPurple, CanvaPink, CanvaGold))),
            contentAlignment = Alignment.Center
          ) {
            Text("B", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = uiState.userName,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = textPrimary
            )
            Text(
              text = if (uiState.isProUser) "👑 Pro VIP Üye (Sınırsız 4K)" else "Ücretsiz Plan (Filigranlı)",
              fontSize = 12.sp,
              color = if (uiState.isProUser) CanvaGold else textSecondary
            )
            Text(
              text = "⚡ ${uiState.aiCredits} AI Kredisi Kalan",
              fontSize = 11.sp,
              color = CanvaCyan,
              fontWeight = FontWeight.SemiBold
            )
          }

          Button(
            onClick = { viewModel.setMoreSubTab(MoreSubTab.PRICING) },
            colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text("Yükselt", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // Görünüm Teması Ayarı
    item {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(
              imageVector = if (isDark) Icons.Default.DarkMode else Icons.Default.LightMode,
              contentDescription = null,
              tint = if (isDark) CanvaAmber else CanvaPurple,
              modifier = Modifier.size(24.dp)
            )
            Column {
              Text("Koyu Tema / Neon Cam Efekti", fontWeight = FontWeight.Bold, color = textPrimary, fontSize = 14.sp)
              Text(
                if (isDark) "Karanlık Mod (Neon Mor & Cyan Cam Vurgular)" else "Açık Tema (Canva Temiz Beyaz)",
                color = textMuted,
                fontSize = 11.sp
              )
            }
          }

          Switch(
            checked = isDark,
            onCheckedChange = { viewModel.setDarkTheme(it) },
            colors = SwitchDefaults.colors(
              checkedThumbColor = CanvaAmber,
              checkedTrackColor = CanvaPurple,
              uncheckedThumbColor = CanvaPurple,
              uncheckedTrackColor = LightCardElevated
            )
          )
        }
      }
    }

    // Sistem ve Mimari Modülleri
    item {
      Text("Sistem & 3B Mimari Altyapısı", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = textSecondary)
    }

    item {
      SettingsRowItem(
        icon = Icons.Default.Hub,
        iconTint = NeonCyan,
        title = "🏛️ 3B İzometrik Mimari Tasarımı",
        subtitle = "WebAssembly, WebGPU, Node.js ve CUDA NVENC veri akış şeması",
        onClick = { viewModel.setMoreSubTab(MoreSubTab.ARCHITECTURE_3D) },
        cardBg = cardBg,
        cardBorder = cardBorder,
        textPrimary = textPrimary,
        textSecondary = textSecondary
      )
    }

    item {
      SettingsRowItem(
        icon = Icons.Default.Speed,
        iconTint = EmeraldTech,
        title = "⚡ 4K NVENC Render & GPU Kuyruğu",
        subtitle = "A100 Tensor Cloud ve istemci WebGPU render durumu",
        onClick = { viewModel.setMoreSubTab(MoreSubTab.RENDER_GPU) },
        cardBg = cardBg,
        cardBorder = cardBorder,
        textPrimary = textPrimary,
        textSecondary = textSecondary
      )
    }

    item {
      SettingsRowItem(
        icon = Icons.Default.WorkspacePremium,
        iconTint = CanvaGold,
        title = "👑 Planınızı Yükseltin & Fiyatlandırma",
        subtitle = "Yıllık indirim, kredi paketleri ve 4K filigransız dışa aktarma",
        onClick = { viewModel.setMoreSubTab(MoreSubTab.PRICING) },
        cardBg = cardBg,
        cardBorder = cardBorder,
        textPrimary = textPrimary,
        textSecondary = textSecondary
      )
    }

    item {
      SettingsRowItem(
        icon = Icons.Default.Security,
        iconTint = CanvaPurple,
        title = "🔒 Veri Güvenliği & Telif Koruması",
        subtitle = "Oluşturulan tüm video ve ses materyalleri ticari lisanslıdır",
        onClick = { viewModel.showToast("Ticari Lisans: Tüm haklar size aittir (Pro VIP)") },
        cardBg = cardBg,
        cardBorder = cardBorder,
        textPrimary = textPrimary,
        textSecondary = textSecondary
      )
    }
  }
}

@Composable
private fun SettingsRowItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  iconTint: Color,
  title: String,
  subtitle: String,
  onClick: () -> Unit,
  cardBg: Color,
  cardBorder: Color,
  textPrimary: Color,
  textSecondary: Color
) {
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(16.dp),
    color = cardBg,
    border = BorderStroke(1.dp, cardBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(CircleShape)
          .background(iconTint.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(22.dp))
      }

      Column(modifier = Modifier.weight(1f)) {
        Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = textPrimary)
        Text(text = subtitle, fontSize = 11.sp, color = textSecondary)
      }

      Icon(Icons.Default.ChevronRight, contentDescription = null, tint = textSecondary, modifier = Modifier.size(18.dp))
    }
  }
}
