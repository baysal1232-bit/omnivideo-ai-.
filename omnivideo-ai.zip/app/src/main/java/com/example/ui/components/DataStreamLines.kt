package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun DataStreamCanvas(
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "laserStream")
  val phase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 100f,
    animationSpec = infiniteRepeatable(
      animation = tween(3000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "phase"
  )

  Canvas(modifier = modifier) {
    val width = size.width
    val height = size.height

    if (width <= 0 || height <= 0) return@Canvas

    // Laser lines connecting modules
    // Blue line: Left (UI) to Center (Dual Screen)
    val leftToCenter = Path().apply {
      moveTo(width * 0.15f, height * 0.35f)
      cubicTo(
        width * 0.30f, height * 0.35f,
        width * 0.35f, height * 0.45f,
        width * 0.50f, height * 0.45f
      )
    }

    // Violet line: Right (AI) to Center (Dual Screen)
    val rightToCenter = Path().apply {
      moveTo(width * 0.85f, height * 0.35f)
      cubicTo(
        width * 0.70f, height * 0.35f,
        width * 0.65f, height * 0.45f,
        width * 0.50f, height * 0.45f
      )
    }

    // Gold line: Center (Dual Screen) to Bottom (Render & Tech)
    val centerToBottom = Path().apply {
      moveTo(width * 0.50f, height * 0.55f)
      cubicTo(
        width * 0.50f, height * 0.70f,
        width * 0.35f, height * 0.80f,
        width * 0.30f, height * 0.88f
      )
    }

    // Emerald line: Server NVENC to Storage S3
    val renderToStorage = Path().apply {
      moveTo(width * 0.50f, height * 0.55f)
      cubicTo(
        width * 0.50f, height * 0.70f,
        width * 0.65f, height * 0.80f,
        width * 0.70f, height * 0.88f
      )
    }

    val dashEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 15f), phase * 3f)

    // Draw background glowing wide path
    drawPath(
      path = leftToCenter,
      color = NeonCyan.copy(alpha = 0.25f),
      style = Stroke(width = 6f)
    )
    drawPath(
      path = leftToCenter,
      color = NeonCyan,
      style = Stroke(width = 2.5f, pathEffect = dashEffect)
    )

    drawPath(
      path = rightToCenter,
      color = CyberPurple.copy(alpha = 0.25f),
      style = Stroke(width = 6f)
    )
    drawPath(
      path = rightToCenter,
      color = CyberPurple,
      style = Stroke(width = 2.5f, pathEffect = dashEffect)
    )

    drawPath(
      path = centerToBottom,
      color = RadiantGold.copy(alpha = 0.25f),
      style = Stroke(width = 6f)
    )
    drawPath(
      path = centerToBottom,
      color = RadiantGold,
      style = Stroke(width = 2.5f, pathEffect = dashEffect)
    )

    drawPath(
      path = renderToStorage,
      color = EmeraldTech.copy(alpha = 0.25f),
      style = Stroke(width = 6f)
    )
    drawPath(
      path = renderToStorage,
      color = EmeraldTech,
      style = Stroke(width = 2.5f, pathEffect = dashEffect)
    )

    // Moving energy packet particles along the routes
    val progress = (phase % 100f) / 100f
    val pX = width * (0.15f + 0.35f * progress)
    val pY = height * (0.35f + 0.10f * sin(progress * Math.PI.toFloat()))

    drawCircle(
      color = NeonCyan,
      radius = 5f,
      center = Offset(pX, pY)
    )
    drawCircle(
      color = Color.White,
      radius = 2.5f,
      center = Offset(pX, pY)
    )

    val p2X = width * (0.85f - 0.35f * progress)
    val p2Y = height * (0.35f + 0.10f * sin(progress * Math.PI.toFloat()))
    drawCircle(
      color = CyberPurple,
      radius = 5f,
      center = Offset(p2X, p2Y)
    )
    drawCircle(
      color = Color.White,
      radius = 2.5f,
      center = Offset(p2X, p2Y)
    )
  }
}
