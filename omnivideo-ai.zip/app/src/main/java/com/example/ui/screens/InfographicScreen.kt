package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun InfographicScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val clipboardManager = LocalClipboardManager.current
  var isHowToExpanded by remember { mutableStateOf(true) }

  var selectedHeroImageIndex by remember { mutableStateOf(0) }

  val promptText = remember {
    "Canva'nın sürükle-bırak sadeliği ile CapCut'ın kurgu gücünü birleştiren, tamamen Türkçe arayüze sahip yapay zeka destekli hepsi bir arada bir video ve görsel stüdyosu yazılımının 3B izometrik UI/UX mimari tasarımı.\n" +
    "Ekran Düzeni ve Arayüz Panelleri:\n" +
    "Üst Kontrol Barı: Sol üstte 'Dosya' ve 'Düzenle' menüleri; ortada tek tıkla değişen 'Format: 9:16 Dikey (Shorts/Reels) / 16:9 Yatay (YouTube) / 1:1' açılır menüsü; sağ üstte parlayan '⚡ 120 AI Kredisi', '👑 Premium' ikonu ve belirgin '📤 4K Dışa Aktar' butonu.\n" +
    "Sol Panel (Canva Stili Bileşen Kütüphanesi): Simgelerle kategorize edilmiş dikey araç çubuğu: '🔍 Ara', '🧩 Şablonlar', '🖼️ Görseller', '🎥 Videolar', '🅰️ Metin & Tipografi', '🎨 Çıkartma & Elementler' ve '📤 Yüklenen Medyalar'. Kullanıcıların görselleri tuvale sürükleyip bırakabildiği düzenli yapı.\n" +
    "Orta Panel (Canlı Tuval & Önizleme): Merkezde dikey (9:16) formatta çalışan, üzerinde metinlerin, katmanların ve görsellerin serbestçe boyutlandırılıp döndürülebildiği esnek canlı önizleme tuvalı.\n" +
    "Sağ Panel (Yapay Zeka ve Otomasyon Sihirbazı):\n" +
    "AI Video Üretici: 'Prompt Girin...' metin kutusu ve altında belirgin '🎬 10 Sahne Üret ve Otomatik Birleştir' butonu.\n" +
    "AI Seslendirme & Altyazı: ElevenLabs entegrasyonlu Türkçe metinden seslendirme paneli ve OpenAI Whisper destekli otomatik zaman damgalı altyazı modülü.\n" +
    "AI Araçları: Tek tıkla arka plan silme (rembg) ve nesne dekupe etme butonları.\n" +
    "Alt Panel (Modüler Zaman Çizelgesi - Timeline):\n" +
    "Video Katmanı: Üretilen veya yüklenen 10 ayrı video klip bloğunun uç uca dizildiği katman.\n" +
    "Ses Katmanı: Arka plan müziği ve AI seslendirme dalga formları.\n" +
    "Altyazı Katmanı: Kelime senkronlu otomatik altyazı blokları.\n" +
    "Görsel Stil: Son derece net, modern, düzenli ve kullanıcı dostu arayüz elemanları. Şeffaf koyu tema cam paneller, neon mavi, mor, cyan ve altın sarısı vurgular, 3B teknoloji ikonları, 8k yüksek çözünürlük, sinematik ışıklandırma, Unreal Engine 5 render estetiği."
  }

  val filteredNodes = remember(uiState.architectureLayerFilter) {
    if (uiState.architectureLayerFilter == null) {
      viewModel.architectureNodes
    } else {
      viewModel.architectureNodes.filter { it.layer == uiState.architectureLayerFilter }
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBg)
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp)
  ) {
    // 1. Header & Title
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          GlowingBadge(
            text = "3B İZOMETRİK İÇERİK STÜDYOSU MİMARİSİ",
            color = NeonCyan
          )
          TechMetricPill(
            label = "CANVA & CAPCUT",
            value = "Hepsi Bir Arada",
            color = RadiantGold
          )
        }

        Text(
          text = "Görsel Tasarım & Video Kurgu Mimarisi",
          color = TextPrimary,
          fontSize = 22.sp,
          fontWeight = FontWeight.Black
        )
        Text(
          text = "Canva tarzı görsel katmanlama, CapCut tarzı video kurgu, dahili Veo/Sora/Flux üretimi ve hibrit WebGPU/CUDA altyapısı.",
          color = TextSecondary,
          fontSize = 13.sp,
          lineHeight = 18.sp
        )
      }
    }

    // 2. 3D Isometric Hero Visual with Animated Laser Streams
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = NeonCyan.copy(alpha = 0.6f),
        backgroundColor = DarkSurface,
        cornerRadius = 18.dp
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(DarkBg)
        ) {
          // Generated 3D Isometric Architecture Image Asset (UI/UX Design or System Architecture)
          val heroDrawable = if (selectedHeroImageIndex == 0) {
            R.drawable.img_canva_capcut_studio_ui_1790547221055
          } else {
            R.drawable.img_canva_capcut_ai_studio_1790546539163
          }

          Image(
            painter = painterResource(id = heroDrawable),
            contentDescription = "Canva ve CapCut Tarzı Hepsi Bir Arada İçerik Stüdyosu 3B İnfografiği",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )

          // Glowing laser stream canvas overlay
          DataStreamCanvas(modifier = Modifier.fillMaxSize())

          // Top badge overlay with image toggle
          Row(
            modifier = Modifier
              .align(Alignment.TopEnd)
              .padding(8.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(Color.Black.copy(alpha = 0.85f))
              .clickable {
                selectedHeroImageIndex = (selectedHeroImageIndex + 1) % 2
              }
              .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.SwapHoriz,
              contentDescription = null,
              tint = RadiantGold,
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = if (selectedHeroImageIndex == 0) "3B UI/UX Arayüz Tasarımı" else "3B Sistem Mimarisi",
              color = RadiantGold,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold
            )
          }

          // Bottom data stream speed tag
          Row(
            modifier = Modifier
              .align(Alignment.BottomStart)
              .padding(8.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(Color.Black.copy(alpha = 0.75f))
              .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(EmeraldTech)
            )
            Text(
              text = "Veri Akış Hatları: Mavi • Mor • Altın",
              color = TextPrimary,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    // 3. Quick Action Row: Promptu Kopyala & Stüdyoyu Aç
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Copy Prompt Button
        Button(
          onClick = {
            clipboardManager.setText(AnnotatedString(promptText))
            viewModel.showToast("Canva & CapCut Mimari Promptu Kopyalandı! Midjourney veya DALL-E'ye yapıştırabilirsiniz.")
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = NeonCyan.copy(alpha = 0.18f),
            contentColor = NeonCyan
          ),
          border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.weight(1f).height(44.dp)
        ) {
          Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Promptu Kopyala", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        // Open Studio Button
        Button(
          onClick = {
            viewModel.setTab(MainNavigationTab.DUAL_STUDIO)
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = RadiantGold,
            contentColor = DarkBg
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.weight(1f).height(44.dp)
        ) {
          Icon(Icons.Default.MovieFilter, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Stüdyoda Dene", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 4. "Nasıl Kullanacaksınız?" Açıklama Paneli
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = RadiantGold.copy(alpha = 0.4f),
        backgroundColor = DarkSurface,
        cornerRadius = 14.dp
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { isHowToExpanded = !isHowToExpanded },
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.HelpOutline, contentDescription = null, tint = RadiantGold)
            Text(
              text = "Hepsi Bir Arada Mimari Nasıl Çalışır?",
              color = TextPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Icon(
            imageVector = if (isHowToExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
            contentDescription = null,
            tint = RadiantGold
          )
        }

        AnimatedVisibility(visible = isHowToExpanded) {
          Column(
            modifier = Modifier.padding(top = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Visual generation guide
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(DarkBg)
                .padding(10.dp)
            ) {
              Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                  text = "🎨 3B Görsel Üretmek İçin:",
                  color = RadiantGold,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "Yukarıdaki 'Promptu Kopyala' butonuna basarak metni kopyalayıp Midjourney, DALL-E 3 veya Leonardo.ai gibi araçlara yapıştırabilirsiniz.",
                  color = TextSecondary,
                  fontSize = 11.sp,
                  lineHeight = 15.sp
                )
              }
            }

            // Software dev guide
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(DarkBg)
                .padding(10.dp)
            ) {
              Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                  text = "💻 Yazılım ve Mimari Entegrasyonu:",
                  color = NeonCyan,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "Kullanıcılar 'Canva Modu' ile grafik katmanlarını, metinleri ve rembg arka plan silmeyi yönetebilir; 'CapCut Modu' ile 10 sahneyi tek tıkla zaman çizelgesine dizip 9:16 ve 16:9 4K çıktı alabilir.",
                  color = TextSecondary,
                  fontSize = 11.sp,
                  lineHeight = 15.sp
                )
              }
            }
          }
        }
      }
    }

    // 5. Layer Filter Chips
    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = "Mimari Katmanları İnceleyin",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )

        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
          item {
            FilterChip(
              selected = uiState.architectureLayerFilter == null,
              onClick = { viewModel.setArchitectureLayerFilter(null) },
              label = { Text("Tüm Katmanlar (${viewModel.architectureNodes.size})") },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                selectedLabelColor = NeonCyan,
                containerColor = DarkCard,
                labelColor = TextSecondary
              )
            )
          }
          items(ArchitectureLayer.values()) { layer ->
            val isSelected = uiState.architectureLayerFilter == layer
            FilterChip(
              selected = isSelected,
              onClick = { viewModel.setArchitectureLayerFilter(layer) },
              label = { Text(layer.displayName.split(":").last().trim()) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = Color(layer.colorHex).copy(alpha = 0.25f),
                selectedLabelColor = Color(layer.colorHex),
                containerColor = DarkCard,
                labelColor = TextSecondary
              )
            )
          }
        }
      }
    }

    // 6. Architecture Nodes Grid / Cards
    items(filteredNodes) { node ->
      ArchitectureNodeCard(
        node = node,
        isSelected = uiState.selectedArchitectureNode?.id == node.id,
        onSelect = { viewModel.selectArchitectureNode(node) },
        onActionNavigate = {
          when (node.layer) {
            ArchitectureLayer.FREE_TIER_TOOLS -> viewModel.setTab(MainNavigationTab.DUAL_STUDIO)
            ArchitectureLayer.PREMIUM_AI_TIER -> viewModel.setTab(MainNavigationTab.PRICING_PLANS)
            ArchitectureLayer.CENTER_WORKSPACE -> viewModel.setTab(MainNavigationTab.DUAL_STUDIO)
            ArchitectureLayer.BOTTOM_TECH_RENDER -> viewModel.setTab(MainNavigationTab.RENDER_PIPELINE)
          }
        }
      )
    }
  }
}

@Composable
fun ArchitectureNodeCard(
  node: ArchitectureNode,
  isSelected: Boolean,
  onSelect: () -> Unit,
  onActionNavigate: () -> Unit
) {
  val layerColor = Color(node.layer.colorHex)

  CyberCard(
    modifier = Modifier.fillMaxWidth(),
    borderColor = if (isSelected) layerColor else DarkCardBorder,
    backgroundColor = if (isSelected) DarkCardElevated else DarkCard,
    cornerRadius = 16.dp,
    onClick = onSelect
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.Top
    ) {
      Row(
        modifier = Modifier.weight(1f),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(layerColor.copy(alpha = 0.15f))
            .border(1.dp, layerColor.copy(alpha = 0.4f), RoundedCornerShape(10.dp)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = when (node.layer) {
              ArchitectureLayer.FREE_TIER_TOOLS -> Icons.Default.DesignServices
              ArchitectureLayer.PREMIUM_AI_TIER -> Icons.Default.WorkspacePremium
              ArchitectureLayer.CENTER_WORKSPACE -> Icons.Default.SmartDisplay
              ArchitectureLayer.BOTTOM_TECH_RENDER -> Icons.Default.Memory
            },
            contentDescription = node.title,
            tint = layerColor,
            modifier = Modifier.size(20.dp)
          )
        }

        Column {
          Text(
            text = node.title,
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = node.subtitle,
            color = layerColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }

      GlowingBadge(
        text = node.highlightBadge,
        color = layerColor
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Text(
      text = node.detailedDescription,
      color = TextSecondary,
      fontSize = 12.sp,
      lineHeight = 17.sp
    )

    Spacer(modifier = Modifier.height(10.dp))

    // Tech Tags
    Row(
      modifier = Modifier.horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      node.technologies.forEach { tech ->
        Text(
          text = tech,
          color = TextPrimary,
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace,
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(DarkCardBorder)
            .padding(horizontal = 6.dp, vertical = 2.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Dataflow Route
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(8.dp))
        .background(DarkBg)
        .padding(8.dp),
      verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Text("Girdi:", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(node.dataflowIn, color = NeonCyan, fontSize = 10.sp, maxLines = 1)
      }
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Text("Çıktı:", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(node.dataflowOut, color = RadiantGold, fontSize = 10.sp, maxLines = 1)
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Action button
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = node.metrics,
        color = TextSecondary,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace
      )

      Button(
        onClick = onActionNavigate,
        colors = ButtonDefaults.buttonColors(
          containerColor = layerColor.copy(alpha = 0.2f),
          contentColor = layerColor
        ),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        modifier = Modifier.height(32.dp)
      ) {
        Text(
          text = "Stüdyoda Aç",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
          imageVector = Icons.Default.ArrowForward,
          contentDescription = null,
          modifier = Modifier.size(12.dp)
        )
      }
    }
  }
}
