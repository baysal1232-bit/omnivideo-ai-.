package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Canva Signature Palette & Gradients
val CanvaPurple = Color(0xFF7C3AED)
val CanvaIndigo = Color(0xFF4F46E5)
val CanvaBlue = Color(0xFF2563EB)
val CanvaCyan = Color(0xFF06B6D4)
val CanvaPink = Color(0xFFEC4899)
val CanvaGold = Color(0xFFF59E0B)
val CanvaAmber = Color(0xFFFBBF24)
val CanvaGreen = Color(0xFF10B981)
val CanvaOrange = Color(0xFFF97316)
val CanvaRose = Color(0xFFF43F5E)

// Light Theme Palette (Canva Fresh Clean White)
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFFFFFFF)
val LightCardElevated = Color(0xFFF1F5F9)
val LightCardBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF94A3B8)

// Cyberpunk / Deep Cinematic Sci-Fi Palette
val DarkBg = Color(0xFF080B12)
val DarkSurface = Color(0xFF0F1523)
val DarkCard = Color(0xFF141C2E)
val DarkCardElevated = Color(0xFF1C273E)
val DarkCardBorder = Color(0xFF263554)

// Vibrant Glow Accents
val NeonCyan = Color(0xFF00D2FF)
val ElectricBlue = Color(0xFF0088FF)
val CyberPurple = Color(0xFFA855F7)
val DeepViolet = Color(0xFF7C3AED)
val RadiantGold = Color(0xFFFBBF24)
val AmberGlow = Color(0xFFF59E0B)
val EmeraldTech = Color(0xFF10B981)
val CoralRed = Color(0xFFEF4444)

// Text Colors (Dark Mode Defaults)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Glass Overlay
val GlassBg = Color(0xCC0F1523)
val GlassBorder = Color(0x6638BDF8)
val LightGlassBg = Color(0xE6FFFFFF)
val LightGlassBorder = Color(0x337C3AED)
