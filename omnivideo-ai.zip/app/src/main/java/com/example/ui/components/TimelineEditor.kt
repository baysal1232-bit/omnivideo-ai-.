package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VideoProject
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun TimelineEditor(
  project: VideoProject,
  currentPlaybackMs: Long,
  isPlaying: Boolean,
  onSeek: (Long) -> Unit,
  onTogglePlay: () -> Unit,
  onCut: () -> Unit,
  onAddEffect: () -> Unit,
  modifier: Modifier = Modifier
) {
  val totalMs = (project.totalDurationSeconds * 1000).toLong()
  val progress = (currentPlaybackMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f)

  val timeCode = remember(currentPlaybackMs) {
    val totalSec = currentPlaybackMs / 1000
    val ms = (currentPlaybackMs % 1000) / 10
    val min = totalSec / 60
    val sec = totalSec % 60
    String.format("%02d:%02d:%02d / 02:00:00", min, sec, ms)
  }

  CyberCard(
    modifier = modifier.fillMaxWidth(),
    borderColor = DarkCardBorder,
    backgroundColor = DarkSurface,
    cornerRadius = 16.dp
  ) {
    // 1. Timeline Header: Controls & Timecode
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        IconButton(
          onClick = onTogglePlay,
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(DarkCardElevated)
            .border(1.dp, NeonCyan.copy(alpha = 0.5f), CircleShape)
            .testTag("timeline_play_pause_button")
        ) {
          Icon(
            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
            contentDescription = if (isPlaying) "Duraklat" else "Oynat",
            tint = NeonCyan,
            modifier = Modifier.size(20.dp)
          )
        }

        IconButton(
          onClick = onCut,
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(DarkCardElevated)
            .border(1.dp, DarkCardBorder, CircleShape)
            .testTag("timeline_cut_button")
        ) {
          Icon(
            imageVector = Icons.Default.ContentCut,
            contentDescription = "Kes & Böl",
            tint = RadiantGold,
            modifier = Modifier.size(18.dp)
          )
        }

        IconButton(
          onClick = onAddEffect,
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(DarkCardElevated)
            .border(1.dp, DarkCardBorder, CircleShape)
            .testTag("timeline_fx_button")
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = "Efekt Ekle",
            tint = CyberPurple,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      // Timecode
      Text(
        text = timeCode,
        color = NeonCyan,
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 2. Interactive Timeline Tracks Canvas with Playhead (10 Klip Uç Uca)
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(145.dp)
        .clip(RoundedCornerShape(10.dp))
        .background(DarkBg)
        .border(1.dp, DarkCardBorder, RoundedCornerShape(10.dp))
        .pointerInput(totalMs) {
          detectDragGestures { change, _ ->
            val newProgress = (change.position.x / size.width).coerceIn(0f, 1f)
            onSeek((newProgress * totalMs).toLong())
          }
        }
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        // Track 1: Video Track (10 Klip Uç Uca Sıralı)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(30.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(DarkCard)
        ) {
          project.scenes.forEachIndexed { idx, scene ->
            val weight = scene.durationSeconds / project.totalDurationSeconds
            Box(
              modifier = Modifier
                .weight(weight)
                .fillMaxHeight()
                .padding(horizontal = 0.8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(scene.primaryColorHex).copy(alpha = 0.45f))
                .border(0.8.dp, Color(scene.primaryColorHex), RoundedCornerShape(4.dp))
                .padding(horizontal = 2.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "${idx + 1}",
                color = TextPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        // Track 2: ElevenLabs Voiceover Track with Audio Waveform (28dp)
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(28.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(RadiantGold.copy(alpha = 0.15f))
            .border(0.8.dp, RadiantGold.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp),
          contentAlignment = Alignment.CenterStart
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val barCount = (w / 4f).toInt()
            for (i in 0 until barCount) {
              val x = i * 4f
              val norm = i.toFloat() / barCount
              val barH = (sin(norm * 40f + 1.2f) * 0.4f + 0.5f) * h * 0.75f
              drawLine(
                color = RadiantGold,
                start = Offset(x, (h - barH) / 2f),
                end = Offset(x, (h + barH) / 2f),
                strokeWidth = 2f
              )
            }
          }
          Text(
            text = "🎙️ ElevenLabs: ${project.voiceover.speakerName.split("-").first().trim()}",
            color = RadiantGold,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
          )
        }

        // Track 3: Whisper Captions Track (26dp)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(26.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(CyberPurple.copy(alpha = 0.15f))
            .border(0.8.dp, CyberPurple.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "💬 Whisper API 10 Klip Kelime Altyazı İzi",
            color = CyberPurple,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
          )
        }

        // Track 4: FX & Shaders Track (24dp)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(24.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(EmeraldTech.copy(alpha = 0.12f))
            .border(0.8.dp, EmeraldTech.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .padding(horizontal = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "✨ Auto-Assemble Geçişleri (${project.scenes.size} Klip)",
            color = EmeraldTech,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      // Playhead Scrubber Line
      Canvas(modifier = Modifier.fillMaxSize()) {
        val playheadX = size.width * progress
        drawLine(
          color = NeonCyan,
          start = Offset(playheadX, 0f),
          end = Offset(playheadX, size.height),
          strokeWidth = 2.5f
        )
        drawCircle(
          color = NeonCyan,
          radius = 5f,
          center = Offset(playheadX, 4f)
        )
      }
    }
  }
}
