package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CyberCard(
  modifier: Modifier = Modifier,
  borderColor: Color = NeonCyan.copy(alpha = 0.5f),
  backgroundColor: Color = DarkCard,
  cornerRadius: Dp = 16.dp,
  onClick: (() -> Unit)? = null,
  content: @Composable ColumnScope.() -> Unit
) {
  val shape = RoundedCornerShape(cornerRadius)
  val clickModifier = if (onClick != null) {
    Modifier.clickable { onClick() }
  } else Modifier

  Column(
    modifier = modifier
      .clip(shape)
      .background(backgroundColor)
      .border(
        width = 1.dp,
        brush = Brush.linearGradient(
          colors = listOf(
            borderColor,
            borderColor.copy(alpha = 0.15f),
            CyberPurple.copy(alpha = 0.3f)
          )
        ),
        shape = shape
      )
      .then(clickModifier)
      .padding(16.dp),
    content = content
  )
}

@Composable
fun GlowingBadge(
  text: String,
  color: Color = NeonCyan,
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "badgePulse")
  val alphaPulse by infiniteTransition.animateFloat(
    initialValue = 0.6f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "alphaPulse"
  )

  Row(
    modifier = modifier
      .clip(RoundedCornerShape(8.dp))
      .background(color.copy(alpha = 0.15f))
      .border(1.dp, color.copy(alpha = alphaPulse * 0.8f), RoundedCornerShape(8.dp))
      .padding(horizontal = 10.dp, vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    Box(
      modifier = Modifier
        .size(6.dp)
        .clip(CircleShape)
        .background(color)
    )
    Text(
      text = text,
      color = color,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.5.sp
    )
  }
}

@Composable
fun TechMetricPill(
  label: String,
  value: String,
  color: Color = NeonCyan,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(DarkCardElevated)
      .border(0.8.dp, DarkCardBorder, RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    Text(
      text = label,
      color = TextMuted,
      fontSize = 10.sp,
      fontWeight = FontWeight.Medium
    )
    Text(
      text = value,
      color = color,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

@Composable
fun NeonGradientButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  colors: List<Color> = listOf(NeonCyan, ElectricBlue, CyberPurple),
  leadingIcon: @Composable (() -> Unit)? = null
) {
  val shape = RoundedCornerShape(12.dp)
  Box(
    modifier = modifier
      .clip(shape)
      .background(
        brush = Brush.horizontalGradient(
          colors = if (enabled) colors else listOf(DarkCardBorder, DarkCard)
        )
      )
      .clickable(enabled = enabled) { onClick() }
      .padding(horizontal = 16.dp, vertical = 12.dp),
    contentAlignment = Alignment.Center
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      leadingIcon?.invoke()
      Text(
        text = text,
        color = if (enabled) TextPrimary else TextMuted,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp
      )
    }
  }
}
