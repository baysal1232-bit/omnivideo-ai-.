package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatioType
import com.example.data.model.RecentProjectCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.StudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DesignsScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val isDark = uiState.isDarkTheme

  val bgColor = if (isDark) DarkBg else LightBg
  val cardBg = if (isDark) DarkCard else LightCard
  val cardBorder = if (isDark) DarkCardBorder else LightCardBorder
  val textPrimary = if (isDark) TextPrimary else LightTextPrimary
  val textSecondary = if (isDark) TextSecondary else LightTextSecondary
  val textMuted = if (isDark) TextMuted else LightTextMuted

  var selectedFolder by remember { mutableStateOf("Tümü") }
  val folders = listOf("Tümü", "📱 TikTok & Reels (9:16)", "🎬 YouTube 4K (16:9)", "🛍️ E-Ticaret", "✨ AI Kurgular")

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(bgColor)
      .testTag("designs_screen_scroll"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp)
  ) {
    // Üst Başlık
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "📁 Tasarımlarınız",
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            color = textPrimary
          )
          Text(
            text = "Son projeleriniz, taslaklar ve render edilen videolar",
            fontSize = 12.sp,
            color = textMuted
          )
        }

        IconButton(
          onClick = { viewModel.launchNewVideo(AspectRatioType.PORTRAIT_9_16) },
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(CanvaPurple)
        ) {
          Icon(Icons.Default.Add, contentDescription = "Yeni Proje", tint = Color.White)
        }
      }
    }

    item { Spacer(modifier = Modifier.height(16.dp)) }

    // Klasör Filtreleri
    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(folders) { folder ->
          val isSelected = folder == selectedFolder
          FilterChip(
            selected = isSelected,
            onClick = { selectedFolder = folder },
            label = {
              Text(
                text = folder,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 12.sp
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = CanvaPurple,
              selectedLabelColor = Color.White,
              containerColor = if (isDark) DarkCardElevated else LightCardElevated,
              labelColor = textSecondary
            )
          )
        }
      }
    }

    item { Spacer(modifier = Modifier.height(20.dp)) }

    // Projeler Listesi
    items(viewModel.recentProjects) { project ->
      val isVertical = project.aspectType == AspectRatioType.PORTRAIT_9_16
      Surface(
        onClick = { viewModel.openRecentProject(project) },
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        shadowElevation = if (isDark) 2.dp else 4.dp,
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp)
          .testTag("design_item_${project.id}")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Sol Önizleme Kutusu
          Box(
            modifier = Modifier
              .size(width = 74.dp, height = 74.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(
                brush = Brush.linearGradient(
                  listOf(Color(project.primaryColorHex), Color(project.secondaryColorHex))
                )
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (isVertical) Icons.Default.StayCurrentPortrait else Icons.Default.Tv,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(28.dp)
            )
          }

          // Orta Bilgiler
          Column(modifier = Modifier.weight(1f)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Text(
                text = project.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = if (isVertical) "9:16 Dikey • ${project.durationSeconds}s • ${project.resolution}" else "16:9 Yatay • ${project.durationSeconds}s • ${project.resolution}",
              fontSize = 11.sp,
              color = textSecondary
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
              text = "Düzenlendi: ${project.lastEdited}",
              fontSize = 10.sp,
              color = textMuted
            )
          }

          // Sağ Eylem Butonu
          Button(
            onClick = { viewModel.openRecentProject(project) },
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Text("Düzenle", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    item { Spacer(modifier = Modifier.height(20.dp)) }

    // Hızlı Başlatma Kartı
    item {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isDark) DarkCardElevated else Color(0xFFEDE9FE),
        border = BorderStroke(1.dp, CanvaPurple.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CanvaPurple)
            Text("Yapay Zeka ile Yeni Video Tasarla", fontWeight = FontWeight.Bold, color = textPrimary)
          }
          Text(
            text = "Google Veo 2, OpenAI Sora ve ElevenLabs Türkçe seslendirme ile 10 sahneyi tek seferde oluşturun.",
            fontSize = 12.sp,
            color = textSecondary
          )
          Button(
            onClick = { viewModel.launchAiVideoBatch() },
            colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text("🪄 10 Sahne Toplu AI Başlat", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}
