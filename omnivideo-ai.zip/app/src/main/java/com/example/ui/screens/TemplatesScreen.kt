package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TemplateItem
import com.example.ui.theme.*
import com.example.ui.viewmodel.StudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TemplatesScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val isDark = uiState.isDarkTheme

  val bgColor = if (isDark) DarkBg else LightBg
  val cardBg = if (isDark) DarkCard else LightCard
  val cardBorder = if (isDark) DarkCardBorder else LightCardBorder
  val textPrimary = if (isDark) TextPrimary else LightTextPrimary
  val textSecondary = if (isDark) TextSecondary else LightTextSecondary
  val textMuted = if (isDark) TextMuted else LightTextMuted

  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("Tümü") }
  val categories = listOf("Tümü", "TikTok & Reels (9:16)", "YouTube (16:9)", "AI Sinema", "Ticari / Reklam", "Altyazılı Klip")

  val filteredTemplates = viewModel.popularTemplates.filter { item ->
    val matchesCategory = selectedCategory == "Tümü" || item.category.contains(selectedCategory.take(6), ignoreCase = true)
    val matchesSearch = searchQuery.isBlank() || item.title.contains(searchQuery, ignoreCase = true) || item.tags.any { it.contains(searchQuery, ignoreCase = true) }
    matchesCategory && matchesSearch
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(bgColor)
      .testTag("templates_screen_scroll"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp)
  ) {
    // Başlık
    item {
      Column {
        Text(
          text = "🎨 Şablon Kütüphanesi",
          fontSize = 24.sp,
          fontWeight = FontWeight.ExtraBold,
          color = textPrimary
        )
        Text(
          text = "Trend dikey ve yatay video şablonlarını tek tıkla özelleştirin",
          fontSize = 12.sp,
          color = textMuted
        )
      }
    }

    item { Spacer(modifier = Modifier.height(14.dp)) }

    // Arama Çubuğu
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Şablon ara (Örn: Reels, YouTube intro, Reklam...)", fontSize = 13.sp) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CanvaPurple) },
        shape = RoundedCornerShape(16.dp),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = cardBg,
          unfocusedContainerColor = cardBg,
          focusedBorderColor = CanvaPurple,
          unfocusedBorderColor = cardBorder
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("input_template_search")
      )
    }

    item { Spacer(modifier = Modifier.height(12.dp)) }

    // Kategori Filtreleri
    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(categories) { cat ->
          val isSelected = cat == selectedCategory
          FilterChip(
            selected = isSelected,
            onClick = { selectedCategory = cat },
            label = {
              Text(
                text = cat,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 12.sp
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = CanvaPurple,
              selectedLabelColor = Color.White,
              containerColor = if (isDark) DarkCardElevated else LightCardElevated,
              labelColor = textSecondary
            )
          )
        }
      }
    }

    item { Spacer(modifier = Modifier.height(18.dp)) }

    // Şablon Kartları
    items(filteredTemplates) { template ->
      Surface(
        onClick = { viewModel.openTemplate(template) },
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        shadowElevation = if (isDark) 2.dp else 4.dp,
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp)
          .testTag("template_list_item_${template.id}")
      ) {
        Column {
          // Banner
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(130.dp)
              .background(
                brush = Brush.linearGradient(
                  listOf(Color(template.gradientStartHex), Color(template.gradientEndHex))
                )
              )
          ) {
            Text(
              text = template.iconEmoji,
              fontSize = 38.sp,
              modifier = Modifier.align(Alignment.Center)
            )

            // Rozet
            template.badgeText?.let { badge ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (template.isPro) CanvaAmber else CanvaPurple,
                modifier = Modifier
                  .padding(10.dp)
                  .align(Alignment.TopEnd)
              ) {
                Text(
                  text = badge,
                  color = if (template.isPro) Color.Black else Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.ExtraBold,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
              }
            }

            // Çözünürlük rozeti
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color.Black.copy(alpha = 0.65f),
              modifier = Modifier
                .padding(8.dp)
                .align(Alignment.BottomStart)
            ) {
              Text(
                text = "${template.dimensions} • ${template.category}",
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }

          // Açıklama ve Buton
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = template.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
              Text(
                text = "${template.usageCount} içerik üretici bu şablonu kullandı",
                fontSize = 11.sp,
                color = textSecondary
              )
            }

            Button(
              onClick = { viewModel.openTemplate(template) },
              colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple),
              shape = RoundedCornerShape(12.dp)
            ) {
              Text("Şablonu Kullan", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
          }
        }
      }
    }
  }
}
