package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TrendAudio
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.StudioSubTab
import com.example.ui.viewmodel.StudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrendScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val isDark = uiState.isDarkTheme

  val bgColor = if (isDark) DarkBg else LightBg
  val cardBg = if (isDark) DarkCard else LightCard
  val cardBorder = if (isDark) DarkCardBorder else LightCardBorder
  val textPrimary = if (isDark) TextPrimary else LightTextPrimary
  val textSecondary = if (isDark) TextSecondary else LightTextSecondary
  val textMuted = if (isDark) TextMuted else LightTextMuted

  var selectedTab by remember { mutableStateOf("🔥 Trend Sesler") }
  val tabs = listOf("🔥 Trend Sesler", "🎬 Video Şablonları", "⚡ Viral Konseptler")

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(bgColor)
      .testTag("trend_screen_scroll"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Başlık
    item {
      Column {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text("📈", fontSize = 24.sp)
          Text(
            text = "Haftanın TikTok & Reels Trendleri",
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            color = textPrimary
          )
        }
        Text(
          text = "Yapay zeka analizli viral sesler, şablonlar ve 30 günlük içerik fikirleri",
          fontSize = 12.sp,
          color = textMuted
        )
      }
    }

    // Sekmeler
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        tabs.forEach { tab ->
          val isSelected = tab == selectedTab
          FilterChip(
            selected = isSelected,
            onClick = { selectedTab = tab },
            label = { Text(tab, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = CanvaPurple,
              selectedLabelColor = Color.White,
              containerColor = if (isDark) DarkCardElevated else LightCardElevated,
              labelColor = textSecondary
            )
          )
        }
      }
    }

    // Trend Sesler Listesi
    items(uiState.trendAudios.ifEmpty { viewModel.repositoryTrendAudios() }) { audio ->
      val isPlaying = uiState.activePlayingAudioId == audio.id
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, if (isPlaying) NeonCyan else cardBorder),
        shadowElevation = if (isPlaying) 6.dp else 2.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            // Çal/Duraklat Butonu
            IconButton(
              onClick = { viewModel.toggleTrendAudioPlayback(audio.id) },
              modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(if (isPlaying) CanvaPurple else (if (isDark) DarkCardElevated else LightCardElevated))
            ) {
              Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = "Oynat",
                tint = if (isPlaying) Color.White else CanvaPurple,
                modifier = Modifier.size(24.dp)
              )
            }

            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = audio.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
              Text(
                text = "${audio.artist} • ${audio.category} (${audio.durationSec}s)",
                fontSize = 11.sp,
                color = textSecondary
              )
            }

            // Büyüme Oranı Rozeti
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = EmeraldTech.copy(alpha = 0.15f)
            ) {
              Text(
                text = "🔥 ${audio.growthPercent}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldTech,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }

          // Ses Dalga Formu Çizgileri
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .height(28.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(if (isDark) DarkBg.copy(alpha = 0.5f) else LightCardElevated)
              .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            audio.waveformPoints.forEach { point ->
              Box(
                modifier = Modifier
                  .width(3.dp)
                  .fillMaxHeight(point)
                  .clip(RoundedCornerShape(2.dp))
                  .background(if (isPlaying) NeonCyan else CanvaPurple.copy(alpha = 0.6f))
              )
            }
          }

          // Alt Bilgi & Projeye Ekle Butonu
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "📊 ${audio.usageCount} içerikte kullanıldı",
              fontSize = 10.sp,
              color = textMuted
            )

            Button(
              onClick = { viewModel.applyTrendAudioToTimeline(audio) },
              colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple),
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Videoya Ekle", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // 30 Günlük Otomatik Shorts Tanıtım Kartı
    item {
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isDark) DarkCardElevated else Color(0xFFF3E8FF),
        border = BorderStroke(1.2.dp, CanvaPurple.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🪄", fontSize = 22.sp)
            Text(
              text = "30 Günlük Otomatik İçerik Fabrikası",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = textPrimary
            )
          }
          Text(
            text = "CSV veya TXT listenizi yükleyin; yapay zeka 30 gün boyunca her güne 1 adet 9:16 Shorts/Reels videosunu hazır altyazılı ve seslendirmeli olarak render alsın.",
            fontSize = 12.sp,
            color = textSecondary
          )
          Button(
            onClick = { viewModel.openBatchAutomationDialog(true) },
            colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text("🚀 30 Günlük Otomasyonu Başlat", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}
