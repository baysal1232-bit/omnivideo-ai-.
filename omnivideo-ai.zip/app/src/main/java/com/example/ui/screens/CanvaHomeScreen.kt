package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.StudioSubTab
import com.example.ui.viewmodel.StudioUiState
import com.example.ui.viewmodel.StudioViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CanvaHomeScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val focusManager = LocalFocusManager.current
  val isDark = uiState.isDarkTheme

  // Glassmorphism ve Cyberpunk tema renkleri
  val bgColor = if (isDark) DarkBg else LightBg
  val surfaceColor = if (isDark) DarkSurface else LightSurface
  val cardBgColor = if (isDark) Color(0xDD111827) else LightCard
  val cardBorderColor = if (isDark) Color(0x5538BDF8) else LightCardBorder
  val textPrimaryColor = if (isDark) TextPrimary else LightTextPrimary
  val textSecondaryColor = if (isDark) TextSecondary else LightTextSecondary
  val textMutedColor = if (isDark) TextMuted else LightTextMuted

  // Crown & Live Credit Pulsing animasyonu
  val infiniteTransition = rememberInfiniteTransition(label = "pulse")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 1f,
    targetValue = 1.05f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "scale"
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(bgColor)
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .testTag("canva_home_scroll"),
      contentPadding = PaddingValues(bottom = 110.dp)
    ) {
      // 1. ÜST BAR
      // Sol: Kullanıcı Profili | Orta: Arama / Prompt | Sağ: Canlı ⚡ 85 AI Kredisi, 👑 Planınızı Yükseltin, Dışa Aktar (4K)
      item {
        OmniTopBar(
          userName = uiState.userName,
          aiCredits = uiState.aiCredits,
          isDark = isDark,
          pulseScale = pulseScale,
          onUpgradeClick = { viewModel.openPricingDialog("Canva Pro VIP Planı") },
          onExport4kClick = { viewModel.trigger4kExport() },
          onToggleTheme = { viewModel.toggleTheme() },
          textPrimary = textPrimaryColor,
          textMuted = textMutedColor,
          cardBorder = cardBorderColor
        )
      }

      // 2. ORTA: 'Bugün ne tasarlayacaksınız?' Arama ve AI Prompt Barı
      item {
        SearchAndPromptBar(
          searchQuery = uiState.homeSearchQuery,
          onSearchChange = { viewModel.setHomeSearchQuery(it) },
          onExecuteAiPrompt = { prompt ->
            if (prompt.isNotBlank()) {
              viewModel.setAiPrompt(prompt)
              viewModel.setTab(MainNavigationTab.AI_STUDIO)
              viewModel.setStudioSubTab(StudioSubTab.AI_ENGINES)
              viewModel.triggerGenerateVideo()
              focusManager.clearFocus()
            }
          },
          isDark = isDark,
          textPrimary = textPrimaryColor,
          textSecondary = textSecondaryColor,
          cardBg = cardBgColor,
          cardBorder = cardBorderColor
        )
      }

      item { Spacer(modifier = Modifier.height(14.dp)) }

      // 3. HIZLI ARAÇ KATEGORİLERİ (6 Modül)
      // '🎥 Dikey Video (9:16)' & '🎬 Yatay Video (16:9)', '🖼️ Görsel Editör', '🪄 30 Günlük Toplu İçerik Üretici', '🎙️ AI Ses Klonlama & Gürültü Temizleme', '🚀 Otomatik Sosyal Medya Paylaşımı'
      item {
        QuickToolCategoriesSection(
          onVerticalVideo = { viewModel.launchNewVideo(AspectRatioType.PORTRAIT_9_16) },
          onHorizontalVideo = { viewModel.launchNewVideo(AspectRatioType.LANDSCAPE_16_9) },
          onGraphicEditor = { viewModel.launchGraphicEditor() },
          onBatchShorts = { viewModel.openBatchAutomationDialog(true) },
          onVoiceClone = { viewModel.openVoiceCloneDialog(true) },
          onSocialShare = { viewModel.openSocialShareDialog(true) },
          textPrimary = textPrimaryColor,
          textSecondary = textSecondaryColor
        )
      }

      item { Spacer(modifier = Modifier.height(20.dp)) }

      // 4. ORTA ALAN: SÜRÜKLE-BIRAK DESTEKLİ CANLI TUVAL VE TRENDLER
      item {
        LiveCanvasAndTrendsSection(
          viewModel = viewModel,
          uiState = uiState,
          isDark = isDark,
          textPrimary = textPrimaryColor,
          textSecondary = textSecondaryColor,
          cardBg = cardBgColor,
          cardBorder = cardBorderColor
        )
      }

      item { Spacer(modifier = Modifier.height(24.dp)) }

      // 5. YAPAY ZEKA VE OTOMASYON STÜDYOSU
      // 10 Sahne Toplu AI Video, ElevenLabs & Whisper, Dudak Senkronlu Çeviri (Lip-Sync), Dekupe & SFX
      item {
        AiAutomationStudioSection(
          viewModel = viewModel,
          uiState = uiState,
          isDark = isDark,
          textPrimary = textPrimaryColor,
          textSecondary = textSecondaryColor,
          cardBg = cardBgColor,
          cardBorder = cardBorderColor
        )
      }

      item { Spacer(modifier = Modifier.height(24.dp)) }

      // 6. ALT PANEL: MODÜLER ÇOKLU İZ ZAMAN ÇİZELGESİ (TIMELINE)
      // Video, ses dalga formu, altyazı ve B-Roll katmanlarının uç uca dizildiği çoklu iz timeline
      item {
        MultiTrackTimelinePreviewSection(
          viewModel = viewModel,
          uiState = uiState,
          isDark = isDark,
          textPrimary = textPrimaryColor,
          textSecondary = textSecondaryColor,
          cardBg = cardBgColor,
          cardBorder = cardBorderColor
        )
      }

      item { Spacer(modifier = Modifier.height(24.dp)) }

      // 7. TASARIMA DEVAM EDİN (Yatay Önizleme Kartları)
      item {
        RecentProjectsSection(
          recentProjects = viewModel.recentProjects,
          onProjectClick = { proj -> viewModel.openRecentProject(proj) },
          onViewAll = { viewModel.setTab(MainNavigationTab.DESIGNS) },
          textPrimary = textPrimaryColor,
          textSecondary = textSecondaryColor,
          cardBg = cardBgColor,
          cardBorder = cardBorderColor,
          isDark = isDark
        )
      }
    }

    // SAĞ ALT YÜZEN BUTON (FAB): Dikkat çeken parlak mor yuvarlak kamera butonu
    Box(
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(bottom = 16.dp, end = 16.dp)
    ) {
      FloatingActionButton(
        onClick = { viewModel.setQuickCreateSheet(true) },
        shape = CircleShape,
        containerColor = Color.Transparent,
        contentColor = Color.White,
        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp, pressedElevation = 12.dp),
        modifier = Modifier
          .size(60.dp)
          .shadow(10.dp, CircleShape, spotColor = CanvaPurple)
          .background(
            brush = Brush.linearGradient(listOf(CanvaPurple, CanvaIndigo, CanvaCyan)),
            shape = CircleShape
          )
          .testTag("fab_quick_create")
      ) {
        Icon(
          imageVector = Icons.Default.Videocam,
          contentDescription = "Hızlı Başlat (Kamera)",
          modifier = Modifier.size(30.dp),
          tint = Color.White
        )
      }
    }

    // ------------------- DİYALOGLAR & MODALLAR -------------------

    // 30 Günlük Toplu İçerik Üretici Modalı
    if (uiState.showBatchAutomationDialog) {
      BatchShortsAutomationDialog(
        automation = uiState.batchShortsAutomation,
        onConfirm = { viewModel.startBatchShortsGeneration() },
        onDismiss = { viewModel.openBatchAutomationDialog(false) },
        textPrimary = textPrimaryColor,
        textSecondary = textSecondaryColor,
        cardBg = cardBgColor
      )
    }

    // AI Ses Klonlama & Gürültü Temizleme Modalı
    if (uiState.showVoiceCloneDialog) {
      VoiceCloneDialog(
        voiceCloneState = uiState.voiceCloneState,
        onStartRecording = { viewModel.startVoiceRecording() },
        onToggleNoise = { viewModel.toggleNoiseCleanup() },
        onDismiss = { viewModel.openVoiceCloneDialog(false) },
        textPrimary = textPrimaryColor,
        textSecondary = textSecondaryColor,
        cardBg = cardBgColor
      )
    }

    // Dudak Senkronu (Lip-Sync) Modalı
    if (uiState.showLipSyncDialog) {
      LipSyncDialog(
        currentLanguage = uiState.lipSyncConfig.targetLanguage,
        onApply = { lang -> viewModel.applyLipSync(lang) },
        onOpenUpscale = {
          viewModel.openLipSyncDialog(false)
          viewModel.openUpscaleDialog(true)
        },
        onDismiss = { viewModel.openLipSyncDialog(false) },
        textPrimary = textPrimaryColor,
        textSecondary = textSecondaryColor,
        cardBg = cardBgColor
      )
    }

    // 4K AI Upscale Modalı
    if (uiState.showUpscaleDialog) {
      Video4kUpscaleDialog(
        upscaleState = uiState.videoUpscaleState,
        onStartUpscale = { viewModel.start4kUpscale() },
        onDismiss = { viewModel.openUpscaleDialog(false) },
        textPrimary = textPrimaryColor,
        textSecondary = textSecondaryColor,
        cardBg = cardBgColor
      )
    }

    // Otomatik Sosyal Medya Paylaşımı Modalı
    if (uiState.showSocialShareDialog) {
      SocialMediaShareDialog(
        platforms = uiState.socialPlatforms,
        onConfirmPost = { viewModel.startSocialAutoPost() },
        onDismiss = { viewModel.openSocialShareDialog(false) },
        textPrimary = textPrimaryColor,
        textSecondary = textSecondaryColor,
        cardBg = cardBgColor
      )
    }

    // Otomatik SFX Modalı
    if (uiState.showAutoSfxDialog) {
      AutoSfxDialog(
        sfxPresets = viewModel.sampleSfxPresets,
        onSelectSfx = { preset -> viewModel.applyAutoSfx(preset) },
        onDismiss = { viewModel.openAutoSfxDialog(false) },
        textPrimary = textPrimaryColor,
        textSecondary = textSecondaryColor,
        cardBg = cardBgColor
      )
    }

    // Hızlı Başlatma Alt Menüsü
    if (uiState.showQuickCreateSheet) {
      ModalBottomSheet(
        onDismissRequest = { viewModel.setQuickCreateSheet(false) },
        containerColor = if (isDark) DarkSurface else LightSurface,
        scrimColor = Color.Black.copy(alpha = 0.5f),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
      ) {
        QuickCreateMenuSheet(
          onClose = { viewModel.setQuickCreateSheet(false) },
          onVertical = {
            viewModel.setQuickCreateSheet(false)
            viewModel.launchNewVideo(AspectRatioType.PORTRAIT_9_16)
          },
          onHorizontal = {
            viewModel.setQuickCreateSheet(false)
            viewModel.launchNewVideo(AspectRatioType.LANDSCAPE_16_9)
          },
          onBatch30Days = {
            viewModel.setQuickCreateSheet(false)
            viewModel.openBatchAutomationDialog(true)
          },
          onVoiceClone = {
            viewModel.setQuickCreateSheet(false)
            viewModel.openVoiceCloneDialog(true)
          },
          onGraphic = {
            viewModel.setQuickCreateSheet(false)
            viewModel.launchGraphicEditor()
          }
        )
      }
    }
  }
}

// ============================================================================
// 1. ÜST BAR
// ============================================================================
@Composable
private fun OmniTopBar(
  userName: String,
  aiCredits: Int,
  isDark: Boolean,
  pulseScale: Float,
  onUpgradeClick: () -> Unit,
  onExport4kClick: () -> Unit,
  onToggleTheme: () -> Unit,
  textPrimary: Color,
  textMuted: Color,
  cardBorder: Color
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .statusBarsPadding()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Sol: Profil Avatarı ve Kullanıcı Adı
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(
              brush = Brush.linearGradient(listOf(NeonCyan, CyberPurple, CanvaGold))
            )
            .padding(2.dp),
          contentAlignment = Alignment.Center
        ) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .clip(CircleShape)
              .background(if (isDark) DarkSurface else LightSurface),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = userName.take(1).uppercase(),
              fontSize = 17.sp,
              fontWeight = FontWeight.ExtraBold,
              color = NeonCyan
            )
          }
        }

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = userName,
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = textPrimary
            )
            Text(text = " 👋", fontSize = 14.sp)
          }
          Text(
            text = "AI Video & Görsel Stüdyosu",
            fontSize = 10.sp,
            color = textMuted,
            fontWeight = FontWeight.Medium
          )
        }
      }

      // Sağ: Canlı '⚡ 85 AI Kredisi' + '👑 Planınızı Yükseltin' + 'Dışa Aktar (4K)'
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Canlı AI Kredisi Göstergesi
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = NeonCyan.copy(alpha = 0.15f),
          border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.4f))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Text(text = "⚡", fontSize = 11.sp)
            Text(
              text = "$aiCredits Kredi",
              fontSize = 11.sp,
              fontWeight = FontWeight.ExtraBold,
              color = if (isDark) NeonCyan else CanvaPurple
            )
          }
        }

        // '👑 Planınızı Yükseltin' Rozeti
        Surface(
          onClick = onUpgradeClick,
          shape = RoundedCornerShape(16.dp),
          color = Color(0xFF6B21A8).copy(alpha = 0.8f),
          border = BorderStroke(1.dp, CanvaGold.copy(alpha = 0.6f)),
          modifier = Modifier.testTag("btn_upgrade_badge")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Text(text = "👑", fontSize = 11.sp)
            Text(
              text = "Yükselt",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = CanvaGold
            )
          }
        }

        // 'Dışa Aktar (4K)' Butonu
        Button(
          onClick = onExport4kClick,
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
          modifier = Modifier
            .height(32.dp)
            .shadow(4.dp, RoundedCornerShape(16.dp), spotColor = CanvaPurple)
            .clip(RoundedCornerShape(16.dp))
            .background(
              brush = Brush.horizontalGradient(listOf(CanvaPurple, CanvaBlue))
            )
            .testTag("btn_export_4k")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(Icons.Default.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
            Text(
              text = "Dışa Aktar (4K)",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }
      }
    }
  }
}

// ============================================================================
// 2. BAŞLIK VE ARAMA / AI PROMPT KUTUSU
// ============================================================================
@Composable
private fun SearchAndPromptBar(
  searchQuery: String,
  onSearchChange: (String) -> Unit,
  onExecuteAiPrompt: (String) -> Unit,
  isDark: Boolean,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color,
  cardBorder: Color
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 4.dp)
  ) {
    Text(
      text = "Bugün ne tasarlayacaksınız?",
      fontSize = 22.sp,
      fontWeight = FontWeight.ExtraBold,
      color = textPrimary,
      lineHeight = 28.sp,
      modifier = Modifier.padding(bottom = 10.dp)
    )

    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .shadow(
          elevation = if (isDark) 4.dp else 6.dp,
          shape = RoundedCornerShape(26.dp),
          spotColor = NeonCyan.copy(alpha = 0.25f)
        )
        .border(
          width = 1.2.dp,
          brush = Brush.horizontalGradient(
            listOf(CanvaPurple.copy(alpha = 0.6f), NeonCyan.copy(alpha = 0.5f), CyberPurple.copy(alpha = 0.5f))
          ),
          shape = RoundedCornerShape(26.dp)
        ),
      shape = RoundedCornerShape(26.dp),
      color = cardBg
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.Search,
          contentDescription = "Ara",
          tint = NeonCyan,
          modifier = Modifier.size(20.dp)
        )

        Spacer(modifier = Modifier.width(8.dp))

        TextField(
          value = searchQuery,
          onValueChange = onSearchChange,
          placeholder = {
            Text(
              text = "Ne oluşturmak istiyorsunuz? veya AI Prompt yazın...",
              fontSize = 12.sp,
              color = textSecondary.copy(alpha = 0.7f),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          },
          singleLine = true,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
          keyboardActions = KeyboardActions(onSearch = { onExecuteAiPrompt(searchQuery) }),
          colors = TextFieldDefaults.colors(
            focusedContainerColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent,
            disabledContainerColor = Color.Transparent,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            focusedTextColor = textPrimary,
            unfocusedTextColor = textPrimary
          ),
          modifier = Modifier
            .weight(1f)
            .testTag("input_search_prompt")
        )

        IconButton(
          onClick = { onExecuteAiPrompt(searchQuery) },
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(
              brush = Brush.linearGradient(listOf(NeonCyan, CanvaPurple))
            )
            .testTag("btn_search_ai_execute")
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = "AI Üret",
            tint = Color.White,
            modifier = Modifier.size(17.dp)
          )
        }
      }
    }
  }
}

// ============================================================================
// 3. HIZLI ARAÇ KATEGORİLERİ (MODÜLLER)
// ============================================================================
@Composable
private fun QuickToolCategoriesSection(
  onVerticalVideo: () -> Unit,
  onHorizontalVideo: () -> Unit,
  onGraphicEditor: () -> Unit,
  onBatchShorts: () -> Unit,
  onVoiceClone: () -> Unit,
  onSocialShare: () -> Unit,
  textPrimary: Color,
  textSecondary: Color
) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 2.dp)
    ) {
      Text(
        text = "Hızlı Araç Kategorileri",
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = textPrimary
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    LazyRow(
      modifier = Modifier.fillMaxWidth(),
      contentPadding = PaddingValues(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // 1. Dikey Video (9:16)
      item {
        ModuleCircleItem(
          emoji = "🎥",
          title = "Dikey Video",
          ratio = "9:16",
          subtitle = "TikTok/Shorts",
          gradient = listOf(Color(0xFFFF007A), Color(0xFF7928CA)),
          onClick = onVerticalVideo
        )
      }

      // 2. Yatay Video (16:9)
      item {
        ModuleCircleItem(
          emoji = "🎬",
          title = "Yatay Video",
          ratio = "16:9",
          subtitle = "YouTube 4K",
          gradient = listOf(Color(0xFF0070F3), Color(0xFF00DFD8)),
          onClick = onHorizontalVideo
        )
      }

      // 3. Görsel Editör (Canva Stili)
      item {
        ModuleCircleItem(
          emoji = "🖼️",
          title = "Görsel Editör",
          ratio = "Canva",
          subtitle = "Katmanlı Tuval",
          gradient = listOf(Color(0xFFFF8008), Color(0xFFFFC837)),
          onClick = onGraphicEditor
        )
      }

      // 4. 30 Günlük Toplu İçerik Üretici (CSV/TXT)
      item {
        ModuleCircleItem(
          emoji = "🪄",
          title = "30 Günlük",
          ratio = "Toplu AI",
          subtitle = "CSV/TXT Shorts",
          gradient = listOf(Color(0xFF7928CA), Color(0xFFFF0080)),
          badge = "OTOMASYON",
          onClick = onBatchShorts
        )
      }

      // 5. AI Ses Klonlama & Gürültü Temizleme
      item {
        ModuleCircleItem(
          emoji = "🎙️",
          title = "Ses Klonlama",
          ratio = "& Temizleme",
          subtitle = "10 Sn TTS & -32dB",
          gradient = listOf(Color(0xFF10B981), Color(0xFF06B6D4)),
          badge = "YENİ",
          onClick = onVoiceClone
        )
      }

      // 6. Otomatik Sosyal Medya Paylaşımı
      item {
        ModuleCircleItem(
          emoji = "🚀",
          title = "Oto Paylaşım",
          ratio = "Social",
          subtitle = "TikTok/IG/Shorts",
          gradient = listOf(Color(0xFF8B5CF6), Color(0xFF06B6D4)),
          badge = "AUTO",
          onClick = onSocialShare
        )
      }
    }
  }
}

@Composable
private fun ModuleCircleItem(
  emoji: String,
  title: String,
  ratio: String,
  subtitle: String,
  gradient: List<Color>,
  badge: String? = null,
  onClick: () -> Unit
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .width(76.dp)
      .clickable(onClick = onClick)
  ) {
    Box(contentAlignment = Alignment.TopEnd) {
      Box(
        modifier = Modifier
          .size(58.dp)
          .shadow(6.dp, CircleShape, spotColor = gradient.first())
          .clip(CircleShape)
          .background(Brush.linearGradient(gradient)),
        contentAlignment = Alignment.Center
      ) {
        Text(text = emoji, fontSize = 26.sp)
      }

      badge?.let {
        Surface(
          shape = CircleShape,
          color = CanvaAmber,
          modifier = Modifier.offset(x = 6.dp, y = (-2).dp)
        ) {
          Text(
            text = it,
            color = Color.Black,
            fontSize = 7.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = "$title ($ratio)",
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      textAlign = TextAlign.Center,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
    Text(
      text = subtitle,
      fontSize = 8.sp,
      color = Color.Gray,
      textAlign = TextAlign.Center,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
  }
}

// ============================================================================
// 4. ORTA ALAN: SÜRÜKLE-BIRAK DESTEKLİ CANLI TUVAL VE TRENDLER
// ============================================================================
@Composable
private fun LiveCanvasAndTrendsSection(
  viewModel: StudioViewModel,
  uiState: StudioUiState,
  isDark: Boolean,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color,
  cardBorder: Color
) {
  val isVertical = uiState.currentAspect == AspectRatioType.PORTRAIT_9_16

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Bölüm Başlığı & En-Boy Seçici
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(text = "🎨", fontSize = 18.sp)
        Text(
          text = "Canlı Tuval (Sürükle-Bırak)",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = textPrimary
        )
      }

      // En-boy geçişi (9:16 vs 16:9)
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(12.dp))
          .background(if (isDark) DarkCardElevated else LightCardElevated)
          .padding(2.dp)
      ) {
        Surface(
          onClick = { viewModel.setAspectRatio(AspectRatioType.PORTRAIT_9_16) },
          shape = RoundedCornerShape(10.dp),
          color = if (isVertical) CanvaPurple else Color.Transparent
        ) {
          Text(
            text = "9:16 Dikey",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (isVertical) Color.White else textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }

        Surface(
          onClick = { viewModel.setAspectRatio(AspectRatioType.LANDSCAPE_16_9) },
          shape = RoundedCornerShape(10.dp),
          color = if (!isVertical) CanvaPurple else Color.Transparent
        ) {
          Text(
            text = "16:9 Yatay",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (!isVertical) Color.White else textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }
    }

    // CANLI TUVAL KARTI (Sürükle-Bırak Destekli)
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = cardBg,
      border = BorderStroke(1.2.dp, cardBorder),
      shadowElevation = if (isDark) 6.dp else 4.dp,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("live_canvas_card")
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        // Tuval Alanı
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(if (isVertical) 240.dp else 190.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF030712))
            .pointerInput(Unit) {
              detectDragGestures { change, dragAmount ->
                change.consume()
                viewModel.updateCanvasDrag(dragAmount.x, dragAmount.y)
              }
            },
          contentAlignment = Alignment.Center
        ) {
          // Canlı Arka Plan Gradyanı & Siber Izgara
          Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRect(
              brush = Brush.radialGradient(
                listOf(Color(0xFF1E1B4B), Color(0xFF030712)),
                center = Offset(w * 0.5f, h * 0.5f),
                radius = w * 0.7f
              )
            )
          }

          // SÜRÜKLENEBİLİR VİDEO VE GRAFİK KATMANI (PARMAKLA TAŞINABİLİR)
          Box(
            modifier = Modifier
              .offset {
                IntOffset(
                  uiState.canvasDragOffsetX.roundToInt(),
                  uiState.canvasDragOffsetY.roundToInt()
                )
              }
              .size(if (isVertical) 130.dp else 240.dp, if (isVertical) 210.dp else 140.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(
                brush = Brush.linearGradient(
                  if (uiState.smartBgRemoved) {
                    listOf(Color(0x3300D2FF), Color(0x337C3AED))
                  } else {
                    listOf(Color(0xFF4C1D95), Color(0xFF1E3A8A), Color(0xFF0F172A))
                  }
                )
              )
              .border(1.dp, NeonCyan, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center,
              modifier = Modifier.padding(8.dp)
            ) {
              Text(text = "🎥", fontSize = 32.sp)
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Siber Metropol & Gelecek",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
              )
              Text(
                text = "👆 Sürükle & Bırak ile Konumlandır",
                fontSize = 8.sp,
                color = NeonCyan,
                textAlign = TextAlign.Center
              )
            }
          }

          // Otomatik Whisper Altyazı Akışı (Karaoke)
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.Black.copy(alpha = 0.75f),
            modifier = Modifier
              .align(Alignment.BottomCenter)
              .padding(bottom = 12.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Text("Geleceğin", fontSize = 11.sp, color = Color.White)
              Text(
                "Yapay Zeka",
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = CanvaAmber
              )
              Text("Şehirleri Burada Doğuyor", fontSize = 11.sp, color = Color.White)
            }
          }

          // Tuval Rozetleri (rembg & Lip-Sync durumu)
          Row(
            modifier = Modifier
              .align(Alignment.TopStart)
              .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            if (uiState.smartBgRemoved) {
              Surface(shape = RoundedCornerShape(6.dp), color = EmeraldTech) {
                Text(
                  "🪄 rembg Dekupe",
                  fontSize = 8.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.Black,
                  modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                )
              }
            }
            Surface(shape = RoundedCornerShape(6.dp), color = CanvaPurple) {
              Text(
                "🗣️ Lip-Sync",
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
              )
            }
          }

          // Konum Sıfırla Butonu
          if (uiState.canvasDragOffsetX != 0f || uiState.canvasDragOffsetY != 0f) {
            IconButton(
              onClick = { viewModel.resetCanvasDrag() },
              modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .size(28.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.6f))
            ) {
              Icon(Icons.Default.Refresh, contentDescription = "Merkeze Hizala", tint = Color.White, modifier = Modifier.size(16.dp))
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Tuval Kurgu Hızlı Araçları (Canva + CapCut Birlikteliği)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
              selected = uiState.smartBgRemoved,
              onClick = { viewModel.toggleRembg() },
              label = { Text("🪄 Dekupe (rembg)", fontSize = 10.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = EmeraldTech,
                selectedLabelColor = Color.Black
              )
            )

            FilterChip(
              selected = false,
              onClick = { viewModel.openLipSyncDialog(true) },
              label = { Text("🗣️ Dudak Senkronu", fontSize = 10.sp) }
            )

            FilterChip(
              selected = false,
              onClick = { viewModel.openAutoSfxDialog(true) },
              label = { Text("⚡ Otomatik SFX", fontSize = 10.sp) }
            )
          }

          IconButton(
            onClick = {
              viewModel.setTab(MainNavigationTab.AI_STUDIO)
              viewModel.setStudioSubTab(StudioSubTab.DUAL_TIMELINE)
            },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(Icons.Default.Fullscreen, contentDescription = "Tam Ekran Kurgu", tint = NeonCyan)
          }
        }
      }
    }

    // 🔥 HAFTANIN TIKTOK / REELS TREND SES VE ŞABLONLARI PANELİ
    Column(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(text = "🔥", fontSize = 18.sp)
          Text(
            text = "Haftanın TikTok & Reels Trend Sesleri",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = textPrimary
          )
        }

        TextButton(
          onClick = { viewModel.setTab(MainNavigationTab.TRENDS) },
          contentPadding = PaddingValues(0.dp)
        ) {
          Text("Tümü", fontSize = 12.sp, color = NeonCyan, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        val audios: List<TrendAudio> = if (uiState.trendAudios.isNotEmpty()) uiState.trendAudios else viewModel.trendAudios
        items(audios) { audio: TrendAudio ->
          val isPlaying = uiState.activePlayingAudioId == audio.id
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = cardBg,
            border = BorderStroke(1.dp, if (isPlaying) NeonCyan else cardBorder),
            modifier = Modifier.width(220.dp)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                IconButton(
                  onClick = { viewModel.toggleTrendAudioPlayback(audio.id) },
                  modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (isPlaying) CanvaPurple else (if (isDark) DarkCardElevated else LightCardElevated))
                ) {
                  Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = if (isPlaying) Color.White else CanvaPurple,
                    modifier = Modifier.size(18.dp)
                  )
                }

                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = audio.title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                  Text(
                    text = "${audio.artist} • ${audio.durationSec}s",
                    fontSize = 10.sp,
                    color = textSecondary
                  )
                }

                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = EmeraldTech.copy(alpha = 0.2f)
                ) {
                  Text(
                    text = audio.growthPercent,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldTech,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              // Ses Dalgası Çizgileri
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(18.dp)
                  .clip(RoundedCornerShape(4.dp))
                  .background(if (isDark) DarkBg else LightCardElevated)
                  .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                audio.waveformPoints.forEach { point ->
                  Box(
                    modifier = Modifier
                      .width(2.5.dp)
                      .height((18 * point).dp)
                      .clip(RoundedCornerShape(2.dp))
                      .background(if (isPlaying) NeonCyan else CanvaPurple.copy(alpha = 0.5f))
                  )
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              Button(
                onClick = { viewModel.applyTrendAudioToTimeline(audio) },
                colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(vertical = 4.dp),
                modifier = Modifier.fillMaxWidth().height(30.dp)
              ) {
                Text("+ Kurguya Ekle", fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

// ============================================================================
// 5. YAPAY ZEKA VE OTOMASYON STÜDYOSU PANELİ
// ============================================================================
@Composable
private fun AiAutomationStudioSection(
  viewModel: StudioViewModel,
  uiState: StudioUiState,
  isDark: Boolean,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color,
  cardBorder: Color
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Text("✨", fontSize = 20.sp)
      Text(
        text = "Yapay Zeka ve Otomasyon Stüdyosu",
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = textPrimary
      )
    }

    // 2x2 Izgara Kartlar
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // 1. Kart: 10 Sahne Toplu AI Video (Veo 2 & Sora)
      Surface(
        onClick = { viewModel.launchAiVideoBatch() },
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        modifier = Modifier.weight(1f)
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(listOf(Color(0xFF7928CA), Color(0xFFFF0080)))),
            contentAlignment = Alignment.Center
          ) {
            Text("🪄", fontSize = 18.sp)
          }

          Text(
            text = "10 Sahne Toplu AI Video",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = textPrimary
          )
          Text(
            text = "Google Veo 2 & Sora ile 10 sahne üret ve birleştir",
            fontSize = 10.sp,
            color = textSecondary,
            lineHeight = 13.sp
          )
        }
      }

      // 2. Kart: ElevenLabs & Whisper Altyazı
      Surface(
        onClick = {
          viewModel.setTab(MainNavigationTab.AI_STUDIO)
          viewModel.setStudioSubTab(StudioSubTab.AUDIO_VOICE)
        },
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        modifier = Modifier.weight(1f)
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(listOf(Color(0xFF0070F3), Color(0xFF00DFD8)))),
            contentAlignment = Alignment.Center
          ) {
            Text("🎙️", fontSize = 18.sp)
          }

          Text(
            text = "ElevenLabs & Whisper",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = textPrimary
          )
          Text(
            text = "Doğal Türkçe seslendirme ve kelime kelime altyazı",
            fontSize = 10.sp,
            color = textSecondary,
            lineHeight = 13.sp
          )
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // 3. Kart: Dudak Senkronlu Çeviri & 4K Upscale
      Surface(
        onClick = { viewModel.openLipSyncDialog(true) },
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        modifier = Modifier.weight(1f)
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF06B6D4)))),
            contentAlignment = Alignment.Center
          ) {
            Text("🗣️", fontSize = 18.sp)
          }

          Text(
            text = "Dudak Senkronu & 4K Upscale",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = textPrimary
          )
          Text(
            text = "Tek tıkla çoklu dil Lip-Sync ve 4K AI Upscaling",
            fontSize = 10.sp,
            color = textSecondary,
            lineHeight = 13.sp
          )
        }
      }

      // 4. Kart: Dekupe & Otomatik SFX
      Surface(
        onClick = { viewModel.openAutoSfxDialog(true) },
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        modifier = Modifier.weight(1f)
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(listOf(Color(0xFFFF8008), Color(0xFFFFC837)))),
            contentAlignment = Alignment.Center
          ) {
            Text("💥", fontSize = 18.sp)
          }

          Text(
            text = "Dekupe & SFX",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = textPrimary
          )
          Text(
            text = "Arka plan silme ve otomatik vuruş ses efektleri",
            fontSize = 10.sp,
            color = textSecondary,
            lineHeight = 13.sp
          )
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // 5. Kart: Otomatik Sosyal Medya Paylaşımı
      Surface(
        onClick = { viewModel.openSocialShareDialog(true) },
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        modifier = Modifier.weight(1f)
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(listOf(Color(0xFF8B5CF6), Color(0xFF06B6D4)))),
            contentAlignment = Alignment.Center
          ) {
            Text("🚀", fontSize = 18.sp)
          }

          Text(
            text = "Oto Sosyal Paylaşım",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = textPrimary
          )
          Text(
            text = "TikTok, Reels ve Shorts doğrudan zamanlayıcı",
            fontSize = 10.sp,
            color = textSecondary,
            lineHeight = 13.sp
          )
        }
      }

      // 6. Kart: AI Ses Klonlama & Gürültü Temizleme
      Surface(
        onClick = { viewModel.openVoiceCloneDialog(true) },
        shape = RoundedCornerShape(16.dp),
        color = cardBg,
        border = BorderStroke(1.dp, cardBorder),
        modifier = Modifier.weight(1f)
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(listOf(Color(0xFFEC4899), Color(0xFF7C3AED)))),
            contentAlignment = Alignment.Center
          ) {
            Text("🎙️", fontSize = 18.sp)
          }

          Text(
            text = "Ses Klonlama & Filtre",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = textPrimary
          )
          Text(
            text = "10 Sn kendi sesinle TTS ve -32dB gürültü temizleme",
            fontSize = 10.sp,
            color = textSecondary,
            lineHeight = 13.sp
          )
        }
      }
    }
  }
}

// ============================================================================
// 6. ALT PANEL: MODÜLER ÇOKLU İZ ZAMAN ÇİZELGESİ (TIMELINE)
// ============================================================================
@Composable
private fun MultiTrackTimelinePreviewSection(
  viewModel: StudioViewModel,
  uiState: StudioUiState,
  isDark: Boolean,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color,
  cardBorder: Color
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("⏱️", fontSize = 18.sp)
        Text(
          text = "Modüler Çoklu İz Timeline",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = textPrimary
        )
      }

      Text(
        text = "00:03.20 / 02:00.00",
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = NeonCyan
      )
    }

    Surface(
      shape = RoundedCornerShape(18.dp),
      color = cardBg,
      border = BorderStroke(1.2.dp, cardBorder),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("timeline_preview_card")
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // İZ 1: Video Kurgu İzi (CapCut Sahneleri)
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text("🎥 Video", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = textSecondary, modifier = Modifier.width(46.dp))
          Row(
            modifier = Modifier
              .weight(1f)
              .height(26.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(if (isDark) DarkBg else LightCardElevated)
              .padding(2.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Box(
              modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF7C3AED)),
              contentAlignment = Alignment.Center
            ) {
              Text("Sahne 1 (Drone)", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
            Box(
              modifier = Modifier
                .weight(1.5f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF2563EB)),
              contentAlignment = Alignment.Center
            ) {
              Text("Sahne 2 (Neon Portre)", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
            Box(
              modifier = Modifier
                .weight(1.0f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF06B6D4)),
              contentAlignment = Alignment.Center
            ) {
              Text("Sahne 3 (Outro)", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
          }
        }

        // İZ 2: Ses Dalga Formu İzi (ElevenLabs + Arka Plan Müziği)
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text("🎵 Ses", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = textSecondary, modifier = Modifier.width(46.dp))
          Row(
            modifier = Modifier
              .weight(1f)
              .height(22.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(if (isDark) DarkBg else LightCardElevated)
              .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
          ) {
            repeat(28) { i ->
              val hFactor = if (i % 3 == 0) 0.9f else if (i % 2 == 0) 0.6f else 0.35f
              Box(
                modifier = Modifier
                  .width(3.dp)
                  .fillMaxHeight(hFactor)
                  .clip(RoundedCornerShape(1.dp))
                  .background(if (i < 12) NeonCyan else Color(0xFF6B7280))
              )
            }
          }
        }

        // İZ 3: Whisper Altyazı İzi
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text("🔤 Altyazı", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = textSecondary, modifier = Modifier.width(46.dp))
          Row(
            modifier = Modifier
              .weight(1f)
              .height(20.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(if (isDark) DarkBg else LightCardElevated)
              .padding(2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
          ) {
            Box(
              modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(4.dp))
                .background(CanvaGold.copy(alpha = 0.8f)),
              contentAlignment = Alignment.Center
            ) {
              Text("Geleceğin", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
            Box(
              modifier = Modifier
                .weight(1.3f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(4.dp))
                .background(CanvaGold.copy(alpha = 0.8f)),
              contentAlignment = Alignment.Center
            ) {
              Text("Yapay Zekası", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
            Box(
              modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(4.dp))
                .background(CanvaGold.copy(alpha = 0.8f)),
              contentAlignment = Alignment.Center
            ) {
              Text("Burada Doğuyor", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
          }
        }

        // İZ 4: B-Roll & SFX Katmanı
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text("💥 SFX", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = textSecondary, modifier = Modifier.width(46.dp))
          Row(
            modifier = Modifier
              .weight(1f)
              .height(20.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(if (isDark) DarkBg else LightCardElevated)
              .padding(2.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFFEF4444)) {
              Text("💨 Whoosh", fontSize = 7.sp, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
            }
            Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFFF59E0B)) {
              Text("⚡ Riser", fontSize = 7.sp, color = Color.Black, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
            }
            Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFF10B981)) {
              Text("💥 Boom Hit", fontSize = 7.sp, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
            }
          }
        }

        // Timeline Kontrol Butonları
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
              onClick = { viewModel.showToast("Sahne bölündü (Split)") },
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
              modifier = Modifier.height(28.dp)
            ) {
              Text("✂️ Böl", fontSize = 10.sp)
            }

            OutlinedButton(
              onClick = { viewModel.showToast("Crossfade geçiş efekti uygulandı") },
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
              modifier = Modifier.height(28.dp)
            ) {
              Text("🪄 AI Geçiş", fontSize = 10.sp)
            }
          }

          Button(
            onClick = {
              viewModel.setTab(MainNavigationTab.AI_STUDIO)
              viewModel.setStudioSubTab(StudioSubTab.DUAL_TIMELINE)
            },
            colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple),
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
            modifier = Modifier.height(28.dp)
          ) {
            Text("Zaman Çizelgesini Aç", fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

// ============================================================================
// 7. TASARIMA DEVAM EDİN
// ============================================================================
@Composable
private fun RecentProjectsSection(
  recentProjects: List<RecentProjectCard>,
  onProjectClick: (RecentProjectCard) -> Unit,
  onViewAll: () -> Unit,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color,
  cardBorder: Color,
  isDark: Boolean
) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Tasarıma Devam Edin",
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = textPrimary
      )

      TextButton(onClick = onViewAll) {
        Text("Tümü", fontSize = 12.sp, color = NeonCyan, fontWeight = FontWeight.Bold)
      }
    }

    LazyRow(
      modifier = Modifier.fillMaxWidth(),
      contentPadding = PaddingValues(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      items(recentProjects) { project ->
        val isVertical = project.aspectType == AspectRatioType.PORTRAIT_9_16
        Surface(
          onClick = { onProjectClick(project) },
          shape = RoundedCornerShape(16.dp),
          color = cardBg,
          border = BorderStroke(1.dp, cardBorder),
          modifier = Modifier.width(if (isVertical) 160.dp else 210.dp)
        ) {
          Column {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .background(
                  brush = Brush.linearGradient(
                    listOf(Color(project.primaryColorHex), Color(project.secondaryColorHex))
                  )
                ),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = if (isVertical) Icons.Default.StayCurrentPortrait else Icons.Default.Tv,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(28.dp)
              )

              Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.7f),
                modifier = Modifier
                  .align(Alignment.BottomEnd)
                  .padding(6.dp)
              ) {
                Text(
                  text = "${project.durationSeconds}s • ${project.sceneCount} Sahne",
                  color = Color.White,
                  fontSize = 8.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
              }
            }

            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = project.title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
              Text(
                text = project.lastEdited,
                fontSize = 9.sp,
                color = textSecondary
              )
            }
          }
        }
      }
    }
  }
}

// ============================================================================
// MODALLAR VE DİYALOGLAR
// ============================================================================
@Composable
private fun BatchShortsAutomationDialog(
  automation: BatchShortsAutomation,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("🪄", fontSize = 20.sp)
        Text("30 Günlük Otomatik Shorts Fabrikası", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "CSV veya TXT dosyasındaki 30 başlığı tek tıkla 9:16 dikey videolara dönüştürün:",
          fontSize = 12.sp,
          color = textSecondary
        )
        Surface(shape = RoundedCornerShape(10.dp), color = CanvaPurple.copy(alpha = 0.15f)) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("✅ 30 Farklı Sahne & AI Prompt Eşleme", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("✅ ElevenLabs Türkçe Metinden Seslendirme (TTS)", fontSize = 11.sp)
            Text("✅ OpenAI Whisper Karaoke Altyazı Yerleşimi", fontSize = 11.sp)
            Text("✅ TikTok, Reels ve Shorts Formatında 4K Export", fontSize = 11.sp)
          }
        }
      }
    },
    confirmButton = {
      Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple)) {
        Text("🚀 30 Videoyu Otomatik Üret", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Kapat") }
    }
  )
}

@Composable
private fun VoiceCloneDialog(
  voiceCloneState: VoiceCloneState,
  onStartRecording: () -> Unit,
  onToggleNoise: () -> Unit,
  onDismiss: () -> Unit,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("🎙️", fontSize = 20.sp)
        Text("AI Ses Klonlama & Gürültü Temizleme", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "Sadece 10 saniye mikrofonunuza konuşun; yapay zeka ses tonunuzu ve vurgularınızı klonlayarak tüm videolarda kendi sesinizle konuşmanızı sağlasın.",
          fontSize = 12.sp,
          color = textSecondary,
          textAlign = TextAlign.Center
        )

        Box(
          modifier = Modifier
            .size(70.dp)
            .clip(CircleShape)
            .background(if (voiceCloneState.isRecording) CoralRed else CanvaPurple)
            .clickable(enabled = !voiceCloneState.isRecording, onClick = onStartRecording),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (voiceCloneState.isRecording) Icons.Default.GraphicEq else Icons.Default.Mic,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(36.dp)
          )
        }

        if (voiceCloneState.isRecording) {
          Text(
            text = "Kayıt Alınıyor: ${voiceCloneState.sampleSecondsRecorded}/10 saniye...",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = CoralRed
          )
        } else {
          Text(
            text = voiceCloneState.cloneStatus,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = EmeraldTech
          )
        }

        // Noise cleanup toggle
        Surface(
          onClick = onToggleNoise,
          shape = RoundedCornerShape(10.dp),
          color = if (voiceCloneState.isNoiseCleanupActive) EmeraldTech.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.12f),
          border = BorderStroke(1.dp, if (voiceCloneState.isNoiseCleanupActive) EmeraldTech else Color.Transparent),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Text("🧹", fontSize = 16.sp)
              Column {
                Text("AI Gürültü Temizleme", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("-32dB stüdyo izolasyonu", fontSize = 10.sp, color = textSecondary)
              }
            }
            Switch(
              checked = voiceCloneState.isNoiseCleanupActive,
              onCheckedChange = { onToggleNoise() }
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onStartRecording,
        enabled = !voiceCloneState.isRecording,
        colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple)
      ) {
        Text(if (voiceCloneState.isRecording) "Kaydediliyor..." else "Kayıt Başlat (10 Sn)")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Kapat") }
    }
  )
}

@Composable
private fun LipSyncDialog(
  currentLanguage: String,
  onApply: (String) -> Unit,
  onOpenUpscale: () -> Unit,
  onDismiss: () -> Unit,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color
) {
  val languages = listOf("İngilizce (ABD)", "Almanca", "İspanyolca", "Arapça", "Fransızca", "Japonca")
  var selected by remember { mutableStateOf(currentLanguage) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("🗣️", fontSize = 20.sp)
        Text("Dudak Senkronlu Çeviri (Lip-Sync)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Videonuzu tek tıkla hedef dile çevirin. Konuşmacının ağız hareketleri hedef dildeki telaffuz ile %98 doğrulukla senkronlanır.",
          fontSize = 12.sp,
          color = textSecondary
        )
        languages.forEach { lang ->
          Surface(
            onClick = { selected = lang },
            shape = RoundedCornerShape(8.dp),
            color = if (selected == lang) CanvaPurple else Color.Transparent,
            border = BorderStroke(1.dp, if (selected == lang) CanvaPurple else Color.Gray.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = lang,
              fontSize = 12.sp,
              fontWeight = if (selected == lang) FontWeight.Bold else FontWeight.Normal,
              color = if (selected == lang) Color.White else textPrimary,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
          }
        }

        // Fast link to 4K upscale
        Surface(
          onClick = onOpenUpscale,
          shape = RoundedCornerShape(8.dp),
          color = CanvaCyan.copy(alpha = 0.15f),
          border = BorderStroke(1.dp, CanvaCyan.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Text("⚡", fontSize = 16.sp)
            Column {
              Text("Çeviri Sonrası 4K AI Upscale", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CanvaCyan)
              Text("Real-ESRGAN v3 ile 4K çözünürlüğe yükselt", fontSize = 10.sp, color = textSecondary)
            }
          }
        }
      }
    },
    confirmButton = {
      Button(onClick = { onApply(selected) }, colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple)) {
        Text("Uygula & Senkronla", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("İptal") }
    }
  )
}

@Composable
private fun Video4kUpscaleDialog(
  upscaleState: VideoUpscaleState,
  onStartUpscale: () -> Unit,
  onDismiss: () -> Unit,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("⚡", fontSize = 20.sp)
        Text("4K AI Video Upscaler", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Düşük kaliteli ve 1080p videoları, Real-ESRGAN v3 ve Bicubic yapay zeka tensör filtreleri ile kristal netliğinde 4K Ultra HD (3840x2160 @ 60 FPS) seviyesine yükseltin.",
          fontSize = 12.sp,
          color = textSecondary
        )

        Surface(
          shape = RoundedCornerShape(10.dp),
          color = CanvaPurple.copy(alpha = 0.12f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
              Text("Kaynak:", fontSize = 11.sp, color = textSecondary)
              Text(upscaleState.sourceResolution, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
              Text("Hedef:", fontSize = 11.sp, color = textSecondary)
              Text(upscaleState.targetResolution, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CanvaCyan)
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
              Text("AI Modeli:", fontSize = 11.sp, color = textSecondary)
              Text(upscaleState.modelEngine, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
          }
        }

        if (upscaleState.isUpscaling) {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            LinearProgressIndicator(
              progress = { upscaleState.progress },
              modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
              color = CanvaCyan,
            )
            Text(
              text = "Yükseltiliyor... %${(upscaleState.progress * 100).toInt()}",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = CanvaCyan
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onStartUpscale,
        enabled = !upscaleState.isUpscaling,
        colors = ButtonDefaults.buttonColors(containerColor = CanvaCyan)
      ) {
        Text(if (upscaleState.isUpscaling) "Yükseltiliyor..." else "4K Upscale Başlat", color = Color.Black, fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Kapat") }
    }
  )
}

@Composable
private fun SocialMediaShareDialog(
  platforms: List<SocialPlatformPost>,
  onConfirmPost: () -> Unit,
  onDismiss: () -> Unit,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("🚀", fontSize = 20.sp)
        Text("Otomatik Sosyal Medya Paylaşımı", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Tek tıkla hazırladığınız kurguyu tüm sosyal medya hesaplarınıza otomatik boyutlandırıp zamanlayarak yayınlayın.",
          fontSize = 12.sp,
          color = textSecondary
        )

        platforms.forEach { platform ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color.Black.copy(alpha = 0.2f),
            border = BorderStroke(1.dp, CanvaPurple.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Text(platform.iconEmoji, fontSize = 20.sp)
              Column(modifier = Modifier.weight(1f)) {
                Text(platform.platform, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Zamanlama: ${platform.scheduledTime}", fontSize = 10.sp, color = textSecondary)
                Text(platform.autoHashtags.joinToString(" "), fontSize = 9.sp, color = CanvaCyan)
              }
              Checkbox(checked = platform.isConnected, onCheckedChange = {})
            }
          }
        }
      }
    },
    confirmButton = {
      Button(onClick = onConfirmPost, colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple)) {
        Text("Tümüne Otomatik Paylaş", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("İptal") }
    }
  )
}

@Composable
private fun AutoSfxDialog(
  sfxPresets: List<SfxPreset>,
  onSelectSfx: (SfxPreset) -> Unit,
  onDismiss: () -> Unit,
  textPrimary: Color,
  textSecondary: Color,
  cardBg: Color
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("⚡", fontSize = 20.sp)
        Text("Otomatik Ses Efekti (SFX) Yerleştirici", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = "Geçişlere ve hareketli sahnelere uygun ses efektini seçin:",
          fontSize = 12.sp,
          color = textSecondary
        )
        sfxPresets.forEach { preset ->
          Surface(
            onClick = { onSelectSfx(preset) },
            shape = RoundedCornerShape(8.dp),
            color = CanvaPurple.copy(alpha = 0.12f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Text(preset.emoji, fontSize = 16.sp)
              Text(preset.name, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("Tamam") }
    }
  )
}

@Composable
private fun QuickCreateMenuSheet(
  onClose: () -> Unit,
  onVertical: () -> Unit,
  onHorizontal: () -> Unit,
  onBatch30Days: () -> Unit,
  onVoiceClone: () -> Unit,
  onGraphic: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 12.dp)
      .padding(bottom = 32.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    Text(text = "⚡ Hızlı Başlat Menüsü", fontSize = 18.sp, fontWeight = FontWeight.Bold)

    Surface(onClick = onVertical, shape = RoundedCornerShape(12.dp), color = CanvaPurple.copy(alpha = 0.12f)) {
      Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🎥", fontSize = 22.sp)
        Column {
          Text("Dikey Video (9:16)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text("TikTok, Instagram Reels ve Shorts", fontSize = 11.sp, color = Color.Gray)
        }
      }
    }

    Surface(onClick = onHorizontal, shape = RoundedCornerShape(12.dp), color = CanvaBlue.copy(alpha = 0.12f)) {
      Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🎬", fontSize = 22.sp)
        Column {
          Text("Yatay Video (16:9)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text("YouTube 4K sinematik video", fontSize = 11.sp, color = Color.Gray)
        }
      }
    }

    Surface(onClick = onBatch30Days, shape = RoundedCornerShape(12.dp), color = CanvaPink.copy(alpha = 0.12f)) {
      Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🪄", fontSize = 22.sp)
        Column {
          Text("30 Günlük Toplu Shorts", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text("CSV / TXT ile otomatik içerik fabrikası", fontSize = 11.sp, color = Color.Gray)
        }
      }
    }

    Surface(onClick = onVoiceClone, shape = RoundedCornerShape(12.dp), color = CanvaCyan.copy(alpha = 0.12f)) {
      Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🎙️", fontSize = 22.sp)
        Column {
          Text("AI Ses Klonlama", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text("10 saniyede kendi sesinizle TTS", fontSize = 11.sp, color = Color.Gray)
        }
      }
    }

    Surface(onClick = onGraphic, shape = RoundedCornerShape(12.dp), color = CanvaAmber.copy(alpha = 0.12f)) {
      Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🖼️", fontSize = 22.sp)
        Column {
          Text("Görsel Editör (Canva Tuvali)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text("Katmanlı afiş, thumbnail ve post tasarımı", fontSize = 11.sp, color = Color.Gray)
        }
      }
    }
  }
}
