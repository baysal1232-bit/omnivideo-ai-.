package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun RenderPipelineScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val activeJobs by viewModel.activeRenderJobs.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBg)
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp)
  ) {
    // 1. Header
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          GlowingBadge(
            text = "TEKNOLOJİ VE RENDER ALTYAPISI",
            color = EmeraldTech
          )
          TechMetricPill(
            label = "DONANIM",
            value = "CUDA & NVENC 4K",
            color = RadiantGold
          )
        }

        Text(
          text = "Hibrit İstemci & Sunucu Render Altyapısı",
          color = TextPrimary,
          fontSize = 22.sp,
          fontWeight = FontWeight.Black
        )
        Text(
          text = "İstemci tarafında WebAssembly (FFmpeg.wasm), Canvas Motorları (PixiJS/Fabric.js) ve WebGPU; sunucu tarafında 4K video ve yüksek çözünürlüklü görsel çıktısı için Node.js ve CUDA / NVENC.",
          color = TextSecondary,
          fontSize = 13.sp,
          lineHeight = 18.sp
        )
      }
    }

    // 2. İstemci Tarafı (Client-Side) Panel
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = NeonCyan.copy(alpha = 0.5f),
        backgroundColor = DarkSurface,
        cornerRadius = 16.dp
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Memory, contentDescription = null, tint = NeonCyan)
            Column {
              Text("İstemci Tarafı (Client-Side)", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
              Text("WebAssembly (FFmpeg.wasm), Canvas (PixiJS) & WebGPU", color = NeonCyan, fontSize = 11.sp)
            }
          }
          GlowingBadge(text = "60 FPS Aktif", color = NeonCyan)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          TechMetricPill(label = "TUVAL MOTORU", value = "PixiJS / WebGPU", color = NeonCyan, modifier = Modifier.weight(1f))
          TechMetricPill(label = "GECİKME", value = "10.4 ms", color = EmeraldTech, modifier = Modifier.weight(1f))
          TechMetricPill(label = "WASM", value = "FFmpeg 6.0", color = TextPrimary, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Tarayıcı içi ve mobil cihazlarda grafik katmanlarını, metin animasyonlarını ve video önizlemesini yerel GPU hızlandırmasıyla sıfır gecikmeyle işler.",
          color = TextSecondary,
          fontSize = 11.sp,
          lineHeight = 15.sp
        )
      }
    }

    // 3. Sunucu Tarafı Render (Server-Side) Panel
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = CyberPurple.copy(alpha = 0.5f),
        backgroundColor = DarkSurface,
        cornerRadius = 16.dp
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Dns, contentDescription = null, tint = CyberPurple)
            Column {
              Text("Sunucu Tarafı Render (Server-Side)", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
              Text("Node.js Orkestratörü & CUDA / NVENC 4K Hızlandırma", color = CyberPurple, fontSize = 11.sp)
            }
          }
          GlowingBadge(text = "4K Master", color = CyberPurple)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          TechMetricPill(label = "KODLAYICI", value = "Dual NVENC", color = CyberPurple, modifier = Modifier.weight(1f))
          TechMetricPill(label = "HIZ", value = "4.8x Gerçek Zaman", color = RadiantGold, modifier = Modifier.weight(1f))
          TechMetricPill(label = "GPU KÜMESİ", value = "NVIDIA A100", color = EmeraldTech, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Yüksek kaliteli 4K video ve yüksek çözünürlüklü görsel çıktısı için Node.js mikroservisleri işleri paralel parçalara böler ve CUDA / NVENC donanım hızlandırmasıyla saniyeler içinde birleştirir.",
          color = TextSecondary,
          fontSize = 11.sp,
          lineHeight = 15.sp
        )
      }
    }

    // 4. Bulut Depolama ve CDN Dağıtımı
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = RadiantGold.copy(alpha = 0.5f),
        backgroundColor = DarkSurface,
        cornerRadius = 16.dp
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.CloudSync, contentDescription = null, tint = RadiantGold)
            Column {
              Text("Bulut Depolama ve CDN Dağıtımı", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
              Text("AWS S3 / Cloudflare R2 Depolama & Anycast CDN", color = RadiantGold, fontSize = 11.sp)
            }
          }
          GlowingBadge(text = "Sıfır Çıkış Ücreti", color = RadiantGold)
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = "Tamamlanan 9:16 ve 16:9 içerikler ile yüksek çözünürlüklü grafikler Cloudflare R2 / AWS S3 üzerinde anında yedeklenir, Anycast CDN üzerinden TikTok, Reels ve YouTube'a ışık hızında servis edilir.",
          color = TextSecondary,
          fontSize = 11.sp,
          lineHeight = 15.sp
        )
      }
    }

    // 5. Active Jobs Queue
    item {
      Text(
        text = "Aktif Dışa Aktarımlar (Canva Katmanları & 10 Video Sahnesi)",
        color = TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold
      )
    }

    items(activeJobs) { job ->
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = Color(job.status.colorHex).copy(alpha = 0.5f),
        backgroundColor = DarkCardElevated,
        cornerRadius = 14.dp
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(job.projectName, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(
              text = job.outputAspects.joinToString(" + ") { it.title.split(" ").first() } + " (4K UHD)",
              color = RadiantGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }

          GlowingBadge(text = job.status.label, color = Color(job.status.colorHex))
        }

        Spacer(modifier = Modifier.height(10.dp))

        LinearProgressIndicator(
          progress = { job.progress },
          modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
          color = Color(job.status.colorHex),
          trackColor = DarkCardBorder
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Düğüm: ${job.gpuNode}",
            color = TextMuted,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            text = "%${(job.progress * 100).toInt()}",
            color = TextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }

    // 6. Action: Trigger Render
    item {
      NeonGradientButton(
        text = "Yeni 4K Canva & CapCut Dışa Aktarımı Başlat",
        onClick = { viewModel.openRenderModal(true) },
        modifier = Modifier.fillMaxWidth(),
        colors = listOf(EmeraldTech, NeonCyan, RadiantGold),
        leadingIcon = {
          Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = DarkBg)
        }
      )
    }
  }
}
