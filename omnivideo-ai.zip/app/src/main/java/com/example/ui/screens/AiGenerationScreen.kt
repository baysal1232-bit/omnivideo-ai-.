package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun AiGenerationScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  var selectedTab by remember { mutableStateOf(0) } // 0: Video & Görsel AI, 1: 10 Sahne Batch, 2: Whisper Altyazı, 3: ElevenLabs Ses

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBg)
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp)
  ) {
    // 1. Header
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          GlowingBadge(
            text = "DAHİLİ YAPAY ZEKA VE ÜRETİM MOTORU",
            color = RadiantGold
          )
          TechMetricPill(
            label = "HAK / KOTA",
            value = "${uiState.remainingVideoQuota}/10 Video",
            color = RadiantGold
          )
        }

        Text(
          text = "Yapay Zeka Üretim Laboratuvarı",
          color = TextPrimary,
          fontSize = 22.sp,
          fontWeight = FontWeight.Black
        )
        Text(
          text = "Komut kutusundan dikey/yatay videolar ve 4K görseller üretin (Flux, Veo, Sora, Kling), 10 sahneyi tek tıkla dizin, Whisper ve ElevenLabs ile seslendirin.",
          color = TextSecondary,
          fontSize = 13.sp,
          lineHeight = 18.sp
        )
      }
    }

    // 2. Sub-module Tabs
    item {
      val modules = listOf(
        "Metinden Video & Görsel (Flux/Veo)",
        "Toplu 10 Sahne (CapCut)",
        "Whisper Altyazı",
        "ElevenLabs Ses"
      )

      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(modules.indices.toList()) { index ->
          val isSelected = selectedTab == index
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(if (isSelected) RadiantGold.copy(alpha = 0.2f) else DarkCard)
              .border(
                1.dp,
                if (isSelected) RadiantGold else DarkCardBorder,
                RoundedCornerShape(10.dp)
              )
              .clickable { selectedTab = index }
              .padding(horizontal = 12.dp, vertical = 8.dp)
          ) {
            Text(
              text = modules[index],
              color = if (isSelected) RadiantGold else TextSecondary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }

    // Tab 0: Metinden Video ve Görsel Üretimi (Veo, Kling, Sora, Flux.1)
    if (selectedTab == 0) {
      item {
        CyberCard(
          modifier = Modifier.fillMaxWidth(),
          borderColor = RadiantGold.copy(alpha = 0.5f),
          backgroundColor = DarkSurface,
          cornerRadius = 16.dp
        ) {
          Text(
            text = "Yapay Zeka Modeli Seçin (Görsel & Video)",
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Model Selector Chips
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(viewModel.aiEngines) { engine ->
              val isSel = uiState.selectedAiModel.id == engine.id
              Box(
                modifier = Modifier
                  .width(150.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSel) RadiantGold.copy(alpha = 0.2f) else DarkCardElevated)
                  .border(1.dp, if (isSel) RadiantGold else DarkCardBorder, RoundedCornerShape(10.dp))
                  .clickable { viewModel.selectAiModel(engine) }
                  .padding(10.dp)
              ) {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(engine.name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  }
                  Text(engine.resolution, color = NeonCyan, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                  Text(engine.strengths, color = TextMuted, fontSize = 9.sp, maxLines = 2, lineHeight = 12.sp)
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Prompt Input
          Text(
            text = "Komut Kutusu (Prompt):",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(6.dp))

          OutlinedTextField(
            value = uiState.aiPromptInput,
            onValueChange = { viewModel.setAiPrompt(it) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = DarkBg,
              unfocusedContainerColor = DarkBg,
              focusedBorderColor = RadiantGold,
              unfocusedBorderColor = DarkCardBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            minLines = 3,
            maxLines = 4
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Two Actions: Video Üret veya Flux.1 ile Görsel Katmanı Üret
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = { viewModel.triggerGenerateFluxImage() },
              colors = ButtonDefaults.buttonColors(containerColor = CyberPurple, contentColor = Color.White),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f).height(42.dp)
            ) {
              Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Flux.1 4K Görsel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = { viewModel.triggerGenerateVideo() },
              colors = ButtonDefaults.buttonColors(containerColor = RadiantGold, contentColor = DarkBg),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f).height(42.dp)
            ) {
              Icon(Icons.Default.MovieFilter, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("AI Video Üret", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // Tab 1: Toplu Sahne Oluşturucu (Batch 10 Sahne)
    if (selectedTab == 1) {
      item {
        CyberCard(
          modifier = Modifier.fillMaxWidth(),
          borderColor = RadiantGold.copy(alpha = 0.5f),
          backgroundColor = DarkSurface,
          cornerRadius = 16.dp
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Toplu 10 Sahne Oluşturucu (Batch CapCut)",
              color = TextPrimary,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )
            GlowingBadge(text = "10/10 Video Kotası", color = RadiantGold)
          }

          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Senaryoyu parçalara bölüp 10 farklı video sahnesini tek tıkla üreterek zaman çizelgesine uç uca dizen sistemdir. 2 dakikalık uzun videoları tek işlemle hazırlar.",
            color = TextSecondary,
            fontSize = 12.sp,
            lineHeight = 16.sp
          )

          Spacer(modifier = Modifier.height(14.dp))

          // 10 Scenes list
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(DarkBg)
              .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            uiState.currentProject.scenes.forEachIndexed { idx, scene ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Text(
                    text = "${idx + 1}.",
                    color = RadiantGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = scene.title,
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                  )
                }

                Text(
                  text = "${scene.aiModel} (${scene.durationSeconds.toInt()}s)",
                  color = TextSecondary,
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          NeonGradientButton(
            text = "10 Sahneyi Tek Tıkla Üret & Birleştir (2:00 dk)",
            onClick = { viewModel.triggerBatchGeneration10Scenes("Siber Şehir & Yapay Zeka Dünyası") },
            modifier = Modifier.fillMaxWidth(),
            colors = listOf(RadiantGold, AmberGlow, CyberPurple),
            leadingIcon = {
              Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = DarkBg)
            }
          )
        }
      }
    }

    // Tab 2: Whisper API Otomatik Altyazı
    if (selectedTab == 2) {
      item {
        CyberCard(
          modifier = Modifier.fillMaxWidth(),
          borderColor = NeonCyan.copy(alpha = 0.5f),
          backgroundColor = DarkSurface,
          cornerRadius = 16.dp
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Whisper Kelime Senkronlu Altyazı", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            GlowingBadge(text = "%99.4 Doğruluk", color = NeonCyan)
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "OpenAI Whisper ile kelime senkronlu altyazı motoru, konuşmaları anında yakalar ve karaoke neon vurgusuyla 9:16 ve 16:9 tuvale yerleştirir.",
            color = TextSecondary,
            fontSize = 12.sp,
            lineHeight = 16.sp
          )

          Spacer(modifier = Modifier.height(12.dp))

          Column(
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(max = 220.dp)
              .verticalScroll(rememberScrollState())
              .clip(RoundedCornerShape(10.dp))
              .background(DarkBg)
              .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            uiState.currentProject.voiceover.words.forEach { word ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(word.word, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("${word.startMs}ms -> ${word.endMs}ms", color = NeonCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              }
            }
          }
        }
      }
    }

    // Tab 3: ElevenLabs Türkçe Seslendirme
    if (selectedTab == 3) {
      item {
        CyberCard(
          modifier = Modifier.fillMaxWidth(),
          borderColor = RadiantGold.copy(alpha = 0.5f),
          backgroundColor = DarkSurface,
          cornerRadius = 16.dp
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("ElevenLabs Türkçe Metinden Sese (TTS)", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            GlowingBadge(text = "44.1 kHz WAV", color = RadiantGold)
          }

          Spacer(modifier = Modifier.height(10.dp))

          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            viewModel.voices.forEach { voice ->
              val isSel = uiState.selectedVoice.id == voice.id
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSel) RadiantGold.copy(alpha = 0.15f) else DarkCardElevated)
                  .border(1.dp, if (isSel) RadiantGold else DarkCardBorder, RoundedCornerShape(10.dp))
                  .clickable { viewModel.selectVoice(voice) }
                  .padding(12.dp)
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                  ) {
                    Icon(
                      imageVector = Icons.Default.RecordVoiceOver,
                      contentDescription = null,
                      tint = if (isSel) RadiantGold else TextSecondary,
                      modifier = Modifier.size(22.dp)
                    )
                    Column {
                      Text(voice.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                      Text(voice.tone, color = TextMuted, fontSize = 11.sp)
                    }
                  }

                  IconButton(
                    onClick = { viewModel.showToast("${voice.name} sesi test ediliyor...") },
                    modifier = Modifier.size(32.dp)
                  ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = "Dinle", tint = RadiantGold)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
