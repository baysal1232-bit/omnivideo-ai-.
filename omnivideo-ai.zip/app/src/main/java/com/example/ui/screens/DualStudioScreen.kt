package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun DualStudioScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  var showBatchDialog by remember { mutableStateOf(false) }
  var showAddTextDialog by remember { mutableStateOf(false) }
  var textInput by remember { mutableStateOf("YAPAY ZEKA ÇAĞI") }

  // Top Bar Dropdowns
  var showFileMenu by remember { mutableStateOf(false) }
  var showEditMenu by remember { mutableStateOf(false) }
  var showFormatMenu by remember { mutableStateOf(false) }
  var show3dHeroBanner by remember { mutableStateOf(true) }

  // Right Panel AI prompt state
  var customAiPrompt by remember {
    mutableStateOf("Neon siber şehirde uçan araçlar, 8k sinematik ışıklandırma, yağmur yansımaları")
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBg)
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 96.dp)
  ) {

    // ==========================================
    // 1. ÜST KONTROL BARI
    // ==========================================
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = NeonCyan.copy(alpha = 0.5f),
        backgroundColor = DarkSurface,
        cornerRadius = 14.dp
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Sol Üst: 'Dosya' ve 'Düzenle' Menüleri
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Box {
                Button(
                  onClick = { showFileMenu = true },
                  colors = ButtonDefaults.buttonColors(
                    containerColor = DarkCardElevated,
                    contentColor = TextPrimary
                  ),
                  contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.height(30.dp)
                ) {
                  Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(13.dp), tint = NeonCyan)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Dosya", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                DropdownMenu(
                  expanded = showFileMenu,
                  onDismissRequest = { showFileMenu = false },
                  modifier = Modifier.background(DarkSurface)
                ) {
                  DropdownMenuItem(
                    text = { Text("✨ Yeni Proje Oluştur", color = TextPrimary, fontSize = 12.sp) },
                    onClick = {
                      showFileMenu = false
                      viewModel.showToast("Yeni proje başlatıldı")
                    }
                  )
                  DropdownMenuItem(
                    text = { Text("💾 Projeyi Kaydet (Bulut)", color = TextPrimary, fontSize = 12.sp) },
                    onClick = {
                      showFileMenu = false
                      viewModel.showToast("Proje buluta kaydedildi")
                    }
                  )
                  DropdownMenuItem(
                    text = { Text("🧩 Şablon Kütüphanesinden Aç", color = TextPrimary, fontSize = 12.sp) },
                    onClick = {
                      showFileMenu = false
                      viewModel.selectCanvaCategory(CanvaCategory.TEMPLATES)
                    }
                  )
                }
              }

              Box {
                Button(
                  onClick = { showEditMenu = true },
                  colors = ButtonDefaults.buttonColors(
                    containerColor = DarkCardElevated,
                    contentColor = TextPrimary
                  ),
                  contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.height(30.dp)
                ) {
                  Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp), tint = CyberPurple)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Düzenle", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                DropdownMenu(
                  expanded = showEditMenu,
                  onDismissRequest = { showEditMenu = false },
                  modifier = Modifier.background(DarkSurface)
                ) {
                  DropdownMenuItem(
                    text = { Text("↩️ Geri Al (Undo)", color = TextPrimary, fontSize = 12.sp) },
                    onClick = {
                      showEditMenu = false
                      viewModel.showToast("Son işlem geri alındı")
                    }
                  )
                  DropdownMenuItem(
                    text = { Text("↪️ Yinele (Redo)", color = TextPrimary, fontSize = 12.sp) },
                    onClick = {
                      showEditMenu = false
                      viewModel.showToast("İşlem yinelendi")
                    }
                  )
                  DropdownMenuItem(
                    text = { Text("🧹 Tüm Katmanları Temizle", color = CoralRed, fontSize = 12.sp) },
                    onClick = {
                      showEditMenu = false
                      viewModel.showToast("Katmanlar sıfırlandı")
                    }
                  )
                }
              }
            }

            // Sağ Üst: '⚡ 120 AI Kredisi', '👑 Premium' ve '📤 4K Dışa Aktar' Butonu
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              // ⚡ 120 AI Kredisi
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(RadiantGold.copy(alpha = 0.15f))
                  .border(0.8.dp, RadiantGold, RoundedCornerShape(6.dp))
                  .clickable { viewModel.setTab(MainNavigationTab.PRICING_PLANS) }
                  .padding(horizontal = 7.dp, vertical = 4.dp)
              ) {
                Text(
                  text = "⚡ ${uiState.aiCredits} Kredi",
                  color = RadiantGold,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Black
                )
              }

              // 👑 Premium
              Box(
                modifier = Modifier
                  .size(28.dp)
                  .clip(CircleShape)
                  .background(if (uiState.isProUser) RadiantGold.copy(alpha = 0.2f) else DarkCardElevated)
                  .border(1.dp, if (uiState.isProUser) RadiantGold else TextMuted, CircleShape)
                  .clickable { viewModel.setTab(MainNavigationTab.PRICING_PLANS) },
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.WorkspacePremium,
                  contentDescription = "Premium",
                  tint = if (uiState.isProUser) RadiantGold else TextMuted,
                  modifier = Modifier.size(16.dp)
                )
              }

              // 📤 4K Dışa Aktar Butonu
              Button(
                onClick = { viewModel.openRenderModal(true) },
                colors = ButtonDefaults.buttonColors(
                  containerColor = NeonCyan,
                  contentColor = DarkBg
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp).testTag("render_export_button")
              ) {
                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("4K Dışa Aktar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }

          // Orta Bar: Tek Tıkla Değişen 'Format: 9:16 Dikey (Shorts/Reels) / 16:9 Yatay (YouTube) / 1:1' Açılır Menüsü
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(modifier = Modifier.weight(1f)) {
              Button(
                onClick = { showFormatMenu = true },
                colors = ButtonDefaults.buttonColors(
                  containerColor = DarkBg,
                  contentColor = NeonCyan
                ),
                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp),
                modifier = Modifier.fillMaxWidth().height(34.dp)
              ) {
                Icon(Icons.Default.AspectRatio, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Format: ${uiState.currentAspect.title} (${uiState.currentAspect.label})",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
              }

              DropdownMenu(
                expanded = showFormatMenu,
                onDismissRequest = { showFormatMenu = false },
                modifier = Modifier.background(DarkSurface)
              ) {
                AspectRatioType.values().forEach { aspect ->
                  DropdownMenuItem(
                    text = {
                      Column {
                        Text(aspect.title, color = if (uiState.currentAspect == aspect) NeonCyan else TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(aspect.label, color = TextSecondary, fontSize = 10.sp)
                      }
                    },
                    leadingIcon = {
                      Icon(
                        imageVector = when (aspect) {
                          AspectRatioType.PORTRAIT_9_16 -> Icons.Default.PhoneAndroid
                          AspectRatioType.LANDSCAPE_16_9 -> Icons.Default.Tv
                          AspectRatioType.SQUARE_1_1 -> Icons.Default.CropSquare
                        },
                        contentDescription = null,
                        tint = if (uiState.currentAspect == aspect) NeonCyan else TextMuted
                      )
                    },
                    onClick = {
                      viewModel.setAspectRatio(aspect)
                      showFormatMenu = false
                    }
                  )
                }
              }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Auto-Reframe Toggle
            Row(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (uiState.autoReframeActive) EmeraldTech.copy(alpha = 0.2f) else DarkBg)
                .border(1.dp, if (uiState.autoReframeActive) EmeraldTech else DarkCardBorder, RoundedCornerShape(8.dp))
                .clickable { viewModel.toggleAutoReframe() }
                .padding(horizontal = 8.dp, vertical = 7.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(Icons.Default.CenterFocusStrong, contentDescription = null, tint = if (uiState.autoReframeActive) EmeraldTech else TextMuted, modifier = Modifier.size(14.dp))
              Text("Auto-Reframe", color = if (uiState.autoReframeActive) EmeraldTech else TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // ==========================================
    // 2. 3B İZOMETRİK UI/UX MİMARİ TANITIM AFİŞİ
    // ==========================================
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = CyberPurple.copy(alpha = 0.4f),
        backgroundColor = DarkSurface,
        cornerRadius = 14.dp
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Hub, contentDescription = null, tint = RadiantGold, modifier = Modifier.size(16.dp))
            Text("3B İzometrik UI/UX Mimari Tasarımı", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          IconButton(
            onClick = { show3dHeroBanner = !show3dHeroBanner },
            modifier = Modifier.size(24.dp)
          ) {
            Icon(
              imageVector = if (show3dHeroBanner) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
              contentDescription = null,
              tint = TextSecondary,
              modifier = Modifier.size(18.dp)
            )
          }
        }

        AnimatedVisibility(visible = show3dHeroBanner) {
          Column(modifier = Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(DarkBg)
            ) {
              Image(
                painter = painterResource(id = R.drawable.img_canva_capcut_studio_ui_1790547221055),
                contentDescription = "Canva ve CapCut 3B İzometrik UI/UX Mimarisi",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )
              DataStreamCanvas(modifier = Modifier.fillMaxSize())
            }
            Text(
              text = "Canva sürükle-bırak sadeliği + CapCut kurgu gücü: Üst bar, sol kütüphane, merkez 9:16 tuval, sağ AI sihirbazı ve alt timeline.",
              color = TextSecondary,
              fontSize = 10.sp,
              lineHeight = 14.sp
            )
          }
        }
      }
    }

    // ==========================================
    // 3. SOL PANEL: CANVA STİLİ BİLEŞEN KÜTÜPHANESİ
    // ==========================================
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = CyberPurple.copy(alpha = 0.5f),
        backgroundColor = DarkSurface,
        cornerRadius = 14.dp
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Box(
                modifier = Modifier
                  .size(30.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(CyberPurple.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.DesignServices, contentDescription = null, tint = CyberPurple, modifier = Modifier.size(18.dp))
              }
              Column {
                Text("Sol Panel: Canva Bileşen Kütüphanesi", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(uiState.canvaActiveCategory.subtitle, color = TextSecondary, fontSize = 10.sp)
              }
            }
            GlowingBadge(text = "Sürükle & Bırak", color = CyberPurple)
          }

          // Simgelerle Kategorize Edilmiş Dikey/Yatay Araç Çubuğu
          // '🔍 Ara', '🧩 Şablonlar', '🖼️ Görseller', '🎥 Videolar', '🅰️ Metin & Tipografi', '🎨 Çıkartma & Elementler', '📤 Yüklenen Medyalar'
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            items(CanvaCategory.values()) { cat ->
              val isSel = uiState.canvaActiveCategory == cat
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isSel) CyberPurple.copy(alpha = 0.25f) else DarkCardElevated)
                  .border(1.dp, if (isSel) CyberPurple else DarkCardBorder, RoundedCornerShape(8.dp))
                  .clickable { viewModel.selectCanvaCategory(cat) }
                  .padding(horizontal = 9.dp, vertical = 6.dp)
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                  Text(cat.iconEmoji, fontSize = 12.sp)
                  Text(
                    text = cat.title,
                    color = if (isSel) CyberPurple else TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                  )
                }
              }
            }
          }

          // Seçili Kategori İçeriği (Tuvale Eklenebilir Öğeler)
          when (uiState.canvaActiveCategory) {
            CanvaCategory.SEARCH -> {
              OutlinedTextField(
                value = "",
                onValueChange = {},
                placeholder = { Text("Tüm şablon, görsel ve çıkartmalarda ara...", fontSize = 11.sp, color = TextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp)) },
                modifier = Modifier.fillMaxWidth().height(46.dp),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = DarkBg,
                  unfocusedContainerColor = DarkBg,
                  focusedBorderColor = NeonCyan,
                  unfocusedBorderColor = DarkCardBorder
                )
              )
            }
            CanvaCategory.TEMPLATES -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                listOf(
                  "🔥 Viral Shorts" to 0xFF00D2FF,
                  "🎬 Sinematik VLOG" to 0xFFFBBF24,
                  "💎 VIP Banner" to 0xFFA855F7
                ).forEach { (title, color) ->
                  Box(
                    modifier = Modifier
                      .weight(1f)
                      .clip(RoundedCornerShape(8.dp))
                      .background(DarkBg)
                      .border(1.dp, Color(color).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                      .clickable {
                        viewModel.addGraphicLayer("Şablon", LayerType.EFFECT, title, color)
                      }
                      .padding(8.dp),
                    contentAlignment = Alignment.Center
                  ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                      Text(title, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                      Text("+ Tuvale Ekle", color = Color(color), fontSize = 9.sp)
                    }
                  }
                }
              }
            }
            CanvaCategory.IMAGES -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                listOf(
                  "Siber Şehir 4K" to 0xFF00D2FF,
                  "Neon Araba" to 0xFFA855F7,
                  "Portre Dekupe" to 0xFF10B981
                ).forEach { (name, color) ->
                  Box(
                    modifier = Modifier
                      .weight(1f)
                      .clip(RoundedCornerShape(8.dp))
                      .background(DarkBg)
                      .border(1.dp, DarkCardBorder, RoundedCornerShape(8.dp))
                      .clickable {
                        viewModel.addGraphicLayer("Görsel", LayerType.IMAGE, name, color)
                      }
                      .padding(8.dp),
                    contentAlignment = Alignment.Center
                  ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                      Icon(Icons.Default.Image, contentDescription = null, tint = Color(color), modifier = Modifier.size(18.dp))
                      Text(name, color = TextPrimary, fontSize = 10.sp, maxLines = 1)
                      Text("Ekle", color = NeonCyan, fontSize = 9.sp)
                    }
                  }
                }
              }
            }
            CanvaCategory.VIDEOS -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                listOf("Veo 2 Klip #1", "Sora Klip #2", "Kling B-Roll").forEach { vid ->
                  Box(
                    modifier = Modifier
                      .weight(1f)
                      .clip(RoundedCornerShape(8.dp))
                      .background(DarkBg)
                      .border(1.dp, RadiantGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                      .clickable {
                        viewModel.showToast("$vid zaman çizelgesine eklendi")
                      }
                      .padding(8.dp),
                    contentAlignment = Alignment.Center
                  ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                      Icon(Icons.Default.Videocam, contentDescription = null, tint = RadiantGold, modifier = Modifier.size(18.dp))
                      Text(vid, color = TextPrimary, fontSize = 10.sp, maxLines = 1)
                      Text("Timeline", color = RadiantGold, fontSize = 9.sp)
                    }
                  }
                }
              }
            }
            CanvaCategory.TEXT -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Button(
                  onClick = { showAddTextDialog = true },
                  colors = ButtonDefaults.buttonColors(containerColor = DarkCardElevated, contentColor = RadiantGold),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.weight(1f).height(36.dp)
                ) {
                  Icon(Icons.Default.TextFields, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Metin Yaz", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                  onClick = {
                    viewModel.addGraphicLayer("Neon Başlık", LayerType.TEXT, "YENİ NESİL VİRAL", 0xFF00D2FF)
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = DarkCardElevated, contentColor = NeonCyan),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.weight(1f).height(36.dp)
                ) {
                  Text("⚡ Neon Başlık", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
            CanvaCategory.STICKERS -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                listOf(
                  "⚡ %100 AI" to 0xFF00D2FF,
                  "🎯 VİRAL" to 0xFFFBBF24,
                  "🚀 TREND" to 0xFFA855F7,
                  "🔥 SICAK" to 0xFFEF4444
                ).forEach { (sticker, col) ->
                  Box(
                    modifier = Modifier
                      .weight(1f)
                      .clip(RoundedCornerShape(6.dp))
                      .background(DarkBg)
                      .border(1.dp, Color(col).copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                      .clickable {
                        viewModel.addGraphicLayer("Çıkartma", LayerType.STICKER, sticker, col)
                      }
                      .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                  ) {
                    Text(sticker, color = Color(col), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
            CanvaCategory.UPLOADS -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text("Cihazınızdan video, logo veya görsel aktarın", color = TextSecondary, fontSize = 11.sp)
                Button(
                  onClick = {
                    viewModel.addGraphicLayer("Yüklenen Logo", LayerType.IMAGE, "Kullanıcı_Logo.png", 0xFF10B981)
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = EmeraldTech, contentColor = DarkBg),
                  shape = RoundedCornerShape(6.dp),
                  contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                  modifier = Modifier.height(30.dp)
                ) {
                  Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Yükle", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    }

    // ==========================================
    // 4. ORTA PANEL: CANLI TUVAL & ÖNİZLEME (9:16 ve Serbest Boyutlandırma / Döndürme)
    // ==========================================
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = NeonCyan.copy(alpha = 0.6f),
        backgroundColor = DarkSurface,
        cornerRadius = 14.dp
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(if (uiState.isPlaying) EmeraldTech else CoralRed)
              )
              Text("Orta Panel: Canlı Tuval & Önizleme", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            GlowingBadge(
              text = "${uiState.currentAspect.title} • ${uiState.currentProject.graphicLayers.size} Katman",
              color = RadiantGold
            )
          }

          // Merkezde dikey (9:16) veya seçilen formatta çalışan canlı simülasyon tuvali
          VideoPlayerSimulation(
            project = uiState.currentProject,
            aspectRatio = uiState.currentAspect,
            currentPlaybackMs = uiState.currentPlaybackMs,
            isPlaying = uiState.isPlaying,
            autoReframeActive = uiState.autoReframeActive,
            smartBgRemoved = uiState.smartBgRemoved,
            isDualSimultaneous = uiState.isDualSimultaneousView,
            onTogglePlay = { viewModel.togglePlayback() }
          )

          // Katmanların Serbestçe Boyutlandırılıp Döndürülebildiği Esnek Kontrol Çubuğu
          if (uiState.currentProject.graphicLayers.isNotEmpty()) {
            val activeLayer = uiState.currentProject.graphicLayers.firstOrNull {
              it.id == uiState.selectedLayerId
            } ?: uiState.currentProject.graphicLayers.first()

            CyberCard(
              modifier = Modifier.fillMaxWidth(),
              borderColor = DarkCardBorder,
              backgroundColor = DarkBg,
              cornerRadius = 10.dp
            ) {
              Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = "🎯 Seçili Katman: \"${activeLayer.content}\"",
                    color = RadiantGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                  )
                  Text(
                    text = "Ölçek: ${(activeLayer.scale * 100).toInt()}% • Açı: ${activeLayer.rotation.toInt()}°",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }

                // Boyutlandırma (Resize/Scale) ve Döndürme (Rotate) Butonları
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  // Boyut Azalt
                  IconButton(
                    onClick = {
                      val newScale = (activeLayer.scale - 0.15f).coerceAtLeast(0.5f)
                      viewModel.updateLayerTransform(activeLayer.id, newScale, activeLayer.rotation)
                    },
                    modifier = Modifier.size(30.dp).clip(RoundedCornerShape(6.dp)).background(DarkCardElevated)
                  ) {
                    Icon(Icons.Default.Remove, contentDescription = "Küçült", tint = NeonCyan, modifier = Modifier.size(16.dp))
                  }

                  Text("Boyutlandır", color = TextSecondary, fontSize = 10.sp)

                  // Boyut Büyüt
                  IconButton(
                    onClick = {
                      val newScale = (activeLayer.scale + 0.15f).coerceAtMost(2.5f)
                      viewModel.updateLayerTransform(activeLayer.id, newScale, activeLayer.rotation)
                    },
                    modifier = Modifier.size(30.dp).clip(RoundedCornerShape(6.dp)).background(DarkCardElevated)
                  ) {
                    Icon(Icons.Default.Add, contentDescription = "Büyüt", tint = NeonCyan, modifier = Modifier.size(16.dp))
                  }

                  Spacer(modifier = Modifier.width(10.dp))

                  // Sola Döndür
                  IconButton(
                    onClick = {
                      val newRot = (activeLayer.rotation - 15f) % 360f
                      viewModel.updateLayerTransform(activeLayer.id, activeLayer.scale, newRot)
                    },
                    modifier = Modifier.size(30.dp).clip(RoundedCornerShape(6.dp)).background(DarkCardElevated)
                  ) {
                    Icon(Icons.Default.RotateLeft, contentDescription = "Sola Döndür", tint = CyberPurple, modifier = Modifier.size(16.dp))
                  }

                  Text("Döndür", color = TextSecondary, fontSize = 10.sp)

                  // Sağa Döndür
                  IconButton(
                    onClick = {
                      val newRot = (activeLayer.rotation + 15f) % 360f
                      viewModel.updateLayerTransform(activeLayer.id, activeLayer.scale, newRot)
                    },
                    modifier = Modifier.size(30.dp).clip(RoundedCornerShape(6.dp)).background(DarkCardElevated)
                  ) {
                    Icon(Icons.Default.RotateRight, contentDescription = "Sağa Döndür", tint = CyberPurple, modifier = Modifier.size(16.dp))
                  }
                }
              }
            }
          }
        }
      }
    }

    // ==========================================
    // 5. SAĞ PANEL: YAPAY ZEKA VE OTOMASYON SİHİRBAZI
    // ==========================================
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = RadiantGold.copy(alpha = 0.6f),
        backgroundColor = DarkSurface,
        cornerRadius = 14.dp
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Box(
                modifier = Modifier
                  .size(30.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(RadiantGold.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RadiantGold, modifier = Modifier.size(18.dp))
              }
              Column {
                Text("Sağ Panel: Yapay Zeka & Otomasyon Sihirbazı", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("Veo 2, Sora, ElevenLabs TTS & Whisper", color = TextSecondary, fontSize = 10.sp)
              }
            }
            GlowingBadge(text = "${uiState.remainingVideoQuota}/10 Kota", color = RadiantGold)
          }

          // A. AI Video Üretici: 'Prompt Girin...' Metin Kutusu
          Text("🎬 AI Video Üretici:", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          OutlinedTextField(
            value = customAiPrompt,
            onValueChange = { customAiPrompt = it },
            placeholder = { Text("Prompt Girin... (Örn: Neon şehirde süzülen siber araçlar)", fontSize = 11.sp) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = DarkBg,
              unfocusedContainerColor = DarkBg,
              focusedBorderColor = RadiantGold,
              unfocusedBorderColor = DarkCardBorder,
              focusedTextColor = TextPrimary
            )
          )

          // Belirgin '🎬 10 Sahne Üret ve Otomatik Birleştir' Butonu
          if (uiState.isBatchGenerating) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              LinearProgressIndicator(
                progress = { uiState.batchProgress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = RadiantGold,
                trackColor = DarkCardBorder
              )
              Text(
                text = uiState.batchStatusMessage,
                color = NeonCyan,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          } else {
            NeonGradientButton(
              text = "🎬 10 Sahne Üret ve Otomatik Birleştir",
              onClick = { showBatchDialog = true },
              modifier = Modifier.fillMaxWidth(),
              colors = listOf(RadiantGold, AmberGlow, CyberPurple),
              leadingIcon = {
                Icon(Icons.Default.MovieFilter, contentDescription = null, tint = DarkBg)
              }
            )
          }

          HorizontalDivider(color = DarkCardBorder.copy(alpha = 0.5f), thickness = 0.8.dp)

          // B. AI Seslendirme (ElevenLabs) & Altyazı (Whisper)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // ElevenLabs Voice
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(DarkBg)
                .border(1.dp, RadiantGold.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .clickable {
                  viewModel.showToast("ElevenLabs Türkçe Spiker: ${uiState.selectedVoice.name}")
                }
                .padding(8.dp)
            ) {
              Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = RadiantGold, modifier = Modifier.size(14.dp))
                  Text("ElevenLabs TTS", color = RadiantGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                  text = uiState.selectedVoice.name.split("-").first().trim(),
                  color = TextPrimary,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
                Text("Doğal Türkçe Spiker", color = TextSecondary, fontSize = 9.sp)
              }
            }

            // Whisper Subtitles
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(DarkBg)
                .border(1.dp, CyberPurple.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .clickable {
                  viewModel.showToast("Whisper API zaman damgalı altyazı katmanı aktif")
                }
                .padding(8.dp)
            ) {
              Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  Icon(Icons.Default.ClosedCaption, contentDescription = null, tint = CyberPurple, modifier = Modifier.size(14.dp))
                  Text("Whisper Altyazı", color = CyberPurple, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text("Kelime Senkronlu", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Karaoke Animasyonu", color = TextSecondary, fontSize = 9.sp)
              }
            }
          }

          // C. AI Araçları: Tek Tıkla Arka Plan Silme (rembg) ve Nesne Dekupe Etme Butonları
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = { viewModel.toggleSmartBgRemoved() },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (uiState.smartBgRemoved) EmeraldTech.copy(alpha = 0.2f) else DarkCardElevated,
                contentColor = if (uiState.smartBgRemoved) EmeraldTech else TextPrimary
              ),
              border = BorderStroke(1.dp, if (uiState.smartBgRemoved) EmeraldTech else DarkCardBorder),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f).height(38.dp)
            ) {
              Icon(Icons.Default.LayersClear, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (uiState.smartBgRemoved) "rembg: Dekupe Açık" else "rembg Arka Plan Sil",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }

            Button(
              onClick = {
                viewModel.showToast("AI Nesne Segmentasyonu uygulandı")
              },
              colors = ButtonDefaults.buttonColors(containerColor = DarkCardElevated, contentColor = NeonCyan),
              border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.4f)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f).height(38.dp)
            ) {
              Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Nesne Dekupe", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // ==========================================
    // 6. ALT PANEL: MODÜLER ZAMAN ÇİZELGESİ (TIMELINE)
    // ==========================================
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.ViewTimeline, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
            Text("Alt Panel: Modüler Zaman Çizelgesi", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
          GlowingBadge(
            text = "Video • Ses • Altyazı İzi",
            color = NeonCyan
          )
        }

        TimelineEditor(
          project = uiState.currentProject,
          currentPlaybackMs = uiState.currentPlaybackMs,
          isPlaying = uiState.isPlaying,
          onSeek = { viewModel.seekPlayback(it) },
          onTogglePlay = { viewModel.togglePlayback() },
          onCut = { viewModel.showToast("Zaman çizelgesinde kare hassasiyetli kesme yapıldı") },
          onAddEffect = { viewModel.showToast("CapCut geçiş efekti uygulandı") }
        )
      }
    }
  }

  // Metin Ekle Dialogu
  if (showAddTextDialog) {
    AlertDialog(
      onDismissRequest = { showAddTextDialog = false },
      containerColor = DarkSurface,
      titleContentColor = TextPrimary,
      textContentColor = TextSecondary,
      title = { Text("Canva Metin Katmanı Ekle", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Tuval üzerinde görüntülenecek metin:", fontSize = 12.sp)
          OutlinedTextField(
            value = textInput,
            onValueChange = { textInput = it },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = DarkBg,
              unfocusedContainerColor = DarkBg,
              focusedBorderColor = RadiantGold,
              unfocusedBorderColor = DarkCardBorder,
              focusedTextColor = TextPrimary
            )
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (textInput.isNotBlank()) {
              viewModel.addGraphicLayer("Metin", LayerType.TEXT, textInput, 0xFFFBBF24)
              showAddTextDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = RadiantGold, contentColor = DarkBg)
        ) {
          Text("Ekle", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddTextDialog = false }) {
          Text("İptal", color = TextMuted)
        }
      }
    )
  }

  // 10 Sahne Toplu Üretim Dialogu
  if (showBatchDialog) {
    AlertDialog(
      onDismissRequest = { showBatchDialog = false },
      containerColor = DarkSurface,
      titleContentColor = TextPrimary,
      textContentColor = TextSecondary,
      title = {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RadiantGold)
          Text("10 Sahne Toplu AI Üretimi", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "Senaryo otomatik olarak 10 sahneye bölünecek, Veo 2 ve Sora modelleriyle 8-15 saniyelik klipler üretilecek ve CapCut zaman çizelgesine otomatik dizilecektir.",
            fontSize = 12.sp,
            color = TextSecondary,
            lineHeight = 16.sp
          )

          CyberCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = RadiantGold.copy(alpha = 0.5f),
            backgroundColor = DarkBg,
            cornerRadius = 8.dp
          ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text("⚙️ Üretim Parametreleri:", color = RadiantGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              Text("• Format: 9:16 Dikey (Shorts/Reels) ve 16:9 Yatay", color = TextSecondary, fontSize = 10.sp)
              Text("• Seslendirme: ElevenLabs Türkçe Spiker (Elif)", color = TextSecondary, fontSize = 10.sp)
              Text("• Altyazı: OpenAI Whisper Kelime Senkronlu Karaoke", color = TextSecondary, fontSize = 10.sp)
              Text("• Geçiş: ${uiState.selectedTransitionEffect}", color = TextSecondary, fontSize = 10.sp)
            }
          }
        }
      },
      confirmButton = {
        NeonGradientButton(
          text = "Üretimi Başlat (10 Sahne)",
          onClick = {
            showBatchDialog = false
            viewModel.triggerBatchGeneration10Scenes("Siber Gelecek & Yapay Zeka Çağı")
          },
          colors = listOf(RadiantGold, AmberGlow, CyberPurple)
        )
      },
      dismissButton = {
        TextButton(onClick = { showBatchDialog = false }) {
          Text("Vazgeç", color = TextMuted)
        }
      }
    )
  }
}
