package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun PricingPlansScreen(
  viewModel: StudioViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val clipboardManager = LocalClipboardManager.current

  val monetizationPrompt = remember {
    "Kullanıcıların ücretsiz temel araçları kullanabildiği, gelişmiş yapay zeka video/görsel üretimi (Veo, Sora, Flux), 4K export, otomatik altyazı (Whisper) ve seslendirme (ElevenLabs) gibi özellikleri 'PREMIUM' kilit arkasında sunduğu hepsi bir arada bir video ve görsel editörü mimarisini gösteren 3B izometrik infografik.\n" +
    "Görselde 'Ücretsiz Katman' (Temel kesme, 1080p export) ile 'Premium / Kredi Katmanı' (10 Video Toplu AI Üretimi, Filigran Kaldırma, 4K Render, Otomatik Altyazı) arasındaki kilitli paneller ve abonelik rozetleri parlayan fütüristik çizgilerle açıkça gösterilmelidir."
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBg)
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp)
  ) {
    // 1. Header
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          GlowingBadge(
            text = "FİYATLANDIRMA VE GELİR MODELİ",
            color = RadiantGold
          )
          TechMetricPill(
            label = "BAKİYE",
            value = "${uiState.aiCredits} Kredi",
            color = RadiantGold
          )
        }

        Text(
          text = "Ücretsiz & Premium Abonelik Mimarisi",
          color = TextPrimary,
          fontSize = 22.sp,
          fontWeight = FontWeight.Black
        )
        Text(
          text = "Temel kurgu araçları ücretsiz; yüksek maliyetli yapay zeka modelleri (Veo, Sora, ElevenLabs), 4K NVENC çıktısı ve filigransız kullanım abonelik ve kredi sistemiyle korunur.",
          color = TextSecondary,
          fontSize = 13.sp,
          lineHeight = 18.sp
        )
      }
    }

    // 2. Active Tier Status & Real-Time Simulator Switcher
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = if (uiState.isProUser) RadiantGold else NeonCyan,
        backgroundColor = DarkSurface,
        cornerRadius = 16.dp
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(if (uiState.isProUser) RadiantGold.copy(alpha = 0.2f) else DarkCardElevated)
                .border(1.5.dp, if (uiState.isProUser) RadiantGold else NeonCyan, CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = if (uiState.isProUser) Icons.Default.WorkspacePremium else Icons.Default.Person,
                contentDescription = null,
                tint = if (uiState.isProUser) RadiantGold else NeonCyan,
                modifier = Modifier.size(20.dp)
              )
            }
            Column {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                  text = "Mevcut Durumunuz:",
                  color = TextSecondary,
                  fontSize = 11.sp
                )
                GlowingBadge(
                  text = uiState.userTier.title,
                  color = Color(uiState.userTier.colorHex)
                )
              }
              Text(
                text = if (uiState.isProUser) "Tüm 4K, 10 Sahne Batch ve Whisper araçları sınırsız açık!" else "1080p sınırı, filigran ve günlük 2 deneme hakkı.",
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Toggle Switch button to test both states instantly
        Button(
          onClick = { viewModel.toggleUserTier() },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (uiState.isProUser) DarkCardElevated else RadiantGold,
            contentColor = if (uiState.isProUser) RadiantGold else DarkBg
          ),
          border = if (uiState.isProUser) BorderStroke(1.dp, RadiantGold) else null,
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth().height(42.dp)
        ) {
          Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (uiState.isProUser) "Ücretsiz Plana Dön (Simülasyon)" else "PRO VIP'ye Yükselt (Simülasyon)",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }

    // 3. Abonelik Modeli (Aylık / Yıllık Fiyatlandırma)
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = RadiantGold.copy(alpha = 0.8f),
        backgroundColor = DarkSurface,
        cornerRadius = 16.dp
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "PRO VIP Abonelik Modeli",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
          GlowingBadge(text = "%44 İndirim", color = RadiantGold)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Billing Cycle Selector Tabs
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          BillingCycle.values().forEach { cycle ->
            val isSel = uiState.activeBillingCycle == cycle
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(if (isSel) RadiantGold.copy(alpha = 0.2f) else DarkCardElevated)
                .border(1.dp, if (isSel) RadiantGold else DarkCardBorder, RoundedCornerShape(10.dp))
                .clickable { viewModel.setBillingCycle(cycle) }
                .padding(10.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                  text = cycle.label,
                  color = if (isSel) RadiantGold else TextSecondary,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = cycle.price,
                  color = TextPrimary,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Black
                )
                Text(
                  text = cycle.discountNote,
                  color = if (isSel) RadiantGold else TextMuted,
                  fontSize = 9.sp
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Included Features List
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          val perks = listOf(
            "Filigransız Temiz Video Çıktısı (Logo Yok)",
            "4K Ultra HD & 60 FPS NVENC Donanım Render",
            "10 Sahne Toplu AI Video Üretimi (Veo 2, Sora, Kling)",
            "Sınırsız Whisper Kelime Senkronlu Karaoke Altyazı",
            "Sınırsız ElevenLabs Doğal Türkçe Seslendirme (TTS)",
            "Tek Tıkla Arka Plan Silme (rembg Yeşil Ekransız Dekupe)",
            "Akıllı Kadrajlama (Auto-Reframe 9:16 ve 16:9)",
            "Tüm VIP Şablon ve Sinematik LUT Filtreleri"
          )

          perks.forEach { perk ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = RadiantGold, modifier = Modifier.size(16.dp))
              Text(perk, color = TextPrimary, fontSize = 11.sp)
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        NeonGradientButton(
          text = if (uiState.isProUser) "Aboneliğiniz Aktif (Pro VIP)" else "Hemen Abone Ol (${uiState.activeBillingCycle.price})",
          onClick = {
            viewModel.setUserTier(SubscriptionTier.PRO_VIP)
          },
          modifier = Modifier.fillMaxWidth(),
          colors = listOf(RadiantGold, AmberGlow, CyberPurple),
          leadingIcon = {
            Icon(Icons.Default.LockOpen, contentDescription = null, tint = DarkBg)
          }
        )
      }
    }

    // 4. Kredi / Paket Sistemi (Yapay Zeka Video Üretimi İçin)
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = CyberPurple.copy(alpha = 0.5f),
        backgroundColor = DarkSurface,
        cornerRadius = 16.dp
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "Yapay Zeka Kredi Paketleri",
              color = TextPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Sunucu maliyetlerini karşılayan esnek tüketim sistemi",
              color = TextSecondary,
              fontSize = 10.sp
            )
          }
          GlowingBadge(text = "100 Kredi = 10 AI Video", color = CyberPurple)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          viewModel.creditPackages.forEach { pkg ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(if (pkg.isPopular) CyberPurple.copy(alpha = 0.15f) else DarkCardElevated)
                .border(1.dp, if (pkg.isPopular) CyberPurple else DarkCardBorder, RoundedCornerShape(10.dp))
                .padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  Text(
                    text = "${pkg.credits} AI Kredisi",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                  )
                  pkg.bonusTag?.let { tag ->
                    GlowingBadge(text = tag, color = if (pkg.isPopular) CyberPurple else RadiantGold)
                  }
                }
                Text(
                  text = pkg.description,
                  color = TextSecondary,
                  fontSize = 10.sp
                )
              }

              Button(
                onClick = { viewModel.purchaseCredits(pkg) },
                colors = ButtonDefaults.buttonColors(
                  containerColor = if (pkg.isPopular) CyberPurple else DarkBg,
                  contentColor = if (pkg.isPopular) Color.White else NeonCyan
                ),
                border = if (!pkg.isPopular) BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)) else null,
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.height(34.dp)
              ) {
                Text(pkg.price, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }

    // 5. Kapsamlı Özellik Karşılaştırma Tablosu (Ücretsiz vs PRO VIP)
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = DarkCardBorder,
        backgroundColor = DarkSurface,
        cornerRadius = 16.dp
      ) {
        Text(
          text = "Özellik Karşılaştırma Tablosu",
          color = TextPrimary,
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Table Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(DarkBg)
            .padding(horizontal = 8.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Özellik", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f))
          Text("Ücretsiz", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f))
          Text("PRO VIP", color = RadiantGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Table Rows
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          viewModel.featureComparisons.forEach { row ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = row.featureName,
                color = TextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1.3f)
              )
              Text(
                text = row.freeValue,
                color = TextSecondary,
                fontSize = 10.sp,
                modifier = Modifier.weight(0.9f)
              )
              Text(
                text = row.proValue,
                color = RadiantGold,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
              )
            }
            HorizontalDivider(color = DarkCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
          }
        }
      }
    }

    // 6. Güncellenmiş 3B Sistem Promptu Paneli
    item {
      CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = NeonCyan.copy(alpha = 0.5f),
        backgroundColor = DarkSurface,
        cornerRadius = 16.dp
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Terminal, contentDescription = null, tint = NeonCyan)
            Text(
              text = "3B Fiyatlandırma Mimarisi Promptu",
              color = TextPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Button(
            onClick = {
              clipboardManager.setText(AnnotatedString(monetizationPrompt))
              viewModel.showToast("Fiyatlandırma & Gelir Modeli Promptu Kopyalandı!")
            },
            colors = ButtonDefaults.buttonColors(
              containerColor = NeonCyan.copy(alpha = 0.2f),
              contentColor = NeonCyan
            ),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            modifier = Modifier.height(30.dp)
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Kopyala", fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = monetizationPrompt,
          color = TextSecondary,
          fontSize = 11.sp,
          lineHeight = 15.sp,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DarkBg)
            .padding(10.dp)
        )
      }
    }
  }
}
