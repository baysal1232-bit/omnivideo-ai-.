package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.SubscriptionTier
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.MoreSubTab
import com.example.ui.viewmodel.StudioViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: StudioViewModel = viewModel()
      val uiState by viewModel.uiState.collectAsState()

      MyApplicationTheme(darkTheme = uiState.isDarkTheme) {
        OmniVideoApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun OmniVideoApp(viewModel: StudioViewModel = viewModel()) {
  val uiState by viewModel.uiState.collectAsState()
  val context = LocalContext.current
  val isDark = uiState.isDarkTheme

  val bgColor = if (isDark) DarkBg else LightBg
  val navContainerColor = if (isDark) DarkSurface else LightSurface
  val navBorderColor = if (isDark) DarkCardBorder else LightCardBorder
  val activeColor = CanvaPurple
  val inactiveColor = if (isDark) TextMuted else LightTextMuted

  // Show toasts
  LaunchedEffect(uiState.toastMessage) {
    uiState.toastMessage?.let { msg ->
      Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
      viewModel.clearToast()
    }
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .background(bgColor),
    containerColor = bgColor,
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    bottomBar = {
      NavigationBar(
        modifier = Modifier
          .fillMaxWidth()
          .windowInsetsPadding(WindowInsets.navigationBars)
          .border(0.8.dp, navBorderColor, RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
          .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
          .testTag("main_bottom_nav"),
        containerColor = navContainerColor,
        tonalElevation = 8.dp
      ) {
        MainNavigationTab.values().forEach { tab ->
          val isSelected = uiState.currentTab == tab
          NavigationBarItem(
            selected = isSelected,
            onClick = { viewModel.setTab(tab) },
            icon = {
              Icon(
                imageVector = when (tab) {
                  MainNavigationTab.HOME -> if (isSelected) Icons.Filled.Home else Icons.Outlined.Home
                  MainNavigationTab.DESIGNS -> if (isSelected) Icons.Filled.Folder else Icons.Outlined.Folder
                  MainNavigationTab.AI_STUDIO -> if (isSelected) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome
                  MainNavigationTab.TRENDS -> if (isSelected) Icons.Filled.TrendingUp else Icons.Outlined.TrendingUp
                  MainNavigationTab.SETTINGS -> if (isSelected) Icons.Filled.Settings else Icons.Outlined.Settings
                },
                contentDescription = tab.title,
                tint = if (isSelected) activeColor else inactiveColor
              )
            },
            label = {
              Text(
                text = tab.title,
                color = if (isSelected) activeColor else inactiveColor,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = activeColor,
              selectedTextColor = activeColor,
              unselectedIconColor = inactiveColor,
              unselectedTextColor = inactiveColor,
              indicatorColor = activeColor.copy(alpha = if (isDark) 0.2f else 0.12f)
            ),
            modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (uiState.currentTab) {
        MainNavigationTab.HOME -> CanvaHomeScreen(viewModel = viewModel)
        MainNavigationTab.DESIGNS -> DesignsScreen(viewModel = viewModel)
        MainNavigationTab.AI_STUDIO -> AiStudioHubScreen(viewModel = viewModel)
        MainNavigationTab.TRENDS -> TrendScreen(viewModel = viewModel)
        MainNavigationTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
      }
    }
  }

  // 👑 Planınızı Yükseltin (Premium) Diyalogu
  if (uiState.activePricingDialog) {
    AlertDialog(
      onDismissRequest = { viewModel.closePricingDialog() },
      containerColor = if (isDark) DarkSurface else LightSurface,
      shape = RoundedCornerShape(20.dp),
      title = {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text("👑", fontSize = 20.sp)
          Text(
            text = "Planınızı Yükseltin (Canva Pro)",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = if (isDark) TextPrimary else LightTextPrimary
          )
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          uiState.activePricingFeatureContext?.let { contextFeature ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = CanvaPurple.copy(alpha = 0.12f)
            ) {
              Text(
                text = "⚡ Kilitli Özellik: $contextFeature",
                fontSize = 12.sp,
                color = CanvaPurple,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }

          Text(
            text = "Canva Pro VIP ile sınırları kaldırın:",
            fontSize = 13.sp,
            color = if (isDark) TextSecondary else LightTextSecondary
          )

          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("✅ 4K Ultra HD (60 FPS) NVENC Render", fontSize = 12.sp)
            Text("✅ Videolarda 'OmniVideo Free' Filigranı Yok", fontSize = 12.sp)
            Text("✅ 10 Sahne Toplu AI Video (Veo 2 & Sora)", fontSize = 12.sp)
            Text("✅ ElevenLabs Türkçe Doğal Seslendirme & Whisper", fontSize = 12.sp)
            Text("✅ Tek Tıkla Arka Plan Silme & Auto-Reframe", fontSize = 12.sp)
          }

          Spacer(modifier = Modifier.height(4.dp))

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isDark) DarkCardElevated else LightCardElevated,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("Yıllık Plan (Avantajlı)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("₺83.25 / ay (₺999 / yıl)", fontSize = 11.sp, color = CanvaPurple)
              }
              Surface(shape = RoundedCornerShape(6.dp), color = CanvaAmber) {
                Text(
                  "%44 İNDİRİM",
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Black,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.setUserTier(SubscriptionTier.PRO_VIP)
            viewModel.closePricingDialog()
          },
          colors = ButtonDefaults.buttonColors(containerColor = CanvaPurple),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text("👑 Pro'ya Geç (₺149/Ay)", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(
          onClick = {
            viewModel.closePricingDialog()
            viewModel.setTab(MainNavigationTab.MORE)
            viewModel.setMoreSubTab(MoreSubTab.PRICING)
          }
        ) {
          Text("Tüm Planları Gör", color = CanvaPurple)
        }
      }
    )
  }
}
