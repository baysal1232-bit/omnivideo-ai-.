package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AspectRatioType
import com.example.data.repository.VideoRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("OmniVideo AI", appName)
  }

  @Test
  fun `architecture nodes and dual workspaces are loaded`() {
    val repository = VideoRepository()
    val nodes = repository.architectureNodes
    assertEquals(14, nodes.size)

    val multiFormat = nodes.firstOrNull { it.id == "workspace_multi_format" }
    val freeEditNode = nodes.firstOrNull { it.id == "free_basic_editing" }
    val batchNode = nodes.firstOrNull { it.id == "prem_batch_10_scenes" }
    val whisperNode = nodes.firstOrNull { it.id == "prem_whisper_subtitles" }

    assertNotNull(multiFormat)
    assertNotNull(freeEditNode)
    assertNotNull(batchNode)
    assertNotNull(whisperNode)
    assertEquals("Çoklu Format Canlı Önizleme", multiFormat?.title)
    assertEquals("Temel Görsel ve Video Kurgu", freeEditNode?.title)
    assertEquals("10 Sahne Toplu Üretim & Birleştirme", batchNode?.title)
  }

  @Test
  fun `10 scenes project duration and graphic layers are valid`() {
    val repository = VideoRepository()
    val project = repository.sampleProjects.first()
    assertEquals(10, project.scenes.size)
    assertEquals(120f, project.totalDurationSeconds)
    assertEquals(10, project.currentQuotaCount)
    assertEquals(4, project.graphicLayers.size)
  }

  @Test
  fun `aspect ratio definitions are accurate`() {
    assertEquals(9f / 16f, AspectRatioType.PORTRAIT_9_16.ratio)
    assertEquals(16f / 9f, AspectRatioType.LANDSCAPE_16_9.ratio)
    assertEquals(1f, AspectRatioType.SQUARE_1_1.ratio)
  }
}
