package com.example

import com.example.data.model.AspectRatioType
import com.example.data.repository.VideoRepository
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.StudioSubTab
import com.example.ui.viewmodel.StudioViewModel
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun canva_home_templates_and_projects_are_populated() {
    val repository = VideoRepository()
    assertTrue("Popular templates must not be empty", repository.popularTemplates.isNotEmpty())
    assertTrue("Recent projects must not be empty", repository.recentProjects.isNotEmpty())
    assertTrue("Trend audios must not be empty", repository.trendAudios.isNotEmpty())

    val portraitProject = repository.recentProjects.find { it.aspectType == AspectRatioType.PORTRAIT_9_16 }
    val landscapeProject = repository.recentProjects.find { it.aspectType == AspectRatioType.LANDSCAPE_16_9 }
    assertNotNull("Must have 9:16 vertical recent project", portraitProject)
    assertNotNull("Must have 16:9 horizontal recent project", landscapeProject)
  }

  @Test
  fun viewmodel_home_actions_and_theme_toggle_work() {
    val viewModel = StudioViewModel()
    assertEquals(MainNavigationTab.HOME, viewModel.uiState.value.currentTab)
    assertTrue("Default must be Dark Mode with neon accents", viewModel.uiState.value.isDarkTheme)
    assertEquals(85, viewModel.uiState.value.aiCredits)

    viewModel.toggleTheme()
    assertFalse(viewModel.uiState.value.isDarkTheme)

    viewModel.toggleTheme()
    assertTrue(viewModel.uiState.value.isDarkTheme)

    viewModel.setHomeSearchQuery("TikTok video yap")
    assertEquals("TikTok video yap", viewModel.uiState.value.homeSearchQuery)

    viewModel.launchNewVideo(AspectRatioType.PORTRAIT_9_16)
    assertEquals(MainNavigationTab.AI_STUDIO, viewModel.uiState.value.currentTab)
    assertEquals(AspectRatioType.PORTRAIT_9_16, viewModel.uiState.value.currentAspect)

    // Test audio playback toggle
    val firstAudio = viewModel.trendAudios.first()
    viewModel.toggleTrendAudioPlayback(firstAudio.id)
    assertEquals(firstAudio.id, viewModel.uiState.value.activePlayingAudioId)

    // Test drag offset
    viewModel.updateCanvasDrag(15f, 25f)
    assertEquals(15f, viewModel.uiState.value.canvasDragOffsetX, 0.01f)
    assertEquals(25f, viewModel.uiState.value.canvasDragOffsetY, 0.01f)
    viewModel.resetCanvasDrag()
    assertEquals(0f, viewModel.uiState.value.canvasDragOffsetX, 0.01f)
  }
}
